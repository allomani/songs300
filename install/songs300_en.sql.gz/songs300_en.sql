-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 31, 2012 at 09:42 AM
-- Server version: 5.5.25a-log
-- PHP Version: 5.3.15

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `songs300_en`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_best_visitors`
--

CREATE TABLE IF NOT EXISTS `info_best_visitors` (
  `time` varchar(200) NOT NULL,
  `v_count` int(11) NOT NULL DEFAULT '0',
  KEY `v_count` (`v_count`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_best_visitors`
--

INSERT INTO `info_best_visitors` (`time`, `v_count`) VALUES
('20-Apr-2011 hour : 00:15', 2);

-- --------------------------------------------------------

--
-- Table structure for table `info_browser`
--

CREATE TABLE IF NOT EXISTS `info_browser` (
  `name` varchar(100) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_browser`
--

INSERT INTO `info_browser` (`name`, `count`) VALUES
('Netscape', 0),
('MSIE', 0),
('Lynx', 0),
('Opera', 0),
('WebTV', 0),
('Konqueror', 0),
('Bot', 0),
('Other', 0),
('Nokia', 0),
('Android', 0),
('iPhone', 0),
('iPod', 0),
('BlackBerry', 0),
('Firefox', 0),
('Chrome', 0);

-- --------------------------------------------------------

--
-- Table structure for table `info_hits`
--

CREATE TABLE IF NOT EXISTS `info_hits` (
  `date` varchar(12) NOT NULL DEFAULT '',
  `hits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `info_online`
--

CREATE TABLE IF NOT EXISTS `info_online` (
  `time` int(15) NOT NULL DEFAULT '0',
  `ip` varchar(40) NOT NULL DEFAULT '',
  KEY `ip` (`ip`),
  KEY `time` (`time`),
  KEY `time_and_ip` (`time`,`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `info_os`
--

CREATE TABLE IF NOT EXISTS `info_os` (
  `name` varchar(100) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_os`
--

INSERT INTO `info_os` (`name`, `count`) VALUES
('Windows', 0),
('Mac', 0),
('Linux', 0),
('FreeBSD', 0),
('SunOS', 0),
('IRIX', 0),
('BeOS', 0),
('OS/2', 0),
('AIX', 0),
('Other', 0),
('BlackBerry', 0),
('Symbian', 0);

-- --------------------------------------------------------

--
-- Table structure for table `songs_access_log`
--

CREATE TABLE IF NOT EXISTS `songs_access_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` text NOT NULL,
  `ip` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_albums`
--

CREATE TABLE IF NOT EXISTS `songs_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `img` text NOT NULL,
  `year` int(11) NOT NULL,
  `page_name` varchar(100) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_description` varchar(255) NOT NULL,
  `page_keywords` varchar(255) NOT NULL,
  `votes` int(11) NOT NULL,
  `votes_total` int(11) NOT NULL,
  `rate` float NOT NULL,
  `views` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `field_1` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`),
  KEY `year` (`year`),
  KEY `rate` (`rate`),
  KEY `name` (`name`),
  KEY `field_1` (`field_1`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_albums_fields`
--

CREATE TABLE IF NOT EXISTS `songs_albums_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `style` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL DEFAULT '0',
  `enable_search` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `songs_albums_fields`
--

INSERT INTO `songs_albums_fields` (`id`, `name`, `details`, `type`, `value`, `style`, `ord`, `enable_search`, `active`) VALUES
(1, 'Producer', '', 'text', '', '', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `songs_banners`
--

CREATE TABLE IF NOT EXISTS `songs_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `date` int(11) NOT NULL DEFAULT '0',
  `ord` int(11) NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `menu_id` int(11) NOT NULL DEFAULT '0',
  `menu_pos` varchar(1) NOT NULL,
  `pages` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `c_type` varchar(4) NOT NULL,
  `start_date` int(11) NOT NULL,
  `expire_date` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `menu_pos` (`menu_pos`),
  KEY `c_type` (`c_type`),
  KEY `active` (`active`),
  KEY `expire_date` (`expire_date`),
  KEY `pos_active_start_end` (`active`,`start_date`,`expire_date`,`menu_pos`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_blocks`
--

CREATE TABLE IF NOT EXISTS `songs_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `pos` varchar(1) NOT NULL,
  `file` text NOT NULL,
  `ord` int(11) NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL,
  `template` varchar(100) NOT NULL,
  `pages` varchar(255) NOT NULL,
  `cat` int(11) NOT NULL,
  `hide_title` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pos` (`pos`),
  KEY `active` (`active`),
  KEY `template` (`template`),
  KEY `pages` (`pages`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `songs_blocks`
--

INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`, `cat`, `hide_title`) VALUES
(10, 'Search', 'l', '<?\r\nglobal $keyword,$op,$phrases;\r\n\r\n$srch_arr = array("songs"=>$phrases[''the_songs''],"singers"=>$phrases[''the_singers''],"videos"=>$phrases[''the_videos''],"news"=>$phrases[''the_news'']);\r\n\r\nprint "<form  action=''search.php''>\r\n<input type=text name=''keyword'' size=''12'' value=\\"".htmlspecialchars($keyword)."\\">";\r\n\r\nprint_select_row("op",$srch_arr,$op);\r\n\r\nprint "<input type=submit value=''Search''>\r\n</form>";\r\n', 5, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(8, 'Main Menu', 'l', '<b>::</b> <a href=''index.php''>Home</a><br>\r\n<b>::</b> <a href=''news.html''>News</a><br>\r\n<b>::</b> <a href=''albums.html''>Albums</a><br>\r\n<b>::</b> <a href=''members.php''>Members</a><br>\r\n<b>::</b> <a href=''index.php?action=statics''>Statistics</a><br>\r\n<b>::</b> <a href=''contactus.php''>Contact us</a><br>\r\n ', 0, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(17, 'Categories', 'l', '<?\r\n$cats_qr=db_query("select * from songs_cats where active=1 order by ord asc");\r\nwhile($data = db_fetch($cats_qr)){\r\n       print "<b>::</b> <a href=\\"".cat_url($data[''id''],$data[''page_name''],$data[''name''])."\\" title=\\"$data[name]\\">$data[name]</a><br>";\r\n\r\n\r\n        }\r\n', 1, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(11, 'Polls', 'r', '<?\r\n$qr_title = db_query("select * from songs_votes_cats  where active=1");\r\nif(db_num($qr_title)){\r\n\r\n$data_title = db_fetch($qr_title);\r\nprint "<center>$data_title[title]</center>";\r\n$qr = mysql_query("select * from songs_votes where cat=$data_title[id]");\r\nprint "<form action=\\"votes.php\\" method=\\"post\\">\r\n<input type=''hidden'' name=''action'' value=''vote_add''>\r\n";\r\n\r\n while ($data = mysql_fetch_array($qr)){\r\n\r\n        print "<input type=''radio'' value=''$data[id]'' name=''vote_id''>$data[title]<br>";\r\n\r\n\r\n\r\n }\r\nprint "<center><br><input type=''submit'' value=''Vote''> <br><br><a href=''votes.php''>Results</a></center></form>";\r\n}else{\r\nprint "<center> there is no active poll </center>";\r\n}\r\n?>', 1, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(2, 'Most Downloaded', 'r', '<?\r\nglobal $links,$settings;\r\n\r\n$cat = $settings[''default_url_id''];\r\n\r\n$qr=db_query("select songs_songs.*,songs_singers.name as singer_name  from songs_songs,songs_singers where songs_singers.id=songs_songs.album order by songs_songs.downloads_{$cat} DESC limit 10");\r\n\r\n  $c = 0 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\n\r\n            $c++ ;\r\n\r\n          print "$c.<a href=\\"".str_replace(array(''{id}'',''{cat}''),array($data[''id''],$cat),$links[''song_listen''])."\\" title=\\"$data[singer_name] - $data[name]\\">$data[singer_name] - $data[name]</a> </font><br>";\r\n        }\r\n\r\n\r\n?>', 4, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(4, 'Online Now', 'l', '<?\r\nglobal $counter,$settings ;\r\n\r\nprint "<p align=center> there are $counter[online_users] visitor ";\r\n\r\nif($settings[''online_members_count'']){\r\nprint " , $counter[online_members] Member";\r\n}\r\n\r\nprint " browsing now</p>";\r\n\r\nprint "<p dir=rtl align=center>Most were  $counter[best_visit] in : <br> $counter[best_visit_time] <br></p>";\r\n', 9, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(13, 'Last Updates', 'c', '<?\r\nglobal $settings,$data,$phrases;\r\n\r\n$sigers_array = array();   \r\n\r\n\r\n\r\n$qr=db_query("select name,id,last_update,img,page_name from songs_singers where active=1 order by last_update desc limit 8") ;\r\n\r\nif(db_num($qr)){\r\nprint "<table width=100%><tr>";\r\n$c=0 ;\r\nwhile($data = db_fetch($qr)){\r\n\r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\nprint "<td valign=top>";\r\nrun_template(''browse_singers'');\r\nprint "</td>";\r\n              }\r\n\r\nprint "</tr></table>";\r\n}else{\r\nprint "<center>$phrases[no_data]</center>";\r\n}\r\n?>', 1, 1, '0', 'main,', 0, 0),
(18, 'Last News', 'c', '<?\r\nglobal $data,$phrases;\r\n\r\n$qr = db_query("select * from songs_news order by id DESC limit 4");\r\n\r\nif(db_num($qr)){\r\nprint "<table width=100%><tr>" ;\r\n\r\nwhile($data = db_fetch($qr)){\r\n\r\n\r\nprint "<tr><td>";\r\nrun_template(''browse_news'');  \r\nprint "</td></tr>";\r\n\r\n        }\r\nprint "</tr></table>";\r\n}else{\r\nprint "<center> $phrases[no_news] </center>";\r\n}\r\n       ?>', 6, 1, '0', 'main,', 0, 0),
(19, 'Most Downloaded Vid.', 'r', '<?\r\nglobal $links;\r\n\r\n$qr=db_query("select *  from songs_videos_data  order by downloads DESC limit 20");\r\n  $c = 0 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\n      ++$c;\r\n          print "$c.<a href=\\"".str_replace(''{id}'',$data[''id''],$links[''video_watch''])."\\" title=\\"$data[name]\\">$data[name]</a><br>";\r\n        }\r\n\r\n\r\n?>', 6, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(20, 'New Videos', 'c', '<?\r\nglobal $settings,$data,$phrases ;\r\n$qr=db_query("select * from songs_videos_data order by id DESC limit 8") ;\r\nif(db_num($qr)){\r\nprint "<table width=100%><tr>";\r\n$c=0 ;\r\nwhile ($data = db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n run_template(''browse_videos'');   \r\n\r\n              }\r\nprint "</tr></table>";\r\n}else{\r\nprint "<center>$phrases[no_data]</center>";\r\n}\r\n\r\n?>', 3, 1, '0', 'main,', 0, 0),
(21, 'Videos Categories', 'l', '<?\r\nglobal $links;\r\n\r\n$cats_qr=db_query("select * from songs_videos_cats where active=1 and cat=0 order by ord asc");\r\nwhile($data = db_fetch($cats_qr)){\r\n       print "<b>::</b> <a href=''".str_replace(''{id}'',$data[''id''],$links[''browse_videos''])."''>$data[name]</a><br>";\r\n\r\n\r\n        }', 2, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(26, 'New Albums', 'c', '<?\r\nglobal $settings,$data_album,$settings,$global_align_x,$links,$phrases;\r\n\r\n$qr=mysql_query("select songs_albums.*,songs_singers.name as singer_name,songs_singers.id as singer_id,songs_singers.page_name as signer_page_name,songs_singers.img as singer_img  from songs_albums,songs_singers where songs_singers.active=1 and songs_albums.cat=songs_singers.id order by ".iif($settings[''albums_orderby'']=="year","songs_albums.year $settings[albums_sort] , songs_albums.id $settings[albums_sort]","songs_albums.$settings[albums_orderby] $settings[albums_sort]")." limit 8") ;\r\n\r\nif(db_num($qr)){\r\nprint "<table width=100%><tr>";\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data_album =db_fetch($qr)){\r\n\r\n\r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\nprint "<td valign=top>";\r\n\r\n\r\nif (!$data_album[''img'']){\r\n$data_album[''img''] = $data_album[''singer_img''];\r\n}\r\n\r\nrun_template(''browse_albums'');\r\n\r\nprint "</td>";\r\n              \r\n}\r\n             print "</tr></table>\r\n\r\n<br><div align=''$global_align_x''><a href=\\"$links[albums_page]\\">All Albums</a></div>";\r\n}else{\r\nprint "<center>$phrases[no_data]</center>";\r\n}\r\n?>', 2, 1, '0', 'main,', 0, 0),
(22, 'Most Rated', 'r', '<?\r\nglobal $links,$settings;\r\n\r\n$cat = $settings[''default_url_id''];\r\n\r\n$qr=db_query("select songs_songs.*,songs_singers.name as singer_name  from songs_songs,songs_singers where songs_singers.id = songs_songs.album order by songs_songs.rate DESC limit 10");\r\n\r\n  $c = 1 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\nprint "$c. <a href=\\"".str_replace(array(''{id}'',''{cat}''),array($data[''id''],$cat),$links[''song_listen''])."\\" title=\\"$data[singer_name] - $data[name]\\">$data[singer_name] - $data[name]</a> <br>";\r\n\r\n$c++;\r\n}\r\n\r\n\r\n?>', 2, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(23, 'Statistics', 'l', '<?\r\nglobal $phrases;\r\n\r\n $data1 = db_qr_fetch("select count(id) as count from songs_singers");\r\n  $data3 = db_qr_fetch("select count(id) as count from songs_songs");\r\n   $data5 = db_qr_fetch("select count(id) as count from songs_videos_data");\r\n\r\n\r\nprint "\r\n\r\n<b> $phrases[singers_count] : </b> $data1[count] <br> <b>  $phrases[songs_count] : </b> $data3[count] <br> <b> $phrases[videos_count] : </b> $data5[count] \r\n";\r\n?>', 7, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(24, 'New', 'r', '<?\r\nglobal $phrases;\r\n\r\n$cached_newmenu = cache_get("newmenu");\r\n\r\nif($cached_newmenu === false){\r\n\r\n$qr = db_query("select songs_singers.*,songs_new_menu.ord from songs_singers,songs_new_menu where songs_singers.id = songs_new_menu.cat and songs_new_menu.`type` like ''singer''");\r\nwhile($data = db_fetch($qr)){\r\n $arr[$data[''ord'']] = $data;   \r\n $arr[$data[''ord'']][''type''] = "singer";   \r\n}\r\n\r\n$qr=db_query("select songs_new_menu.ord,songs_albums.*,songs_singers.id as singer_id ,songs_singers.name as singer_name,songs_singers.page_name as singer_page_name,songs_singers.img as singer_img from songs_singers,songs_albums,songs_new_menu where songs_albums.cat = songs_singers.id and songs_singers.active=1 and songs_albums.id=songs_new_menu.cat and songs_new_menu.`type` like ''album''");\r\nwhile($data = db_fetch($qr)){\r\n $arr[$data[''ord'']] = $data;   \r\n $arr[$data[''ord'']][''type''] = "album";   \r\n}\r\n\r\nunset($data);\r\n$arr = (array) $arr;\r\nksort($arr);\r\n\r\ncache_set("newmenu",$arr);\r\n}else{\r\n$arr = $cached_newmenu;\r\n$arr = (array) $arr;\r\n}\r\n\r\nprint "<center>";\r\n\r\nif(count($arr)){\r\nforeach($arr as $data){\r\n\r\nif($data[''type'']=="singer"){\r\n\r\nprint "<a href=\\"".singer_url($data[''id''],$data[''page_name''],$data[''name''])."\\" title=\\"$data[name]\\"><img src=\\"".get_image($data[''img''])."\\" alt=\\"$data[name]\\" width=50 hieght=50><br>$data[name]</a><br><br>";\r\n\r\n\r\n\r\n\r\n}else{\r\n\r\nprint "<a href=\\"".album_url($data[''id''],$data[''page_name''],$data[''name''],$data[''singer_id''],$data[''singer_page_name''],$data[''singer_name''])."\\" title=\\"$data[singer_name] - $data[name]\\"><img src=\\"".get_image(iif($data[''img''],$data[''img''],$data[''singer_img'']))."\\" alt=\\"$data[singer_name] - $data[name]\\"  width=50 hieght=50><br>$data[singer_name] - $data[name]</a>".iif($data[''year''],"<br> <font color=#9D9D9D>$data[year]</font>")."<br><br>";\r\n\r\n}\r\n}\r\n}else{\r\nprint $phrases[''no_data''];\r\n}\r\nprint "</center>";\r\n?>', 0, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(25, 'Most Listened', 'r', '<?\r\nglobal $links,$settings,$phrases;\r\n\r\n$cat = $settings[''default_url_id''];\r\n\r\n$qr=db_query("select songs_songs.*,songs_singers.name as singer_name  from songs_songs,songs_singers where songs_singers.id=songs_songs.album order by songs_songs.listens_{$cat} DESC limit 10");\r\n\r\nif(db_num($qr)){\r\n  $c = 0 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\n\r\n            $c++ ;\r\n\r\n          print "$c.<a href=\\"".str_replace(array(''{id}'',''{cat}''),array($data[''id''],$cat),$links[''song_listen''])."\\" title=\\"$data[singer_name] - $data[name]\\">$data[singer_name] - $data[name]</a> </font><br>";\r\n        }\r\n\r\n}else{\r\nprint "<center>$phrases[no_data]</center>";\r\n}\r\n?>', 3, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(27, 'Most Rated Videos', 'r', '<?\r\nglobal $links;\r\n\r\n$qr=db_query("select *  from songs_videos_data order by rate DESC limit 10");\r\n  $c = 0 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\n      ++$c;\r\n          print "$c.<a href=\\"".str_replace(''{id}'',$data[''id''],$links[''video_watch''])."\\" title=\\"$data[name]\\">$data[name]</a> </font><br>";\r\n        }\r\n\r\n\r\n?>', 7, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(31, 'Members', 'l', '<? if(check_member_login()){\r\nglobal $member_data,$style,$phrases ;\r\n\r\n\r\nprint "<center>  Welcome $member_data[username] <br> <br>" ;\r\n$nw_msgs = db_qr_fetch("select count(id) as count from songs_members_msgs where owner=''$member_data[id]'' and opened=0 and sent=0");\r\n\r\nif($nw_msgs[''count''] >0){\r\nprint "<font color=red> You have $nw_msgs[count] New Messages </font><br><br>";\r\n}\r\n\r\nprint "</center>\r\n\r\n<a href=''usercp.php''><img src=''$style[images]/my_favorite.gif''>&nbsp; $phrases[favorite_videos] </a><br>\r\n\r\n\r\n<a href=''messages.php''><img src=''$style[images]/my_messages.gif''>&nbsp; Messages</a><br>\r\n\r\n<a href=''usercp.php?action=profile''><img src=''$style[images]/my_profile.gif''>&nbsp;Profile</a><br>\r\n\r\n<a href=''usercp.php?action=friends''><img src=''$style[images]/friends_list.gif''>&nbsp; Friends List</a><br>\r\n\r\n<a href=''usercp.php?action=black_list''><img src=''$style[images]/black_list.gif''>&nbsp; Black List</a><br>\r\n\r\n<a href=''login.php?action=logout''><img src=''$style[images]/logout.gif''>&nbsp; Logout </a>\r\n</center><br>";\r\n}else{\r\n?>\r\n<form method="POST" action="login.php">\r\n<input type=hidden name=action value=login>\r\n<input type=hidden name=re_link value="<? print $_SERVER[REQUEST_URI] ; ?>">\r\n<table border="0" width="100%">\r\n	<tr>\r\n		<td height="15">Username :</td></tr><tr>\r\n		<td height="15"><input type="text" name="username" size="10"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="12">Password :</td></tr><tr>\r\n		<td height="12" ><input type="password" name="password" size="10"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="23">\r\n		<p align="center"><input type="submit" value="Login"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="38"><span lang="ar-sa">\r\n		<a href="register.php">New User ?</a><br>\r\n		<a href="index.php?action=forget_pass">Forgot your Password ? </a></td>\r\n	</tr>\r\n</table>\r\n</form>\r\n\r\n<hr class=separate_line size=1>\r\n<b>For test:</b> <br>\r\n<b>Username: </b> test<br>\r\n<b>Password : </b>test\r\n<hr class=separate_line size=1>\r\n\r\n<?\r\n}\r\n?>', 3, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(32, 'Random Songs', 'l', '<?\r\n$qr = db_query("select id,name from songs_cats where active=1 order by binary name asc");\r\nprint "<form action=''listen_all.php'' method=''post''>\r\n<input type=''hidden'' name=''action'' value=''random''>\r\n\r\n<table><tr><td colspan=2>\r\nCategory : </td></tr><tr><td colspan=2><select name=cat>\r\n<option value=''''>All Categories</option>" ;\r\n\r\nwhile($data = db_fetch($qr)){\r\nprint "<option value=''$data[id]''>$data[name]</option>";\r\n}\r\nprint "</select>\r\n</td></tr><tr><td>\r\nCount : </td><td>\r\n<select name=num>\r\n<option value=10>10</option>\r\n<option value=15>15</option>\r\n<option value=20>20</option>\r\n</select>\r\n</td></tr><tr><td colspan=2 align=center>\r\n<input type=submit value=''Listen''>\r\n</td></tr></table>\r\n</form>";\r\n', 6, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(34, 'New Songs', 'c', '<?\r\nglobal $action,$data,$data_singer,$song_ext,$lyrics_count,$urls_sets,$songs_fields_sets,$phrases,$songs_limit,$tr_class,$song_ext,$videos_count,$lyrics_count;\r\n\r\n$songs_limit =  1;\r\n\r\n$qr=db_query("select songs_new_songs_menu.song_id,songs_songs.*,songs_singers.name as singer_name,songs_singers.id as singer_id,songs_singers.page_name as singer_page_name  from songs_new_songs_menu,songs_songs,songs_singers where songs_songs.id=songs_new_songs_menu.song_id and songs_singers.id=songs_songs.album  order by songs_new_songs_menu.ord asc");\r\n\r\n  $c = 0 ;\r\n\r\nif(db_num($qr)){\r\n\r\n//--- save results to array -----------\r\nunset($saved_results);\r\n$lyrics_count = 0;\r\n$videos_count = 0;\r\n      while($data = db_fetch($qr)){  \r\n      $saved_results[] = $data;\r\n      if($data[''lyrics'']){$lyrics_count++;}\r\n      if($data[''video_id'']){$videos_count++;}\r\n      }\r\n//------------------------------------\r\n\r\n\r\nrun_template(''browse_songs_header'');\r\n\r\n\r\nforeach($saved_results as $data){\r\n\r\n   \r\n $song_ext =  get_song_ext($data[''ext''],$data[''date'']) ;\r\n\r\n\r\n$data_singer[''name''] = $data[''singer_name''];\r\n$data_singer[''id''] = $data[''singer_id''];\r\n$data_singer[''page_name''] = $data[''singer_page_name''];\r\n\r\n\r\nif($tr_class == "row_1"){\r\n$tr_class="row_2" ;\r\n}else{\r\n$tr_class="row_1";\r\n}         \r\n   \r\n\r\nrun_template(''browse_songs'');\r\n\r\n        }\r\n\r\nrun_template(''browse_songs_footer'');\r\n}else{\r\nprint "<center>$phrases[err_no_songs]</center>";\r\n}\r\n\r\n?>', 4, 1, '0', 'main,', 0, 0),
(35, 'Feeds', 'l', '<?\r\nglobal $global_align,$phrases,$sitemap_perpage;\r\n\r\n$count_songs = valueof(db_qr_fetch("select count(*) as count from songs_songs"),"count");\r\n\r\n\r\nprint "\r\n<fieldset style=''align:$global_align;''>\r\n<legend><b>RSS</b></legend>\r\n<a href=''rss.php''><img src=''images/rss_small.png''>&nbsp;$phrases[the_singers]</a>\r\n<br>\r\n<a href=''rss.php?op=songs''><img src=''images/rss_small.png''>&nbsp;$phrases[the_songs]</a>\r\n<br>\r\n<a href=''rss.php?op=albums''><img src=''images/rss_small.png''>&nbsp;$phrases[the_albums]</a>\r\n<br>\r\n<a href=''rss.php?op=videos''><img src=''images/rss_small.png''>&nbsp;$phrases[the_videos]</a>\r\n<br>\r\n<a href=''rss.php?op=photos''><img src=''images/rss_small.png''>&nbsp;$phrases[the_photos]</a>\r\n<br>\r\n<a href=''rss.php?op=news''><img src=''images/rss_small.png''>&nbsp;$phrases[the_news]</a>\r\n\r\n\r\n</fieldset>\r\n<br>\r\n\r\n<fieldset style=''align:$global_align;''>\r\n<legend><b>Site Maps</b></legend>\r\n<a href=''sitemap.php''><img src=''images/sitemap_small.gif''>&nbsp;Main Site Map</a>\r\n<br>";\r\n\r\n$pgs = $count_songs / $sitemap_perpage;\r\n$pgs = (int) $pgs;\r\nif($pgs<1){$pgs=1;}\r\n\r\nfor($i=1;$i<=$pgs;$i++){\r\nprint "<a href=''sitemap.php?op=songs".iif($i>1,"&page=$i")."''><img src=''images/sitemap_small.gif''>&nbsp;$phrases[the_songs]".iif($i>1," $i")."</a><br>";\r\n}\r\n\r\nprint "\r\n<a href=''sitemap.php?op=videos''><img src=''images/sitemap_small.gif''>&nbsp;$phrases[the_videos]</a>\r\n<br>\r\n<a href=''sitemap.php?op=photos''><img src=''images/sitemap_small.gif''>&nbsp;$phrases[the_photos]</a>\r\n\r\n</fieldset>";\r\n?>', 8, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(36, 'Playlist', 'l', '<?\r\nglobal $member_data,$phrases;\r\nif(check_member_login()){\r\n\r\nprint "\r\n<div id=\\"playlists_select_div\\">\r\n<script>\r\nget_playlists();\r\n</script>\r\n</div>\r\n<div id=\\"playlists_add_div\\" style=\\"display:none\\">\r\n<input type=text id=playlist_name name=playlist_name size=6>&nbsp;<input type=button value=\\"$phrases[add_button]\\" onclick=\\"playlists_submit($(''playlist_name'').value);\\"></div>";\r\n\r\n//----- List Items -----//\r\n\r\n$last_list_id = intval(get_cookie(''last_list_id''));\r\n\r\n\r\nprint "<form name=''playlist_form'' action=''listen_all.php'' method=''post''>\r\n<div id=\\"playlist_div\\" align=center style=\\"background-color:#FFFFFF;border: thin dashed #C0C0C0;\\">\r\n\r\n<script>\r\nget_playlist_items(".$last_list_id.");\r\n</script>";\r\n\r\nprint "</div><br>\r\n<center><input type=submit value=\\"$phrases[listen]\\"></center>\r\n</form>\r\n\r\n<script>\r\ninit_playlist_sortlist();\r\n</script>";\r\n\r\n}else{\r\nprint "<center> $phrases[please_login_first]</center>";\r\n}\r\n', 4, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(37, 'Offers', 'c', '<?\r\n\r\n$qr=db_query("select * from songs_banners where `type` like ''offer'' and active=1 and (start_date <= ".time()." or start_date=0) and (expire_date > ".time()." or expire_date=0) order by ord");\r\nif(db_num($qr)){\r\n\r\ninclude_once("includes/class_slider.php");\r\n\r\nopen_table();\r\n$slider = new slider("slider");      \r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n$ids[] = $data[''id''];\r\n\r\n$slider->start($data[''id'']);\r\nprint "<center>".iif($data[''url''],"<a href=\\"banner.php?id=$data[id]\\" target=_blank title=\\"$data[title]\\">").iif($data[''img''],"<img border=0 src=\\"$data[img]\\" alt=\\"$data[title]\\" title=\\"$data[title]\\"><br><br>").$data[''content''].iif($data[''url''],"</a>")."</center>";\r\n\r\n$slider->end();  \r\n}\r\n\r\n\r\n$slider->run();\r\ndb_query("update songs_banners set views=views+1 where id IN (".implode(",",$ids).")");\r\nclose_table();\r\n}\r\n?>', 0, 1, 'no_title_no_border', 'main,', 0, 1),
(38, 'Most Watched', 'r', '<?\r\nglobal $links;\r\n\r\n$qr=db_query("select *  from songs_videos_data  order by views DESC limit 20");\r\n  $c = 0 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\n      ++$c;\r\n          print "$c.<a href=\\"".str_replace(''{id}'',$data[''id''],$links[''video_watch''])."\\" title=\\"$data[name]\\">$data[name]</a><br>";\r\n        }\r\n\r\n\r\n?>', 5, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(40, 'New Photos', 'c', '<?\r\nglobal $phrases,$qr;\r\n\r\n$qr = db_query("select songs_singers_photos.*,songs_singers.id as singer_id , songs_singers.name as singer_name, songs_singers.page_name as singer_page_name from songs_singers_photos,songs_singers where songs_singers.id = songs_singers_photos.cat order by id desc limit 8");\r\n\r\nif(db_num($qr)){\r\n\r\n run_template(''browse_photos''); \r\n\r\n}else{\r\n\r\nprint "<center>$phrases[no_photos]</center>";\r\n}', 5, 1, '0', 'main,', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `songs_cats`
--

CREATE TABLE IF NOT EXISTS `songs_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `ord` int(2) NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL DEFAULT '0',
  `download_for_members` int(1) NOT NULL DEFAULT '0',
  `listen_for_members` int(1) NOT NULL,
  `page_name` varchar(100) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_description` varchar(255) NOT NULL,
  `page_keywords` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_comments`
--

CREATE TABLE IF NOT EXISTS `songs_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `fid` int(11) NOT NULL DEFAULT '0',
  `comment_type` varchar(100) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `time` int(14) NOT NULL DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fid` (`fid`,`comment_type`,`active`),
  KEY `active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_confirmations`
--

CREATE TABLE IF NOT EXISTS `songs_confirmations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` text NOT NULL,
  `old_value` text NOT NULL,
  `new_value` text NOT NULL,
  `cat` int(11) NOT NULL DEFAULT '0',
  `code` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_countries`
--

CREATE TABLE IF NOT EXISTS `songs_countries` (
  `name` varchar(80) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `songs_countries`
--

INSERT INTO `songs_countries` (`name`) VALUES
('Afghanistan'),
('Albania'),
('Algeria'),
('American Samoa'),
('Andorra'),
('Angola'),
('Anguilla'),
('Antarctica'),
('Antigua and Barbuda'),
('Argentina'),
('Armenia'),
('Aruba'),
('Australia'),
('Austria'),
('Azerbaijan'),
('Bahamas'),
('Bahrain'),
('Bangladesh'),
('Barbados'),
('Belarus'),
('Belgium'),
('Belize'),
('Benin'),
('Bermuda'),
('Bhutan'),
('Bolivia'),
('Bosnia and Herzegovina'),
('Botswana'),
('Bouvet Island'),
('Brazil'),
('British Indian Ocean Territory'),
('Brunei Darussalam'),
('Bulgaria'),
('Burkina Faso'),
('Burundi'),
('Cambodia'),
('Cameroon'),
('Canada'),
('Cape Verde'),
('Cayman Islands'),
('Central African Republic'),
('Chad'),
('Chile'),
('China'),
('Christmas Island'),
('Cocos (Keeling) Islands'),
('Colombia'),
('Comoros'),
('Congo'),
('Cook Islands'),
('Costa Rica'),
('Cote D''Ivoire'),
('Croatia'),
('Cuba'),
('Cyprus'),
('Czech Republic'),
('Denmark'),
('Djibouti'),
('Dominica'),
('Dominican Republic'),
('Ecuador'),
('Egypt'),
('El Salvador'),
('Equatorial Guinea'),
('Eritrea'),
('Estonia'),
('Ethiopia'),
('Faroe Islands'),
('Fiji'),
('Finland'),
('France'),
('Gabon'),
('Gambia'),
('Georgia'),
('Germany'),
('Ghana'),
('Gibraltar'),
('Greece'),
('Greenland'),
('Grenada'),
('Guadeloupe'),
('Guam'),
('Guatemala'),
('Guinea'),
('Guinea-Bissau'),
('Guyana'),
('Haiti'),
('Honduras'),
('Hong Kong'),
('Hungary'),
('Iceland'),
('India'),
('Indonesia'),
('Iraq'),
('Ireland'),
('Israel'),
('Italy'),
('Jamaica'),
('Japan'),
('Jordan'),
('Kazakhstan'),
('Kenya'),
('Kiribati'),
('Korea, Republic of'),
('Kuwait'),
('Kyrgyzstan'),
('Latvia'),
('Lebanon'),
('Lesotho'),
('Liberia'),
('Libyan Arab Jamahiriya'),
('Liechtenstein'),
('Lithuania'),
('Luxembourg'),
('Macao'),
('Madagascar'),
('Malawi'),
('Malaysia'),
('Maldives'),
('Mali'),
('Malta'),
('Marshall Islands'),
('Martinique'),
('Mauritania'),
('Mauritius'),
('Mayotte'),
('Mexico'),
('Monaco'),
('Mongolia'),
('Montserrat'),
('Morocco'),
('Mozambique'),
('Myanmar'),
('Namibia'),
('Nauru'),
('Nepal'),
('Netherlands'),
('Netherlands Antilles'),
('New Caledonia'),
('New Zealand'),
('Nicaragua'),
('Niger'),
('Nigeria'),
('Niue'),
('Norfolk Island'),
('Norway'),
('Oman'),
('Pakistan'),
('Palau'),
('Panama'),
('Papua New Guinea'),
('Paraguay'),
('Peru'),
('Philippines'),
('Pitcairn'),
('Poland'),
('Portugal'),
('Puerto Rico'),
('Qatar'),
('Reunion'),
('Romania'),
('Russian Federation'),
('Rwanda'),
('Saint Helena'),
('Saint Kitts and Nevis'),
('Saint Lucia'),
('Saint Pierre and Miquelon'),
('Samoa'),
('San Marino'),
('Sao Tome and Principe'),
('Saudi Arabia'),
('Senegal'),
('Serbia and Montenegro'),
('Seychelles'),
('Sierra Leone'),
('Singapore'),
('Slovakia'),
('Slovenia'),
('Solomon Islands'),
('Somalia'),
('South Africa'),
('Spain'),
('Sri Lanka'),
('Sudan'),
('Suriname'),
('Svalbard and Jan Mayen'),
('Swaziland'),
('Sweden'),
('Switzerland'),
('Syrian Arab Republic'),
('Taiwan, Province of China'),
('Tajikistan'),
('Thailand'),
('Timor-Leste'),
('Togo'),
('Tokelau'),
('Tonga'),
('Trinidad and Tobago'),
('Tunisia'),
('Turkey'),
('Turkmenistan'),
('Turks and Caicos Islands'),
('Tuvalu'),
('Uganda'),
('Ukraine'),
('United Arab Emirates'),
('United Kingdom'),
('United States'),
('Uruguay'),
('Uzbekistan'),
('Vanuatu'),
('Venezuela'),
('Viet Nam'),
('Virgin Islands, British'),
('Virgin Islands, U.s.'),
('Wallis and Futuna'),
('Western Sahara'),
('Yemen'),
('Zambia'),
('Zimbabwe'),
('Palestine');

-- --------------------------------------------------------

--
-- Table structure for table `songs_exts`
--

CREATE TABLE IF NOT EXISTS `songs_exts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `period_from` int(5) NOT NULL,
  `period_to` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `songs_exts`
--

INSERT INTO `songs_exts` (`id`, `name`, `period_from`, `period_to`) VALUES
(1, 'New', 31, 60),
(2, 'Very New', 0, 30),
(3, 'Jalsa', 0, 0),
(4, 'Concept', 0, 0),
(6, 'Solo', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `songs_hooks`
--

CREATE TABLE IF NOT EXISTS `songs_hooks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `hookid` text NOT NULL,
  `code` text NOT NULL,
  `ord` int(11) NOT NULL DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_links`
--

CREATE TABLE IF NOT EXISTS `songs_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `songs_links`
--

INSERT INTO `songs_links` (`id`, `name`, `value`) VALUES
(1, 'cat', 'cat/{id}-{name}.html'),
(2, 'browse_news', 'news_{cat}.html'),
(3, 'browse_news_w_pages', 'news_{cat}_{start}.html'),
(4, 'singer', 'singer/{id}-{name}.html'),
(5, 'album', 'album-{id}-{album_id}.html'),
(6, 'browse_songs_w_pages', 'singer-{id}-{album_id}-{orderby}-{sort}-{start}.html'),
(7, 'browse_videos', 'videos-{id}.html'),
(8, 'browse_videos_w_pages', 'videos-{id}-{start}.html'),
(9, 'song_download', 'song_download_{id}_{cat}'),
(10, 'song_listen', 'song_listen_{id}_{cat}.html'),
(11, 'video_download', 'video_download_{id}'),
(12, 'video_watch', 'video_watch_{id}.html'),
(26, 'singer_songs', 'singer/{id}-{name}-songs.html'),
(14, 'album_w_name', 'album/{singer_id}-{id}-{singer_name}-{name}.html'),
(16, 'news', 'news.html'),
(17, 'news_details', 'news_view_{id}.html'),
(18, 'singer_photo', 'photo_{id}.html'),
(19, 'singer_photos', 'singer/{id}-{name}-photos.html'),
(20, 'singer_videos', 'singer/{id}-{name}-videos.html'),
(21, 'pages', 'page_{id}.html'),
(22, 'profile', 'profile_{id}.html'),
(23, 'letters_songs_w_pages', 'songs-letter-{letter}-{start}.html'),
(24, 'letters_songs', 'songs-letter-{letter}.html'),
(25, 'singer_w_pages', 'singer/{id}-{album_id}-{orderby}-{sort}-{start}-{name}.html'),
(27, 'singer_albums', 'singer/{id}-{name}-albums.html'),
(28, 'singer_overview', 'singer/{id}-{name}.html'),
(29, 'singer_videos_w_pages', 'singer/{id}-{name}-videos-{start}.html'),
(30, 'singer_photos_w_pages', 'singer/{id}-{name}-photos-{start}.html'),
(31, 'singer_bio', 'singer/{id}-{name}-bio.html'),
(32, 'song_ext_listen', 'song_listen_{id}_{cat}'),
(33, 'albums_page', 'albums.html'),
(34, 'albums_page_w_pages', 'albums-{year}-{start}.html'),
(35, 'albums_page_w_year', 'albums-{year}.html'),
(36, 'letters_singers', 'singers-letter-{letter}.html');

-- --------------------------------------------------------

--
-- Table structure for table `songs_members`
--

CREATE TABLE IF NOT EXISTS `songs_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `active_code` varchar(35) NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT '0',
  `last_login` int(11) NOT NULL DEFAULT '0',
  `usr_group` int(11) NOT NULL DEFAULT '0',
  `birth` date NOT NULL DEFAULT '0000-00-00',
  `country` varchar(90) NOT NULL DEFAULT '',
  `gender` varchar(10) NOT NULL DEFAULT '',
  `members_list` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `pm_email_notify` int(1) NOT NULL,
  `privacy_settings` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `active_code` (`active_code`),
  KEY `last_login` (`last_login`),
  KEY `members_list` (`members_list`),
  KEY `gender` (`gender`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_members_black`
--

CREATE TABLE IF NOT EXISTS `songs_members_black` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid1` int(11) NOT NULL,
  `uid2` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_members_favorites`
--

CREATE TABLE IF NOT EXISTS `songs_members_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_members_friends`
--

CREATE TABLE IF NOT EXISTS `songs_members_friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid1` int(11) NOT NULL,
  `uid2` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_members_msgs`
--

CREATE TABLE IF NOT EXISTS `songs_members_msgs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `owner` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL,
  `opened` int(1) NOT NULL DEFAULT '0',
  `date` int(11) NOT NULL DEFAULT '0',
  `sent` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `owner` (`owner`),
  KEY `sent` (`sent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_members_sets`
--

CREATE TABLE IF NOT EXISTS `songs_members_sets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `details` text NOT NULL,
  `type` text NOT NULL,
  `value` text NOT NULL,
  `style` text NOT NULL,
  `required` int(11) NOT NULL DEFAULT '0',
  `ord` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_meta`
--

CREATE TABLE IF NOT EXISTS `songs_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `songs_meta`
--

INSERT INTO `songs_meta` (`id`, `name`, `title`, `description`, `keywords`) VALUES
(1, 'cats', '{name}', '{name} , {name} mp3 , {name} جديدة , {name} حصرية', '{name} , {name} mp3 , {name} جديدة , {name} حصرية'),
(2, 'member_profile', '{name} - Profile', 'Profile {name} , Member {name} , Mailing {name}', 'Profile {name} , Member {name} , Mailing {name}'),
(3, 'news', '{name}', '{name} , Read {name} , News {name} , Details {name}', '{name} , Read {name} , News {name} , Details {name}'),
(4, 'pages', '{name}', 'Page {name} , Details {name}', 'Page {name} , Details {name}'),
(5, 'search', 'Search About {name}{sp}{page}', 'Search About {name} {page}', 'Search About {name} {page}'),
(6, 'singer', '{name} - {cat_name}{sp}{page}', 'info about {name} , songs {name} , albums {name} ,{cat_name}, {page}  ', 'info about {name} , songs {name} , albums {name} ,{cat_name}, {page}  '),
(7, 'videos_cat', '{name}{sp}{page}', '{name} , {name} Clips , Videos{name} ,{name} New , {name} Exclusive {page}', '{name} , {name} Clips , Videos{name} ,{name} New , {name} Exclusive {page}'),
(8, 'news_cats', '{name}{sp}{page}', '{name} , News {name} , New {name} , {name} Exclusive', '{name} , News {name} , New {name} , {name} Exclusive'),
(9, 'letters_songs', 'Songs of {letter}{sp}{page}', 'Songs of {letter}{sp}{page}', 'Songs of {letter}{sp}{page}'),
(10, 'letters_singers', 'Singers of {letter}', 'Singers of {letter}', 'Singers of {letter}'),
(11, 'song_listen', '{name} - {singer_name} - {cat_name}', '{name},{singer_name} {album_name},{cat_name}', '{name},{singer_name} {album_name},{cat_name}'),
(12, 'album', 'Album {album} {album_year} - {name} - {cat_name}{sp}{page}', 'Album {album} {album_year} , اغاني {name} , Albums {name} ,{cat_name}, {page}  ', 'Album {album} {album_year} , اغاني {name} , Albums {name} ,{cat_name}, {page}  '),
(13, 'singer_songs', 'Songs {name} - {cat_name}{sp}{page}', 'Songs {name} , Albums {name} ,{cat_name}, {page}  ', 'Songs {name} , Albums {name} ,{cat_name}, {page}  '),
(14, 'singer_albums', 'Albums  {name} - {cat_name}', 'All Albums {name} , Songs {name} , Albums {name} ,{cat_name}', 'All Albums {name} , Songs {name} , Albums {name} ,{cat_name}'),
(15, 'singer_videos', 'Videos of {name} - {cat_name}{sp}{page}', 'Videos {name} , Songs {name} , Albums {name} ,{cat_name}, {page}  ', 'Videos {name} , Songs {name} , Albums {name} ,{cat_name}, {page}'),
(16, 'videos', 'Videos', 'Videos , Concepts , Parties , Clips', 'Videos , Concepts , Parties , Clips'),
(17, 'singer_photos', 'Photos of  {name} - {cat_name}{sp}{page}', 'Photos {name} , Songs {name} , Albums {name} ,{cat_name}, {page}  ', 'Photos {name} , Songs {name} , Albums {name} ,{cat_name}, {page}  '),
(18, 'singer_photo', 'Photo {id} - {name} - {cat_name}', 'Photo {id} , {name} , {cat_name}', 'Photo {id} , {name} , {cat_name}'),
(19, 'video_watch', '{name} - {cat_name}', 'Video {name} , Clip {name} , New {name}, Exclusive {name}, {cat_name}', 'Video {name} , Clip {name} , New {name}, Exclusive {name}, {cat_name}'),
(20, 'song_lyrics', 'Lyrics of  {name} - {singer_name} - {cat_name}', 'Lyrics {name},{singer_name} {album_name},{cat_name}', 'Lyrics {name},{singer_name} {album_name},{cat_name}'),
(21, 'albums_page_w_year', 'Albums {year}{sp}{page}', 'Albums {year}{sp}{page}', 'Albums {year}{sp}{page}'),
(22, 'albums_page', 'Albums {sp}{page}', 'All Albums {page}', 'All Albums {page}'),
(23, 'contactus', 'Contact us', 'Contact us', 'Contact us'),
(24, 'votes', 'Polls', 'Polls', 'Polls'),
(25, 'members_page', 'Members {sp}{page}', 'Members {sp}{page}', 'Members {sp}{page}'),
(26, 'singer_bio', 'Biography of {name}  - {cat_name}', 'Biography {name} , Songs {name} , Albums {name} ,{cat_name}  ', 'Biography {name} , Songs {name} , Albums {name} ,{cat_name}  ');

-- --------------------------------------------------------

--
-- Table structure for table `songs_news`
--

CREATE TABLE IF NOT EXISTS `songs_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `writer` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `details` text NOT NULL,
  `date` int(11) NOT NULL,
  `img` text NOT NULL,
  `votes` int(11) NOT NULL DEFAULT '0',
  `votes_total` int(11) NOT NULL DEFAULT '0',
  `rate` float NOT NULL,
  `cat` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`),
  KEY `rate` (`rate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_news_cats`
--

CREATE TABLE IF NOT EXISTS `songs_news_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_new_menu`
--

CREATE TABLE IF NOT EXISTS `songs_new_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT '',
  `ord` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `ord` (`ord`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_new_songs_menu`
--

CREATE TABLE IF NOT EXISTS `songs_new_songs_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `song_id` int(11) NOT NULL DEFAULT '0',
  `ord` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `song_id` (`song_id`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_pages`
--

CREATE TABLE IF NOT EXISTS `songs_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_phrases`
--

CREATE TABLE IF NOT EXISTS `songs_phrases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `cat` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=975 ;

--
-- Dumping data for table `songs_phrases`
--

INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES
(1, 'the_songs', 'Songs', 'main'),
(2, 'the_singers', 'Singers', 'main'),
(3, 'the_songs_count', 'No. of Songs', 'main'),
(4, 'the_albums_count', 'No. of Albums', 'main'),
(5, 'last_update', 'Last Update', 'main'),
(6, 'contact_us', 'Contact us', 'main'),
(7, 'no_results', 'No Results', 'main'),
(8, 'search_results', 'Search Results', 'main'),
(9, 'download', 'Download', 'main'),
(10, 'listen', 'Listen', 'main'),
(11, 'vote_song', 'Vote Song', 'main'),
(12, 'send2friend', 'Send to Friend', 'main'),
(13, 'lyrics', 'Lyrics', 'main'),
(14, 'watch', 'Watch', 'main'),
(15, 'vote_video', 'Vote Video', 'main'),
(16, 'err_no_page', 'Sorry , This page is not exists', 'main'),
(17, 'type_search_keyword', 'Please type search keyword , Minimum {letters} Letters', 'main'),
(18, 'the_name', 'Name', 'main'),
(19, 'add_date', 'Add Date', 'main'),
(20, 'err_no_videos', 'No Videos', 'main'),
(21, 'err_wrong_url', 'Wrong URL', 'main'),
(22, 'err_no_cats', 'No Categories', 'main'),
(23, 'another_songs', 'Other Songs', 'main'),
(24, 'pages', 'Pages', 'main'),
(25, 'err_no_songs', 'No Songs', 'main'),
(26, 'the_writer', 'Writer', 'main'),
(27, 'the_news_archive', 'News Archive', 'main'),
(28, 'vote_song_thnx_msg', 'Thank You , Song Vote Added', 'main'),
(29, 'vote_video_thnx_msg', 'Thank You , Video Vote Added', 'main'),
(30, 'vote_select', 'Vote', 'main'),
(31, 'vote_do', 'Vote', 'main'),
(32, 'send2friend_subject', 'Invitation from Your Friend', 'main'),
(33, 'send2friend_done', 'Invitation sent to your Friend', 'main'),
(34, 'your_name', 'Your Name', 'main'),
(35, 'your_email', 'Your Email', 'main'),
(36, 'your_friend_email', 'Friend Email', 'main'),
(37, 'send', 'Send', 'main'),
(38, 'err_vote_expire_hours', 'Sorry, You can vote Every {vote_expire_hours} Hour', 'main'),
(39, 'add2favorite', 'Add to Favorite', 'main'),
(40, 'add2fav_success', 'Added to Favorite Successfully', 'main'),
(41, 'register_closed', 'Sorry , Registration is closed', 'main'),
(42, 'no_news', 'No News', 'main'),
(43, 'err_vote_file_expire_hours', 'Sorry , You can vote file every {vote_expire_hours} Hour', 'main'),
(44, 'the_phrases', 'Phrases', 'cp'),
(45, 'welcome_to_cp', 'Welcome to Control Panel', 'cp'),
(46, 'php_version', 'PHP Version', 'cp'),
(47, 'mysql_version', 'MySQL Version', 'cp'),
(49, 'the_version', 'Version', 'cp'),
(50, 'cp_available', 'Available', 'cp'),
(51, 'cp_not_available', 'Not Available', 'cp'),
(52, 'gd_library', 'GD Library', 'cp'),
(53, 'gd_install_required', 'Gd library is not installed , without it script will not work fine.', 'cp'),
(54, 'cp_addons', 'Plugins', 'cp'),
(55, 'no_addons', 'No Plugins', 'cp'),
(56, 'edit', 'Edit', 'cp'),
(57, 'register', 'Register', 'main'),
(58, 'register_email_exists', 'Email Already Exists', 'main'),
(59, 'register_user_exists', 'Sorry , Username {username} Already Exists', 'main'),
(60, 'reg_complete', 'Registration Complete Successfully', 'main'),
(61, 'err_fileds_not_complete', 'Please Fill All Fields', 'main'),
(62, 'err_passwords_not_match', 'Password is not match it', 'main'),
(63, 'email', 'Email', 'main'),
(64, 'username', 'Username', 'main'),
(65, 'password', 'Password', 'main'),
(66, 'cp_login_do', 'Login', 'cp'),
(67, 'cp_username', 'Username', 'cp'),
(68, 'cp_password', 'Password', 'cp'),
(69, 'the_content_type', 'Content Type', 'cp'),
(70, 'the_url', 'URL', 'cp'),
(71, 'bnr_appearance_places', 'Appearance Places', 'cp'),
(72, 'bnr_appearance_pages', 'Appearance Pages', 'cp'),
(73, 'add_after_menu_number', 'Add After Menu #', 'cp'),
(74, 'login_do', 'Login', 'cp'),
(75, 'bnr_ctype_code', 'Code', 'cp'),
(76, 'bnr_ctype_img', 'Image / URL', 'cp'),
(77, 'the_code', 'Code', 'cp'),
(78, 'bnr_open', 'Site-Open', 'cp'),
(79, 'bnr_close', 'Site-Close', 'cp'),
(80, 'bnr_menu', 'Menu', 'cp'),
(81, 'bnr_header', 'Header', 'cp'),
(82, 'bnr_footer', 'Footer', 'cp'),
(83, 'bnr_menu_pos', 'on', 'cp'),
(84, 'the_left', 'The Left', 'cp'),
(85, 'the_center', 'The Center', 'cp'),
(86, 'the_right', 'The Rigth', 'cp'),
(87, 'bnr_the_menu', 'The Menu', 'cp'),
(88, 'bnr_the_visits', 'Visits', 'cp'),
(89, 'bnr_appearance_count', 'Appearance Count', 'cp'),
(90, 'add_button', 'Add', 'cp'),
(91, 'the_order', 'Order', 'cp'),
(92, 'the_image', 'Picture', 'cp'),
(93, 'the_title', 'Title', 'cp'),
(94, 'delete', 'Delete', 'cp'),
(95, 'pages_lang', 'Pages Language', 'cp'),
(96, 'pages_encoding', 'Pages Encoding', 'cp'),
(97, 'cp_enable_browsing', 'Enable Browsing', 'cp'),
(98, 'cp_opened', 'Opened', 'cp'),
(99, 'cp_closed', 'Closed', 'cp'),
(100, 'cp_browsing_closing_msg', 'Browsing Close Message', 'cp'),
(101, 'site_closed_for_visitors', 'Website Closed For Visitors', 'main'),
(102, 'cp_mailing_sending_to', 'Sending to', 'cp'),
(103, 'cp_send_as', 'Send As', 'cp'),
(104, 'cp_as_email', 'Email', 'cp'),
(105, 'next_page', 'Next Page', 'cp'),
(106, 'failed', 'Failed', 'cp'),
(107, 'cp_as_pm', 'Personal Message', 'cp'),
(108, 'cp_send_to', 'Send To', 'cp'),
(109, 'all_members', 'All Members', 'cp'),
(110, 'one_member', 'One Member', 'cp'),
(111, 'sender_name', 'Sender Name', 'cp'),
(112, 'sender_email', 'Sender Email', 'cp'),
(113, 'msg_type', 'Message Type', 'cp'),
(114, 'msg_encoding', 'Message Encoding', 'cp'),
(115, 'msg_subject', 'Message Subject', 'cp'),
(116, 'start_from', 'Start From', 'cp'),
(117, 'mailing_emails_perpage', 'Emails Per Page', 'cp'),
(118, 'auto_pages_redirection', 'Auto Pages Redirection', 'cp'),
(119, 'cp_url_fopen_disabled_msg', 'your server settings does not allow you to import file from external url', 'cp'),
(120, 'err_url_x_invalid', 'Url : {url} is invalid', 'cp'),
(121, 'local_file_uploader', 'Local File', 'cp'),
(122, 'external_file_uploader', 'External File', 'cp'),
(123, 'cp_photo_resize_width', 'width', 'cp'),
(124, 'cp_photo_resize_hieght', 'hieght', 'cp'),
(125, 'view', 'View', 'cp'),
(126, 'members_mailing', 'Members Mailing', 'cp'),
(127, 'yes', 'Yes', 'main'),
(128, 'no', 'No', 'main'),
(129, 'cp_mng_members', 'Members Managment', 'cp'),
(130, 'members_custom_fields', 'Members Additional Fields', 'cp'),
(131, 'cp_members_remote_db', 'Remote Database', 'cp'),
(132, 'the_members', 'Members', 'cp'),
(133, 'cp_add_new_template', 'Add New Template', 'cp'),
(134, 'the_description', 'Description', 'cp'),
(135, 'cp_edit_templates', 'Edit Templates', 'cp'),
(136, 'main_page', 'Main Page', 'cp'),
(137, 'the_templates', 'Templates', 'cp'),
(138, 'style_settings', 'Settings', 'cp'),
(139, 'add_style', 'Add new Styles', 'cp'),
(140, 'style_selectable', 'Selectable', 'cp'),
(141, 'template_name', 'Template Name', 'cp'),
(142, 'template_description', 'Template Description', 'cp'),
(143, 'add_new_template', 'Add New Template', 'cp'),
(144, 'are_you_sure', 'Are You Sure ?', 'cp'),
(145, 'the_database', 'The Database', 'cp'),
(146, 'backup', 'Backup', 'cp'),
(147, 'db_repair_tables_do', 'Repair Tables', 'cp'),
(148, 'cp_db_backup_do', 'Do Backup now', 'cp'),
(149, 'the_file_path', 'File Path', 'cp'),
(150, 'db_backup_saveto_server', 'Save on Your website space', 'cp'),
(151, 'db_backup_saveto_pc', 'Save on Your Computer', 'cp'),
(152, 'cp_db_backup', 'Database Backup', 'cp'),
(153, 'the_size', 'Size', 'cp'),
(154, 'the_table', 'Table', 'cp'),
(155, 'the_status', 'Status', 'cp'),
(156, 'please_select_tables_to_rapair', 'Please Select tables that you want to repair', 'cp'),
(157, 'cp_repairing_table', 'Repairing ', 'cp'),
(158, 'done', 'Done', 'cp'),
(159, 'cp_db_check_repair', 'Check / Repair', 'cp'),
(160, 'backup_done_successfully', 'Backup Done Successfully', 'cp'),
(161, 'the_search', 'Search', 'cp'),
(162, 'members_count', 'Members', 'cp'),
(163, 'cp_remote_members_db', 'Remote Members Database', 'cp'),
(164, 'use_remote_db', 'Use Remote Database', 'cp'),
(165, 'db_host', 'Database Host', 'cp'),
(166, 'db_name', 'Database Name', 'cp'),
(167, 'db_username', 'Database Username', 'cp'),
(168, 'members_table', 'Members Table Name', 'cp'),
(169, 'note', 'Note', 'cp'),
(170, 'members_remote_db_wizzard_note', 'when you use a new members remote database you have to run Remote Database Wizzard to check if the database is compatible with script and setup it', 'cp'),
(171, 'members_remote_db_wizzard', 'Remote Database Wizard', 'cp'),
(172, 'chng_field_type_success', 'Field type changed successfully', 'cp'),
(173, 'chng_field_type_failed', 'unable to change field type , please change it manually from your database admin application', 'cp'),
(174, 'add_field_failed', 'unable to add field , please add it manually from your database admin application', 'cp'),
(175, 'add_field_success', 'Field added successfully', 'cp'),
(176, 'members_remote_db_compatible', 'Remote Database is compatible', 'cp'),
(177, 'members_remote_db_uncompatible', 'the database is not compatible with script, please check and correct the errors and run the wizzard again', 'cp'),
(178, 'wrong_remote_db_name', 'Wrong Remote Database name', 'cp'),
(179, 'wrong_remote_db_connect_info', 'Error while connecting to remote database , please check connection info', 'cp'),
(180, 'members_remote_db_disabled', 'System is disabled', 'cp'),
(181, 'no_members_custom_fields', 'No Additional Fields', 'cp'),
(182, 'add_member_custom_field', 'Add New Field', 'cp'),
(183, 'the_type', 'Type', 'cp'),
(184, 'textbox', 'Text box', 'cp'),
(185, 'textarea', 'Text Area', 'cp'),
(186, 'select_menu', 'Select Menu', 'cp'),
(187, 'radio_button', 'Radio Button', 'cp'),
(188, 'checkbox', 'Checkbox', 'cp'),
(189, 'default_value_or_options', 'Default Value / Options', 'cp'),
(190, 'put_every_option_in_sep_line', 'For Options , put every option in new line', 'cp'),
(191, 'required', 'Required', 'cp'),
(192, 'addition_style', 'Field Style', 'cp'),
(193, 'addition_fields', 'Addition Fields', 'cp'),
(194, 'this_member_not_exists', 'This member is not exists', 'cp'),
(195, 'members_local_db_clean_wizzard', 'Local Database Clean Wizard', 'cp'),
(196, 'members_local_db_clean_note', 'When you use a remote or local database , some members data like private messages , favorites , custom fields , etc..  is stored on local database , so it', 'cp'),
(197, 'members_local_db_clean_description', 'Wizard will delete any members data as listed , please make sure that tables does not containing any important data then click on process button', 'cp'),
(198, 'members_msgs_table', 'Members Private Messages Table', 'cp'),
(199, 'members_favorite_table', 'Members Favorite files Table', 'cp'),
(200, 'members_custom_fields_table', 'Members Additional Fields Table', 'cp'),
(201, 'members_confirmations_table', 'Members Confirmations Table', 'cp'),
(202, 'process_done_successfully', 'Process Done Successfully', 'cp'),
(274, 'from', 'From', 'cp'),
(275, 'plz_enter_username_and_pwd', 'Please Enter the username and Password', 'main'),
(204, 'pwd_rest_request_msg_subject', 'Rest Password Request', 'cp'),
(205, 'rest_pwd_request_msg_sent', 'changing password confirmation email sent to you', 'cp'),
(206, 'pwd_rest_done_msg_subject', 'Your New Password !', 'cp'),
(207, 'pwd_rest_done', 'Your password changed and sent to your email', 'cp'),
(208, 'security_code', 'Security Code', 'cp'),
(209, 'email_activation_msg_subject', 'Email Activation', 'cp'),
(210, 'upload_file', 'Upload File', 'cp'),
(211, 'search_do', 'Search', 'cp'),
(212, 'birth', 'Birth', 'main'),
(213, 'country', 'Country', 'main'),
(214, 'select_from_menu', 'Select From Menu', 'main'),
(215, 'register_do', 'Register', 'main'),
(216, 'registered_before', 'You are already registered', 'main'),
(217, 'click_here', 'Click Here', 'main'),
(218, 'forgot_pass', 'Forgot your Password?', 'main'),
(219, 'login_info_sent', 'Login info sent to your email', 'main'),
(220, 'email_not_exists', 'Sorry , This Email is not Exists', 'main'),
(221, 'continue', 'Continue', 'main'),
(222, 'active_account', 'Account Activation', 'main'),
(223, 'active_acc_succ', 'Your Account Activated Successfullu', 'main'),
(224, 'active_acc_err', 'Sorry , Wrong URL or Account Already Activated', 'main'),
(225, 'login', 'Login', 'main'),
(226, 'newuser', 'New Member ?', 'main'),
(227, 'err_function_usage_denied', 'Error : You can', 'main'),
(228, 'err_emails_not_match', 'Email is not matching it', 'main'),
(229, 'email_confirm', 'Email Confirm', 'main'),
(230, 'err_sec_code_not_valid', 'Security code is not valid', 'main'),
(231, 'registration', 'Registration', 'cp'),
(232, 'as_every_cat_settings', 'as Every Category Settings', 'cp'),
(233, 'enabled_for_all', 'Enabled For All', 'cp'),
(234, 'stng_download_for_members_only', 'Downlaod For Members Only', 'cp'),
(235, 'security_code_in_registration', 'Registration Security Code', 'cp'),
(236, 'auto_email_activate', 'Auto Email Activation', 'cp'),
(237, 'username_min_letters', 'username Min Letters', 'cp'),
(238, 'username_exludes', 'username Excludes', 'cp'),
(239, 'emails_msgs_default_type', 'Emails Default Messages Type', 'cp'),
(240, 'emails_msgs_default_encoding', 'Emails Default Messages Encoding', 'cp'),
(241, 'leave_blank_to_use_site_encoding', 'leave it blank to use site encoding', 'cp'),
(242, 'uploader_system', 'Uploader System', 'cp'),
(243, 'disable_uploader_msg', 'Uploader Disable Message', 'cp'),
(244, 'uploader_path', 'Uploading Path', 'cp'),
(245, 'uploader_allowed_types', 'Allowed Types', 'cp'),
(246, 'enabled', 'Enabled', 'cp'),
(247, 'disabled', 'Disable', 'cp'),
(248, 'password_confirm', 'Password Confirm', 'main'),
(249, 'err_username_min_letters', 'Error , username lenght is not meeting the minimum letters lenght', 'main'),
(250, 'err_email_not_valid', 'invalid Email address', 'main'),
(251, 'err_username_not_allowed', 'Username not allowed , please select another one', 'main'),
(252, 'reg_complete_need_activation', 'Registration done , please check your email for activation message.', 'main'),
(253, 'req_addition_info', 'Required Addition Info', 'main'),
(254, 'not_req_addition_info', 'Not Required Addition Info', 'main'),
(255, 'your_email_changed_successfully', 'Your Email Changed Successfully', 'main'),
(256, 'this_account_already_activated', 'This Account Already Activated', 'main'),
(257, 'closed_account_cannot_activate', 'Sorry, This is Closed Account , you can not Activate it', 'main'),
(258, 'activation_msg_sent_successfully', 'Activation Message Sent Successfully', 'main'),
(259, 'register_date', 'Registration Date', 'cp'),
(260, 'last_login', 'Last Login', 'cp'),
(261, 'member_deleted_successfully', 'Member Deleted successfully', 'cp'),
(262, 'member_added_successfully', 'Member Added Successfully', 'cp'),
(263, 'please_fill_all_fields', 'Please Fill All Fields', 'cp'),
(264, 'member_edited_successfully', 'Member edited successfully', 'cp'),
(265, 'add_member', 'Add Member', 'cp'),
(266, 'records_perpage', 'Records Per Page', 'cp'),
(267, 'member_edit', 'Edit Member', 'cp'),
(268, 'member_acc_type', 'Account type', 'cp'),
(269, 'send_msg_to_member', 'Send Message to Member', 'cp'),
(270, 'acc_type_not_activated', 'Not Activated', 'cp'),
(271, 'acc_type_activated', 'Activated', 'cp'),
(272, 'acc_type_closed', 'Closed', 'cp'),
(273, 'leave_blank_for_no_change', 'Leave blank to not change', 'cp'),
(276, 'this_account_closed_cant_login', 'Sorrry , This Account is Closed', 'main'),
(277, 'this_account_not_activated', 'Sorry , This account is not activated', 'main'),
(278, 'chng_email_msg_subject', 'Changing email Confirm', 'main'),
(279, 'resend_activation_msg', 'resend Activation Message', 'main'),
(280, 'invalid_pwd', 'Sorry , Invalid Password', 'main'),
(281, 'invalid_username', 'Sorry , Invalid Username', 'main'),
(282, 'usercp_menu', 'Member Menu', 'main'),
(283, 'usercp_welcome_msg', 'Welcome {username} to Member Control Panel', 'main'),
(284, 'cp_hooks_fix_order', 'Fix Order', 'cp'),
(285, 'cp_hooks', 'Plugins / Hooks', 'cp'),
(286, 'no_hooks', 'No Hooks', 'cp'),
(287, 'add', 'Add', 'cp'),
(288, 'the_place', 'The Place', 'cp'),
(289, 'the_options', 'Options', 'cp'),
(290, 'the_default_template', 'Default Template', 'cp'),
(291, 'the_videos', 'Videos', 'cp'),
(292, 'the_news', 'News', 'cp'),
(293, 'the_votes', 'Polls', 'cp'),
(294, 'the_statics', 'Statics', 'cp'),
(295, 'appearance_places', 'Appearance Places', 'cp'),
(296, 'the_blocks', 'Blocks', 'cp'),
(297, 'the_position', 'Position', 'cp'),
(298, 'right', 'Right', 'cp'),
(299, 'center', 'Center', 'cp'),
(300, 'left', 'Left', 'cp'),
(301, 'the_template', 'Template', 'cp'),
(302, 'to_up', 'To up', 'cp'),
(303, 'to_down', 'To down', 'cp'),
(304, 'enable', 'Enable', 'cp'),
(305, 'disable', 'Disable', 'cp'),
(306, 'cp_blocks_fix_order', 'Fix Order', 'cp'),
(307, 'cp_no_blocks', 'No Blocks', 'cp'),
(308, 'the_content', 'Content', 'cp'),
(309, 'logout', 'Logout', 'cp'),
(310, 'the_settings', 'Settings', 'cp'),
(311, 'do_button', 'Process', 'cp'),
(312, 'news_add', 'Add News', 'cp'),
(313, 'news_short_content', 'Short Details', 'cp'),
(314, 'auto_short_content_create', 'Auto Short details Create', 'cp'),
(315, 'the_date', 'Date', 'main'),
(316, 'all', 'All', 'main'),
(317, 'view_do', 'View', 'main'),
(318, 'os_and_browsers_statics', 'OS & Browsers Statics', 'cp'),
(319, 'visitors_hits_statics', 'Visitors Hits Statics', 'cp'),
(320, 'online_visitors_statics', 'Online Visitors Statics', 'cp'),
(321, 'default_style', 'Default Style', 'cp'),
(322, 'search_min_letters', 'Search Minimum Letters', 'cp'),
(323, 'sorry_search_disabled', 'Sorry , Search Disabled', 'main'),
(324, 'uploader_title', 'Uploader', 'cp'),
(325, 'pixel', 'Pixel', 'cp'),
(326, 'this_filetype_not_allowed', 'File type not allowed', 'cp'),
(327, 'the_file', 'File', 'cp'),
(328, 'auto_photos_resize', 'Auto Pictures Resize', 'cp'),
(329, 'upload_file_do', 'Upload', 'cp'),
(330, 'allowed_filetypes', 'Allowed Types', 'cp'),
(331, 'please_login_first', 'Please Login First', 'cp'),
(332, 'uploader_thumb_width', 'Uploader - Thumb Max Width', 'cp'),
(333, 'uploader_thumb_hieght', 'Uploader - Thumb Max Hieght', 'cp'),
(334, 'fixed', 'Fixed', 'cp'),
(335, 'send2friend_failed', 'Error whie sending , please try again later', 'main'),
(336, 'invalid_from_or_to_email', 'Invalid From or To Email Address', 'main'),
(337, 'bnr_listen', 'Listen File', 'cp'),
(338, 'urls_fields', 'Songs Urls Fields', 'cp'),
(339, 'urls_fields_add', 'Add new Field', 'cp'),
(340, 'access_denied', 'Access Denied', 'cp'),
(341, 'no_singers', 'No Singers', 'cp'),
(342, 'the_cat', 'Category', 'cp'),
(343, 'singers_list', 'Singers List', 'cp'),
(344, 'singer', 'Singer', 'cp'),
(345, 'album', 'Album', 'cp'),
(346, 'the_albums', 'Albums', 'cp'),
(347, 'no_new_files', 'No New Files', 'cp'),
(348, 'err_autosearch_folder_not_exists', 'Error, Auto Search folder is invalid', 'cp'),
(349, 'auto_search', 'Auto Search', 'cp'),
(350, 'add_songs', 'Add Songs', 'cp'),
(351, 'new_songs_menu', 'New Songs Menu', 'cp'),
(352, 'new_stores_menu', 'New Stores Menu', 'cp'),
(353, 'the_banners', 'Banners', 'cp'),
(354, 'users_and_permissions', 'Users & Permissions', 'cp'),
(355, 'permissions_manage', 'Permissions Manage', 'cp'),
(356, 'cp_sections_permissions', 'Sections Permissions', 'cp'),
(357, 'videos_cats_permissions', 'Videos Categories', 'cp'),
(358, 'songs_cats_permissions', 'Songs Categories', 'cp'),
(359, 'cp_err_username_exists', 'Error , Username already Exists', 'cp'),
(360, 'cp_plz_enter_usr_pwd', 'Please Enter username and password', 'cp'),
(361, 'cp_edit_user_success', 'Edit User Done Successfully', 'cp'),
(362, 'cp_add_user', 'Add User', 'cp'),
(363, 'cp_email', 'Email', 'cp'),
(364, 'cp_user_group', 'Group', 'cp'),
(365, 'cp_user_admin', 'Administrator', 'cp'),
(366, 'cp_user_mod', 'Moderator', 'cp'),
(367, 'the_users', 'Users', 'cp'),
(368, 'edit_personal_acc_only', 'Sorry , You can only edit your account info', 'cp'),
(369, 'click_here_to_edit_ur_account', 'To edit your account click here', 'cp'),
(372, 'the_pages', 'Pages', 'cp'),
(373, 'pages_add', 'Add New Page', 'cp'),
(374, 'no_pages', 'No Pages', 'cp'),
(375, 'err_cat_access_denied', 'Category Access Denied', 'cp'),
(376, 'songs_custom_fields', 'Songs Additional Fields', 'cp'),
(377, 'songs_field_add', 'Add New Field', 'cp'),
(378, 'no_data', 'No Data', 'cp'),
(381, 'songs_default_orderby', 'Songs Default Sort', 'cp'),
(380, 'field_style', 'Field Style', 'cp'),
(382, 'asc', 'ASC', 'cp'),
(383, 'desc', 'DESC', 'cp'),
(384, 'visitors_can_sort_songs', 'Visitors Can Select Songs Sort', 'cp'),
(386, 'the_most_voted', 'Most Voted', 'cp'),
(387, 'songs_orderby_text', 'Order By', 'cp'),
(388, 'the_download', 'Download', 'cp'),
(389, 'download_for_all_visitors', 'All Visitors Can Download', 'cp'),
(390, 'download_for_members_only', 'Members Only Can Downlaod', 'cp'),
(391, 'stng_videos_download_for_members_only', 'Only Members Can Download Videos', 'cp'),
(392, 'add_to_playlist', 'Add to Playlist', 'cp'),
(393, 'stng_songs_multi_select', 'Enable multi-select songs for visitors', 'cp'),
(394, 'playlists_add', 'Add New Playlist', 'main'),
(395, 'playlists_del', 'Delete Current Playlist', 'main'),
(396, 'printable_copy', 'Print', 'main'),
(397, 'members_playlists_table', 'Playlists Table', 'cp'),
(398, 'singers_other_letters', 'Other', 'main'),
(399, 'the_favorite', 'Favorite', 'main'),
(400, 'no_files', 'No Files', 'main'),
(401, 'send_new_msg', 'Send New Message', 'main'),
(402, 'the_messages', 'Messages', 'main'),
(403, 'used_messages', 'Used Messages', 'main'),
(404, 'pm_box_full_warning', 'Warning : Your Box is Full and you can', 'main'),
(405, 'no_messages', 'No Messages', 'main'),
(406, 'the_sender', 'Sender', 'main'),
(407, 'the_subject', 'Subject', 'main'),
(408, 'reply', 'Reply', 'main'),
(409, 'err_sendto_pm_box_full', 'Error, Box that you trying to sent to is full.', 'main'),
(410, 'pm_sent_successfully', 'Your Message Sent Successfully', 'main'),
(411, 'err_sendto_username_invalid', 'Error , Receiver username is invalid', 'main'),
(412, 'the_message', 'Message', 'main'),
(413, 'chng_email_conf_msg_sent', 'your new email confirmation message sent to your email', 'main'),
(414, 'your_profile_updated_successfully', 'Your Profile Updated Successfully', 'main'),
(415, 'the_profile', 'Profile', 'main'),
(416, 'default_playlist', 'Default Playlist', 'main'),
(417, 'err_wrong_uploader_folder', 'Wrong Uploader Folder', 'cp'),
(418, 'register_email_exists2', 'if this is your email and you forgot the password ', 'cp'),
(419, 'the_statics_and_counters', 'Counters', 'cp'),
(420, 'cp_visitors_statics', 'Visitors Statics', 'cp'),
(421, 'cp_counters_start_date', 'Counters start Date', 'cp'),
(422, 'cp_total_visits', 'Total Visits', 'cp'),
(423, 'the_hour', 'Hour', 'cp'),
(424, 'operating_systems', 'Operating Systems', 'main'),
(425, 'the_browsers', 'Browser', 'main'),
(426, 'monthly_statics_for', 'Monthly Statics for ', 'main'),
(427, 'daily_statics_for', 'Daily Statics for', 'main'),
(428, 'the_year', 'Year', 'main'),
(429, 'the_month', 'Month', 'main'),
(430, 'right_to_left', 'Right to Left', 'cp'),
(431, 'left_to_right', 'Left to Right', 'cp'),
(432, 'page_dir', 'Page Direction', 'cp'),
(433, 'mailing_email', 'Mailing Email', 'cp'),
(434, 'copyrights_sitename', 'Copyrights Site Name', 'cp'),
(435, 'section_name', 'Section Name', 'cp'),
(436, 'site_name', 'Site Name', 'cp'),
(437, 'page_keywords', 'Keywords', 'cp'),
(438, 'votes_expire_time', 'Seperation time between polls', 'cp'),
(439, 'hour', 'Hour', 'cp'),
(440, 'the_songs_cats', 'Songs Categories', 'cp'),
(441, 'the_songs_and_singers', 'Singers &amp; Songs', 'cp'),
(442, 'the_songs_exts', 'Songs Extensions', 'cp'),
(443, 'add_edit_videos', 'Add / Edit Videos', 'cp'),
(444, 'bnr_views', 'View', 'cp'),
(445, 'bnr_visits', 'Visit', 'cp'),
(446, 'del_cat_warning', 'Warning : This Action will delete also all songs and singers under this category , Continue ?', 'cp'),
(447, 'show_download_icon', 'Show download icon', 'cp'),
(448, 'the_download_icon', 'Download Icon', 'cp'),
(449, 'download_icon_alt', 'Download icon Alt', 'cp'),
(450, 'show_listen_icon', 'Show Listen Icon', 'cp'),
(451, 'the_listen_icon', 'Listen Icon', 'cp'),
(452, 'listen_icon_alt', 'Listen icon Alt', 'cp'),
(453, 'listen_file_mime', 'Listen File MIME', 'cp'),
(454, 'listen_file_name', 'Listen File Name', 'cp'),
(455, 'listen_file_content', 'Listen FIle Content', 'cp'),
(456, 'the_cats', 'Categories', 'cp'),
(457, 'del_video_cat_warning', 'Warning : This Action will delete also all videos under this category , Continue ?', 'cp'),
(458, 'add_video', 'Add New Video', 'cp'),
(459, 'add_cat', 'Add Category', 'cp'),
(460, 'no_videos_or_no_permissions', 'No Video or you do not have the permissions to see this category', 'cp'),
(461, 'default', 'Default', 'cp'),
(462, 'view_page', 'View Page', 'cp'),
(463, 'vote_add', 'Add new Vote', 'cp'),
(464, 'set_default', 'Set as Default', 'cp'),
(465, 'edit_or_options', 'Edit / Options', 'cp'),
(466, 'add_options', 'Add Options', 'cp'),
(467, 'vote_files_expire_time', 'Seperation time between files votes', 'cp'),
(468, 'images_cells_count', 'Images Cells Count', 'cp'),
(469, 'news_perpage', 'News Per Page', 'cp'),
(470, 'back_to_cats', 'Back to Categories', 'cp'),
(471, 'singer_add', 'Add Singer', 'cp'),
(472, 'no_singers_or_no_permissions', 'No Singer or you do not have the permissions to see this category', 'cp'),
(473, 'move_songs', 'Move Songs', 'cp'),
(474, 'move_from', 'Move From', 'cp'),
(475, 'move_to', 'Move to', 'cp'),
(476, 'please_select_songs_first', 'Please Select Songs Firts', 'cp'),
(477, 'next', 'Next', 'cp'),
(478, 'without_album', 'Without Album', 'cp'),
(479, 'the_album', 'Album', 'cp'),
(480, 'move_do', 'Move', 'cp'),
(481, 'back_to_singers', 'Back to Singers', 'cp'),
(482, 'edit_singer', 'Edit Singer', 'cp'),
(483, 'del_singer_warning', 'Warning  : This Action will delete also all songs and albums under this singer , Continue ?', 'cp'),
(484, 'song', 'Song', 'cp'),
(485, 'select_all', 'Check All', 'cp'),
(486, 'select_none', 'Uncheck All', 'cp'),
(487, 'change_ext', 'Change Extension', 'cp'),
(488, 'move_to_album', 'Move to Album', 'cp'),
(489, 'move_to_singer', 'Move to Singer', 'cp'),
(490, 'edit_songs', 'Edit Songs', 'cp'),
(491, 'delete_songs', 'Delete Songs', 'cp'),
(492, 'add_to_new_songs_menu', 'Add to New Songs Menu', 'cp'),
(493, 'without_ext', 'Without Extension', 'cp'),
(494, 'the_comment', 'Comment', 'cp'),
(495, 'fields_count', 'No. of Fields', 'cp'),
(496, 'edit_album', 'Edit Album', 'cp'),
(497, 'singers_count', 'No. of Singers', 'cp'),
(498, 'songs_count', 'No. of Songs', 'cp'),
(499, 'videos_count', 'No. of Videos', 'cp'),
(500, 'users_count', 'Users', 'cp'),
(501, 'show_sitename_in_subpages', 'Show Site name in sub-pages', 'cp'),
(502, 'show_section_name_in_subpages', 'Show Section name in sub-pages', 'cp'),
(503, 'adding_songs_fields_count', 'Fields Count in Adding Songs Page', 'cp'),
(504, 'songs_perpage', 'Songs per-page', 'cp'),
(505, 'videos_perpage', 'Videos per-page', 'cp'),
(506, 'msgs_count_limit', 'Member Messages Limit', 'cp'),
(507, 'message', 'Message', 'cp'),
(508, 'stng_singers_letters', 'Singers Letters Bar', 'cp'),
(509, 'stng_songs_letters', 'Songs Letters Bar', 'cp'),
(510, 'stng_vote_songs', 'Voting Songs', 'cp'),
(511, 'stng_send_song', 'Sending songs to friends', 'cp'),
(512, 'stng_group_singers_by_letters', 'Show Singer in Letters Groups', 'cp'),
(513, 'stng_vote_videos', 'Voting Videos', 'cp'),
(514, 'stng_send_videos', 'Sending Videos to friends', 'cp'),
(515, 'the_listen_file', 'Listen File', 'cp'),
(516, 'ram_banner_width', 'Banners window width', 'cp'),
(517, 'ram_banner_height', 'Banners window height', 'cp'),
(518, 'listen_statics_rest_done', 'Rest Songs Listens Done', 'cp'),
(519, 'download_statics_rest_done', 'Rest Songs Downloads Done', 'cp'),
(520, 'votes_statics_rest_done', 'Rest Songs Votes Done', 'cp'),
(521, 'videos_watch_rest_done', 'Rest Videos Views Done', 'cp'),
(522, 'videos_download_rest_done', 'Rest Videos Downloads Done', 'cp'),
(523, 'videos_votes_rest_done', 'Rest Videos Votes Done', 'cp'),
(524, 'songs_listens_statics', 'Songs Listens', 'cp'),
(525, 'songs_downloads_statics', 'Songs Downloads', 'cp'),
(526, 'songs_votes_statics', 'Songs Votes', 'cp'),
(527, 'videos_watch_statics', 'Videos Views', 'cp'),
(528, 'videos_download_statics', 'Videos Downloads', 'cp'),
(529, 'videos_votes_statics', 'Videos Votes', 'cp'),
(530, 'err_invalid_song_id', '<b>Error : </b> Invalid Song ID', 'cp'),
(531, 'song_id', 'Song ID', 'cp'),
(532, 'err_invalid_id', '<b>Error : </b> Invalid ID', 'cp'),
(533, 'the_id', 'ID', 'cp'),
(534, 'without_title', 'No Title', 'cp'),
(535, 'cp_rest_counters', 'Rest Counters', 'cp'),
(536, 'cp_rest_counters_do', 'Rest Counters', 'cp'),
(537, 'visitors_statics_rest_done', 'Rest Counters Done', 'cp'),
(538, 'cp_no_phrases', 'No Phrases', 'cp'),
(539, 'cp_no_templates', 'No Templates', 'cp'),
(540, 'cp_invalid_pwd', 'invalid password', 'cp'),
(541, 'cp_invalid_username', 'invalid username', 'cp'),
(542, 'cp_welcome_msg', 'Welcome {username}', 'cp'),
(543, 'cp_statics', 'Statics', 'cp'),
(544, 'search', 'Search', 'cp'),
(545, 'forgot_pwd_msg_subject', 'Recover your password', 'cp'),
(546, 'without_selection', 'None', 'cp'),
(547, 'create_main_user', 'Create Main User', 'cp'),
(898, 'in_this_video', 'في هذا الكليب', 'main'),
(556, 'عدد أعمدة صور الفيلم', 'movie_photos_cells', 'cp'),
(562, 'rating_expire_msg', 'Sorry, You can rate every {hours} Hour', 'cp'),
(563, 'the_files_count', 'No. of Files', 'main'),
(565, 'home_page', 'Main Page', 'main'),
(567, 'back_to_news', 'Back to News', 'main'),
(568, 'no_banners', 'No Banners', 'cp'),
(571, 'watch_for_members', 'Watch for Members Only', 'cp'),
(572, 'download_for_members', 'Download For Members Only', 'cp'),
(573, 'cat_del_warn', 'Deleting this category will delete all sub categories and movies , Continue ?', 'cp'),
(574, 'add_by_name', 'Add by Name', 'cp'),
(575, 'news_votes', 'News Votes', 'cp'),
(576, 'add_by_id', 'Add by ID', 'cp'),
(577, 'news_views', 'News Views', 'cp'),
(579, 'sex', 'Gender', 'main'),
(580, 'male', 'Male', 'main'),
(581, 'female', 'Female', 'main'),
(594, 'click_and_drag_to_change_order', 'Click and Drag to Change Order', 'cp'),
(595, 'access_log', 'Access Log', 'cp'),
(596, 'comment_is_waiting_admin_review', 'Your Comment Added Successfully , Waiting for Admin Review', 'cp'),
(598, 'admin_email', 'Admin Email', 'cp'),
(599, 'page_description', 'Page Description', 'cp'),
(600, 'hide_title', 'Hide Title', 'cp'),
(601, 'page_number_x', 'Page # {x}', 'main'),
(602, 'the_details', 'Details', 'cp'),
(605, 'default_value', 'Default Value', 'cp'),
(606, 'pages_links_settings', 'Pages Links Settings', 'cp'),
(607, 'seo_settings', 'SEO Settings', 'cp'),
(608, 'pages_meta_settings', 'Pages Meta Data Settings', 'cp'),
(610, 'months_ago', 'Months Ago', 'main'),
(611, 'weeks_ago', 'Weeks Ago', 'main'),
(612, 'images_folder', 'Images Folder', 'cp'),
(613, 'edit_templates', 'Edit Templates', 'cp'),
(614, 'you_can_edit_this_values_from_config_file', 'You can edit this values from config.php file', 'cp'),
(617, 'new', 'New', 'main'),
(619, 'fields_options_add_note', 'you can edit options by click on edit button after adding the field', 'cp'),
(621, 'black_list_note', 'Members in this list cannot see your profile or send you private messages ', 'main'),
(623, 'not_available_now', 'Not Available Now', 'main'),
(624, 'update', 'Update', 'main'),
(625, 'orderby', 'Sort by', 'main'),
(626, 'remove_from_fav', 'Remove from Favorites', 'main'),
(627, 'to', 'To', 'main'),
(629, 'enlarge_pic', 'Click to Enlarge', 'main'),
(630, 'not_selected', 'Not Selected', 'main'),
(632, 'year_ago', 'Years Ago', 'main'),
(633, 'for_members_only', 'For Members Only', 'cp'),
(634, 'pm_send_denied', 'Sorry , You can''t send a message to this member', 'main'),
(635, 'add_to_friends_list', 'Add to Friends List', 'main'),
(636, 'last_page', 'Last Page', 'main'),
(637, 'prev_page', 'Prev. Page', 'main'),
(638, 'seconds_ago', 'Seconds Ago', 'main'),
(639, 'redirection_msg', 'Redirecting , if your browser not support redirecting', 'main'),
(643, 'download_for_all', 'For All', 'cp'),
(644, 'count', 'Qty', 'main'),
(646, 'prev_votes', 'Prev. Votes', 'main'),
(647, 'no_options', 'No Options', 'main'),
(649, 'not_available', 'Not Available', 'main'),
(650, 'first_page', 'First Page', 'main'),
(652, 'for_no_one', 'No One', 'main'),
(653, 'for_any_one', 'Any One', 'main'),
(656, 'not_saved', 'Not Saved', 'main'),
(657, 'minutes_ago', 'Minutes Ago', 'main'),
(658, 'telephone', 'Tel.', 'main'),
(659, 'hours_ago', 'Hours Ago', 'main'),
(660, 'city', 'City', 'main'),
(661, 'days_ago', 'Days Ago', 'main'),
(662, 'the_count', 'Qty', 'main'),
(665, 'gender', 'Gender', 'main'),
(666, 'tabbed_to', 'Tabbed To', 'cp'),
(667, 'without_tabbed_menu', 'Not Tabbed', 'cp'),
(668, 'prev', 'Prev.', 'main'),
(669, 'offers_menu', 'Offers Menu', 'main'),
(670, 'show_prev_votes', 'Show Prev. Votes', 'cp'),
(671, 'max_count', 'Max Count', 'cp'),
(672, 'random', 'Random', 'cp'),
(673, 'cats_permissions', 'Categories Permissions', 'cp'),
(674, 'cats_permissions_note', 'You can edit Categories Permission by click on edit button for each Category', 'cp'),
(676, 'for_friends_only', 'Friends Only', 'main'),
(677, 'add_to_black_list', 'Add to Black List', 'main'),
(678, 'other', 'Other', 'main'),
(680, 'leave_blank_to_use_default_settings', 'Leave it Blank to use default settings', 'cp'),
(681, 'activate', 'Activate', 'cp'),
(682, 'the_member', 'Member', 'main'),
(683, 'delete_picture', 'Delete Picture', 'main'),
(685, 'update_data', 'Update Data', 'cp'),
(688, 'text_color', 'Text Color', 'cp'),
(690, 'sending_form_code', 'Sending Form Code', 'cp'),
(692, 'short_description', 'Short Description', 'cp'),
(693, 'fields_search_menu', 'Search Menu', 'cp'),
(694, 'options_edit', 'Edit Options', 'cp'),
(695, 'the_value', 'Value', 'cp'),
(696, 'without_main_cat', 'without main Category', 'cp'),
(697, 'sent_messages', 'Sent Messages', 'main'),
(698, 'received_msgs', 'Inbox', 'main'),
(699, 'move_the_cats', 'Move Categories', 'cp'),
(700, 'please_select_cats_first', 'Please Select Categories first', 'cp'),
(701, 'add2fav_already_exists', 'This Movie already added to favorites', 'main'),
(702, 'err_invalid_cat_id', '<b> Error : </b> Invalid Category ID', 'cp'),
(703, 'err_cats_not_selected', '<b> Error : </b> No Categories Selected', 'cp'),
(704, 'move', 'Move', 'cp'),
(705, 'profile_access_denied', 'Sorry , You can''t see this profile', 'main'),
(706, 'the_moderators', 'Moderators', 'cp'),
(707, 'page_custom_info', 'Page Custom Info', 'cp'),
(708, 'the_page_keywords', 'Page Keywords', 'cp'),
(709, 'comment_type', 'Comment Type', 'cp'),
(710, 'add2fav_confirm_msg', 'Are you sure that you want to add "{name}" to favorites', 'main'),
(711, 'photos_count', 'No. of Photos', 'cp'),
(712, 'remaining_letters', 'Remaining Letters', 'cp'),
(713, 'the_comments', 'Comments', 'cp'),
(714, 'add_photos', 'Add Photos', 'cp'),
(715, 'no_photos', 'No Photos', 'cp'),
(716, 'no_moderators', 'No Moderators', 'cp'),
(717, 'available', 'Available', 'cp'),
(719, 'comments_waiting_admin_review', 'Comments Waiting Admin Review', 'cp'),
(720, 'write_your_comment', 'Write Your Comment', 'cp'),
(721, 'phrases_name_exists', 'Cannot be Added , this name already used', 'cp'),
(722, 'the_players', 'Players', 'cp'),
(723, 'no_players', 'No Players', 'cp'),
(724, 'extensions', 'Extensions', 'cp'),
(725, 'players_add', 'Add Player', 'cp'),
(726, 'ioncube_version', 'ionCube Version', 'cp'),
(727, 'internal_player', 'Internal Player', 'cp'),
(728, 'external_player', 'External Player', 'cp'),
(729, 'file_name', 'File Name', 'cp'),
(730, 'the_icon_url', 'Icon URL', 'cp'),
(731, 'the_icon_alt', 'Icon Title', 'cp'),
(732, 'use_comma_between_types', 'Use (Comma) Between Types', 'cp'),
(734, 'no_cats', 'No Categories', 'main'),
(736, 'close', 'Close', 'main'),
(741, 'download_url', 'Download URL', 'cp'),
(742, 'watch_url', 'Watch URL', 'cp'),
(744, 'add_files', 'Add Files', 'cp'),
(747, 'members_comments', 'Members Comments', 'main'),
(754, 'manage_photos', 'Manage Photos', 'cp'),
(756, 'player_view_style', 'View Style', 'cp'),
(759, 'player_view_ext_page', 'External Page', 'cp'),
(761, 'next_photo', 'Next Photo', 'cp'),
(762, 'the_photo', 'Photo', 'cp'),
(763, 'prev_photo', 'Prev. Photo', 'cp'),
(764, 'full_photo_size', 'Full Size', 'cp'),
(765, 'rating_exire_time', 'Time period between ratings', 'cp'),
(768, 'delete_cover', 'Delete Photo', 'cp'),
(969, 'show_in_members_list', 'Appear in Members List', 'main'),
(970, 'members_perpage', 'Members Per Page', 'cp'),
(971, 'rating', 'Rating', 'cp'),
(972, 'select_video', 'Select Video', 'cp'),
(973, 'video_id', 'Video ID', 'cp'),
(974, 'videos_orderby', 'Sort Videos By', 'cp'),
(781, 'release_year', 'Release Year', 'main'),
(782, 'err', 'Error', 'main'),
(783, 'edit_done', 'Edit Done Successfully', 'cp'),
(784, 'please_select_photos', 'Please Select Photos', 'cp'),
(787, 'in_this_photo', 'In This Photo', 'main'),
(788, 'more', 'More', 'main'),
(790, 'no_comments', 'No Comments', 'main'),
(791, 'please_login', 'Please Login', 'main'),
(792, 'err_empty_comment', 'Please Write your Comment', 'main'),
(793, 'older_comments', 'Older Comments', 'main'),
(794, 'no_files_selected', 'No Files Selected', 'main'),
(795, 'the_files', 'Files', 'main'),
(796, 'activated', 'Activated', 'cp'),
(797, 'not_activated', 'Not Active', 'cp'),
(798, 'since', 'Since', 'cp'),
(799, 'rating_done', 'Rating Done', 'cp'),
(800, 'report_file', 'Report File', 'cp'),
(801, 'comment_is_not_exist', 'Comment Does not Exist', 'cp'),
(802, 'report_number_x', 'Report #', 'cp'),
(803, 'security_code_in_report', 'Security Code', 'main'),
(804, 'security_code_in_send', 'Security Code', 'main'),
(805, 'err_upload_max_size', 'Please make sure that file size under', 'main'),
(806, 'photo_not_saved', 'Photo did not saved', 'main'),
(807, 'new_pm_email_notify', 'Email Notify when receiving a new private Message', 'main'),
(808, 'pm_email_notify_subject', 'New Private Message', 'main'),
(809, 'not_classified', 'Not Classified', 'main'),
(810, 'sort_by', 'Sort By', 'main'),
(917, 'photos_perpage', 'Photos Per Page', 'cp'),
(916, 'prev_singer', 'Prev. Singer', 'main'),
(813, 'online_status', 'Online Status', 'main'),
(814, 'online', 'Online', 'main'),
(815, 'offline', 'Offline', 'main'),
(915, 'next_singer', 'Next Singer', 'main'),
(914, 'prev_next_singer', 'Prev. and Next Singer', 'cp'),
(818, 'enable_search', 'Enable Search', 'cp'),
(819, 'add_custom_field', 'Add Additional Field', 'cp'),
(820, 'report_sent', 'Thank You , Report sent', 'main'),
(821, 'the_explanation', 'Explanation', 'main'),
(822, 'new_reports', 'New Reports', 'main'),
(823, 'report_type', 'Report Type', 'main'),
(824, 'the_reports', 'Reports', 'cp'),
(825, 'no_reports', 'No Reports', 'cp'),
(826, 'reports_count', 'No. of Reports', 'cp'),
(913, 'overview', 'Overview', 'main'),
(828, 'report_do', 'Report', 'main'),
(829, 'member_is_not_exist', 'Member does not exist', 'cp'),
(912, 'listen_to_songs', 'Listen to Songs', 'main'),
(831, 'comment_count', 'No. of Comments', 'cp'),
(832, 'deactivate', 'Deactivate', 'cp'),
(833, 'profile_picture', 'Profile Picture', 'main'),
(834, 'profile_preview', 'Profile Preview', 'main'),
(835, 'views', 'Views', 'main'),
(836, 'date_format', 'Date Format', 'cp'),
(837, 'the_counters', 'Counters', 'cp'),
(838, 'contactus_send_successfully', 'Thank You , Your Message sent successfully', 'main'),
(839, 'contactus_send_failed', 'Sorry , cannot send your message , please try again later', 'main'),
(840, 'without_subject', 'without subject', 'main'),
(841, 'counters_reset', 'Counters Reset', 'cp'),
(842, 'members_connectors', 'Members Connectors', 'cp'),
(844, 'cats_count', 'No. of Categories', 'main'),
(845, 'files_count', 'No. of Files', 'main'),
(846, 'comments_count', 'No. of Comments', 'main'),
(847, 'visitors_can_send_reports', 'Visitors Can Send Reports', 'cp'),
(848, 'general_settings', 'General Settings', 'cp'),
(849, 'mailing_settings', 'Mailing Settings', 'cp'),
(850, 'default_privacy_settings', 'Privacy Default Settings', 'cp'),
(851, 'pic_width', 'Picture Width', 'cp'),
(852, 'pic_height', 'Picture Height', 'cp'),
(853, 'pic_max_width', 'Picture Max Width', 'cp'),
(854, 'pic_max_height', 'Picture Max Height', 'cp'),
(855, 'thumb_width', 'Thumb Width', 'cp'),
(856, 'thumb_height', 'Thumb Height', 'cp'),
(857, 'the_photos', 'Photos', 'cp'),
(911, 'uncheck_all', 'Uncheck All', 'main'),
(910, 'check_all', 'Check All', 'main'),
(862, 'news_cat_del_warn', 'Deleting this category will delete all news inside it , Continue ?', 'cp'),
(863, 'read_more', 'Read More', 'main'),
(864, 'please_select_news_first', 'Please Select news First', 'cp'),
(909, 'this_song_only', 'This Song Only', 'cp'),
(867, 'time_and_date', 'Date and Time', 'cp'),
(868, 'timezone', 'Time Zone', 'cp'),
(869, 'privacy_settings', 'Privacy Settings', 'main'),
(870, 'profile_view', 'Profile View', 'main'),
(908, 'video', 'Video', 'main'),
(872, 'receive_pm_from', 'Receive Private Messages From', 'main'),
(873, 'this_member_exist_in_list', 'This Member Already exist in list', 'main'),
(874, 'add_done_successfully', 'Add Done Successfully', 'main'),
(875, 'friends_list', 'Friends List', 'main'),
(876, 'no_friends_in_list', 'No Friends', 'main'),
(877, 'black_list', 'Black List', 'main'),
(878, 'no_members_in_list', 'No Members', 'main'),
(881, 'max_letters', 'Max Letters', 'cp'),
(907, 'playlist', 'Playlist', 'cp'),
(906, 'visits', 'Visits', 'main'),
(886, 'news_comments', 'News Comments', 'cp'),
(887, 'comments_auto_activate', 'Comments Auto Activate', 'cp'),
(888, 'show_online_members_count', 'Show No. of Online Members', 'cp'),
(905, 'the_ext', 'Extension', 'cp'),
(890, 'commets_per_request', 'Comments Per Request', 'cp'),
(891, 'err_no_singers', 'No Singers', 'main'),
(892, 'add_album', 'Add Album', 'cp'),
(893, 'no_albums', 'No Albums', 'cp'),
(894, 'file_is_not_available', 'File is not Available', 'main'),
(895, 'page_file_name', 'Page File Name', 'cp'),
(896, 'photos_add', 'Add Photos', 'cp'),
(897, 'singer_photos', 'Singer''s Photos', 'main'),
(899, 'singer_videos', 'Singer''s Videos', 'main'),
(900, 'songs_comments', 'Songs Comments', 'cp'),
(901, 'singer_info', 'Singer Info', 'cp'),
(902, 'the_singer', 'Singer', 'cp'),
(903, 'add_videos', 'Add Videos', 'cp'),
(904, 'new_songs_menu_note', 'You can also add to this menu from going to singer page and select the songs then select add to new songs menu from the options below ', 'cp'),
(918, 'bio', 'Biography', 'main'),
(919, 'username_max_letters', 'Username Max Letters', 'cp'),
(920, 'err_username_max_letters', 'Username letters count more than allowed', 'main'),
(921, 'albums_orderby', 'Sort Albums By', 'cp'),
(922, 'downloads', 'Downloads', 'cp'),
(923, 'listens', 'Listens', 'cp'),
(924, 'prev_next_song', 'Prev. and Next Song', 'cp'),
(925, 'prev_next_cat', 'Prev. and Next Category', 'cp'),
(926, 'prev_next_album', 'Prev. and Next Album', 'cp'),
(927, 'prev_next_video', 'Prev. and Next Video', 'cp'),
(928, 'prev_next_video_cat', 'Prev. and Next Video''s Category', 'cp'),
(929, 'prev_song', 'Prev. Song', 'main'),
(930, 'next_song', 'Next Song', 'main'),
(931, 'next_video', 'Next Video', 'main'),
(932, 'prev_video', 'Prev. Video', 'main'),
(933, 'prev_cat', 'Prev. Category', 'main'),
(934, 'next_cat', 'Next Category', 'main'),
(935, 'prev_album', 'Prev. Album', 'main'),
(936, 'next_album', 'Next Album', 'main'),
(937, 'all_songs', 'All Songs', 'main'),
(938, 'for_all_visitors', 'For All Visitors', 'cp'),
(939, 'listen_permission', 'Listen Permission', 'cp'),
(940, 'download_permission', 'Download Permission', 'cp'),
(941, 'listen_type', 'Listen Type', 'cp'),
(942, 'in_site_page', 'in Site Page', 'cp'),
(943, 'ext_listen', 'External Listen', 'cp'),
(944, 'path_sep', '->', 'main'),
(945, 'singers_fields', 'Singers Additional Fields', 'cp'),
(946, 'albums_fields', 'Albums Additional Fields', 'cp'),
(947, 'favorite_videos', 'Favorite Videos', 'main'),
(948, 'custom_ext', 'Custom Ext.', 'cp'),
(949, 'auto', 'Auto', 'cp'),
(950, 'day', 'Day', 'cp'),
(951, 'ext_auto_note', 'from this option you can choose the period from add date to auto show the extenstion , you can set number 0 in fields to disable auto system', 'cp'),
(952, 'singers_perpage', 'Singers Per Page', 'cp'),
(953, 'albums_perpage', 'Albums Per Page', 'cp'),
(954, 'cp_show_singer_img', 'Show Singers Photos in CP', 'cp'),
(955, 'videos_cats_permissions_note', 'you can edit videos categories permission by click on edit button for videos categories and select the moderators', 'cp'),
(956, 'please_select_videos', 'Please Select Videos', 'cp'),
(957, 'tools', 'Tools', 'cp'),
(958, 'update_counters', 'Update Counters', 'cp'),
(959, 'delete_w_songs', 'Delete with Songs', 'cp'),
(960, 'del_with_songs_warn', 'this option will delete the album and it''s songs , do you want to continue ?', 'cp'),
(961, 'please_select_albums', 'Please Select Albums', 'cp'),
(962, 'album_move', 'Move Album', 'cp'),
(963, 'expire_date', 'Expire Date', 'cp'),
(964, 'without_expire', 'Without Expiration', 'cp'),
(965, 'start_date', 'Start Date', 'cp'),
(966, 'singer_overview_page', 'Singer Overview Page', 'cp'),
(967, 'the_age', 'Age', 'main'),
(968, 'year', 'Year', 'main');

-- --------------------------------------------------------

--
-- Table structure for table `songs_phrases_cats`
--

CREATE TABLE IF NOT EXISTS `songs_phrases_cats` (
  `id` text NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`(20))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `songs_phrases_cats`
--

INSERT INTO `songs_phrases_cats` (`id`, `name`) VALUES
('main', 'General'),
('cp', 'Control Panel / System');

-- --------------------------------------------------------

--
-- Table structure for table `songs_players`
--

CREATE TABLE IF NOT EXISTS `songs_players` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `int_content` text NOT NULL,
  `playlist_content` text NOT NULL,
  `video_content` text NOT NULL,
  `exts` varchar(255) NOT NULL DEFAULT '',
  `ext_content` text NOT NULL,
  `ext_mime` varchar(100) NOT NULL DEFAULT '',
  `ext_filename` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `exts` (`exts`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `songs_players`
--

INSERT INTO `songs_players` (`id`, `name`, `int_content`, `playlist_content`, `video_content`, `exts`, `ext_content`, `ext_mime`, `ext_filename`) VALUES
(1, 'Default Player', '<center>\r\n<OBJECT id=''rvocx'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n          width="500" height=''30''>\r\n          <param name=''src'' value="{url}">\r\n          <param name=''autostart'' value="true">\r\n          <param name=''controls'' value=''ControlPanel''>\r\n          <param name=''console'' value=''video''>\r\n          <EMBED src="{url}" width="500" height=''30''  controls=''ControlPanel'' type=''audio/x-pn-realaudio-plugin'' console=''video'' autostart="true">\r\n          </EMBED>\r\n          </OBJECT></center>\r\n', '<center>\r\n <embed src="{url}" width="500" height=''60''  controls=''ControlPanel,StatusBar'' type=''audio/x-pn-realaudio-plugin'' console=''one'' autostart="true" id=''RVOCX'' name=''RVOCX''></embed></center>\r\n\r\n<script>\r\nif(!tm){\r\n  var tm =  new PeriodicalExecuter(function(pe) {\r\nif($(''RVOCX'')){\r\n    var argx = $(''RVOCX'').GetLength();\r\n    var argy =  $(''RVOCX'').GetPosition();\r\n \r\n    \r\n    if(argy > 0){\r\n    if( argy >=  argx-1000){\r\n       play_song({next_index});  \r\n    }\r\n    \r\n    \r\n    }\r\n    \r\n}\r\n}, 1);\r\n}\r\n</script>', '<table border=''0'' cellpadding=''0'' align="center">\r\n        <tr><td>\r\n        <OBJECT id=''RVOCX'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n        width="500" height="300">\r\n        <param name=''src'' value="{url}">\r\n        <param name=''autostart'' value="true">\r\n        <param name=''controls'' value=''imagewindow''>\r\n        <param name=''console'' value=''video''>\r\n        <param name=''loop'' value="true">\r\n        <EMBED src="{url}" width="500" height="300" \r\n        loop="true" type=''audio/x-pn-realaudio-plugin'' controls=''imagewindow'' console=''video'' autostart="true">\r\n        </EMBED>\r\n        </OBJECT>\r\n        </td></tr>\r\n          <tr><td>\r\n          <OBJECT id=''RVOCX'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n          width="500" height=''30''>\r\n          <param name=''src'' value="{url}">\r\n          <param name=''autostart'' value="true">\r\n          <param name=''controls'' value=''ControlPanel''>\r\n          <param name=''console'' value=''video''>\r\n          <EMBED src="{url}" width="500" height=''30'' \r\n          controls=''ControlPanel'' type=''audio/x-pn-realaudio-plugin'' console=''video'' autostart="true">\r\n          </EMBED>\r\n          </OBJECT>\r\n          </td></tr>\r\n      </table>', '', '<?\r\nglobal $num_ramadv,$scripturl;\r\n\r\n\r\nif($num_ramadv){\r\n$adv_ram_link = "?rpcontextwidth=600&rpcontextheight=300&rpcontexturl=".$scripturl."/ram_banners.php";\r\n}else{\r\n$adv_ram_link = "";\r\n}\r\n\r\nprint "{url}".$adv_ram_link;\r\n\r\n?>', 'audio/x-pn-realaudio', 'listen.ram'),
(2, 'JW Flash Player', '<center>\r\n<div id=''player_div''></div>\r\n</center>\r\n\r\n<script>\r\n jwplayer("player_div").setup({\r\n    file: "{url}",\r\n    flashplayer: scripturl+"/players/player.swf",\r\n  ''controlbar'': ''bottom'',\r\n    height: 24,\r\n    width: 500,\r\n    autostart: true\r\n   \r\n  });\r\n</script>', '<script>\r\n jwplayer("player_div").setup({\r\n    file: "{url}",\r\n    flashplayer: scripturl+"/players/player.swf",\r\n  ''controlbar'': ''bottom'',\r\n    height: 24,\r\n    width: 500,\r\n    autostart: true\r\n   \r\n  });\r\n\r\n jwplayer("player_div").onComplete(function() {     \r\n play_song({next_index}); \r\n });\r\n</script>', '<center>\r\n<div id=''player_div''></div>\r\n</center>\r\n\r\n<script>\r\n jwplayer("player_div").setup({\r\n    file: "{url}",\r\n    flashplayer: scripturl+"/players/player.swf",\r\n    height: 300,\r\n    width: 500,\r\n    autostart: true\r\n   \r\n  });\r\n</script>', '.mp3,.flv,youtube.com,.mp4', '<?\r\nglobal $num_ramadv,$scripturl;\r\n\r\n\r\nif($num_ramadv){\r\n$adv_ram_link = "?rpcontextwidth=600&rpcontextheight=300&rpcontexturl=".$scripturl."/ram_banners.php";\r\n}else{\r\n$adv_ram_link = "";\r\n}\r\n\r\nprint "{url}".$adv_ram_link;\r\n\r\n?>', 'audio/x-pn-realaudio', 'listen.ram'),
(3, 'Windows Media Player', '    <table border=''0'' cellpadding=''0'' align="center">\r\n      <tr><td>\r\n      <OBJECT id=''mediaPlayer'' width="400" height="305"\r\n      classid=''CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95''\r\n      codebase=''http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701''\r\n      standby=''Loading Microsoft Windows Media Player components...'' type=''application/x-oleobject''>\r\n      <param name=''fileName'' value="{url}">\r\n      <param name=''animationatStart'' value=''true''>\r\n      <param name=''transparentatStart'' value=''true''>\r\n      <param name=''autoStart'' value="true">\r\n      <param name=''showControls'' value="true">\r\n      <param name=''loop'' value="false">\r\n      <EMBED type=''application/x-mplayer2''\r\n        pluginspage=''http://microsoft.com/windows/mediaplayer/en/download/''\r\n        id=''mediaPlayer'' name=''mediaPlayer'' displaysize=''4'' autosize=''-1''\r\n        bgcolor=''darkblue'' showcontrols="true" showtracker=''-1''\r\n        showdisplay=''0'' showstatusbar=''-1'' videoborder3d=''-1'' width="400" height="305"\r\n        src="{url}" autostart="true" designtimesp=''5311'' loop="false">\r\n      </EMBED>\r\n      </OBJECT>\r\n      </td></tr>\r\n      <!-- ...end embedded WindowsMedia file -->\r\n    <!-- begin link to launch external media player... -->\r\n      \r\n      </table>', '', '', '.wmv', '', '', ''),
(4, 'Divx Player', '<center>\r\n<object classid="clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616" width="600" height="358" codebase="http://go.divx.com/plugin/DivXBrowserPlugin.cab">\r\n  <param name="custommode" value="none" />\r\n  <param name="autoPlay" value="true" />\r\n  <param name="src" value="{url}" />\r\n  <embed type="video/divx"\r\n         src="{url}"\r\n         custommode="none"\r\n         width="600" height="358"\r\n         autoPlay="false"\r\n         pluginspage="http://go.divx.com/plugin/download/">\r\n  </embed>\r\n</object>\r\n', '', '', '.avi,.mkv', '', '', ''),
(6, 'Real Player', '<center>\r\n <embed src="{url}" width="500" height=''60''  controls=''ControlPanel,StatusBar'' type=''audio/x-pn-realaudio-plugin'' console=''one'' autostart="true" id=''RVOCX'' name=''RVOCX''></embed></center>', '<center>\r\n <embed src="{url}" width="500" height=''60''  controls=''ControlPanel,StatusBar'' type=''audio/x-pn-realaudio-plugin'' console=''one'' autostart="true" id=''RVOCX'' name=''RVOCX''></embed></center>\r\n\r\n<script>\r\nif(!tm){\r\n  var tm =  new PeriodicalExecuter(function(pe) {\r\nif($(''RVOCX'')){\r\n    var argx = $(''RVOCX'').GetLength();\r\n    var argy =  $(''RVOCX'').GetPosition();\r\n \r\n    \r\n    if(argy > 0){\r\n    if( argy >=  argx-1000){\r\n       play_song({next_index});  \r\n    }\r\n    \r\n    \r\n    }\r\n    \r\n}\r\n}, 1);\r\n}\r\n</script>', '<table border=''0'' cellpadding=''0'' align="center">\r\n        <tr><td>\r\n        <OBJECT id=''RVOCX'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n        width="500" height="300">\r\n        <param name=''src'' value="{url}">\r\n        <param name=''autostart'' value="true">\r\n        <param name=''controls'' value=''imagewindow''>\r\n        <param name=''console'' value=''video''>\r\n        <param name=''loop'' value="true">\r\n        <EMBED src="{url}" width="500" height="300" \r\n        loop="true" type=''audio/x-pn-realaudio-plugin'' controls=''imagewindow'' console=''video'' autostart="true">\r\n        </EMBED>\r\n        </OBJECT>\r\n        </td></tr>\r\n          <tr><td>\r\n          <OBJECT id=''RVOCX'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n          width="500" height=''30''>\r\n          <param name=''src'' value="{url}">\r\n          <param name=''autostart'' value="true">\r\n          <param name=''controls'' value=''ControlPanel''>\r\n          <param name=''console'' value=''video''>\r\n          <EMBED src="{url}" width="500" height=''30'' \r\n          controls=''ControlPanel'' type=''audio/x-pn-realaudio-plugin'' console=''video'' autostart="true">\r\n          </EMBED>\r\n          </OBJECT>\r\n          </td></tr>\r\n      </table>', '.rm,.rmvb,.rv', '<?\r\nglobal $num_ramadv,$scripturl;\r\n\r\n\r\nif($num_ramadv){\r\n$adv_ram_link = "?rpcontextwidth=600&rpcontextheight=300&rpcontexturl=".$scripturl."/ram_banners.php";\r\n}else{\r\n$adv_ram_link = "";\r\n}\r\n\r\nprint "{url}".$adv_ram_link;\r\n\r\n?>', 'audio/x-pn-realaudio', 'listen.ram');

-- --------------------------------------------------------

--
-- Table structure for table `songs_playlists`
--

CREATE TABLE IF NOT EXISTS `songs_playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_playlists_data`
--

CREATE TABLE IF NOT EXISTS `songs_playlists_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL DEFAULT '0',
  `song_id` int(11) NOT NULL DEFAULT '0',
  `ord` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `member_ord_cat` (`cat`,`member_id`,`ord`),
  KEY `member_id` (`member_id`,`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_reports`
--

CREATE TABLE IF NOT EXISTS `songs_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `report_type` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date` int(11) NOT NULL,
  `opened` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `report_type` (`report_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_settings`
--

CREATE TABLE IF NOT EXISTS `songs_settings` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `songs_settings`
--

INSERT INTO `songs_settings` (`name`, `value`) VALUES
('snd2friend', '1'),
('vote_song', '1'),
('sitename', 'Allomani'),
('section_name', 'Audio & Video v3.0'),
('songs_add_fields', '5'),
('letters_songs', '1'),
('letters_singers', '1'),
('html_dir', 'ltr'),
('header_keywords', 'Songs , Videos , Singers '),
('uploader', '0'),
('uploader_path', 'uploads'),
('uploader_msg', 'This Feature is disabled in Demo Version'),
('uploader_types', 'jpg,gif,png,rm,mp3'),
('songs_add_limit', '10'),
('singers_groups', '1'),
('songs_perpage', '100'),
('songs_cells', '4'),
('vote_clip', '1'),
('snd2friend_clip', '1'),
('votes_expire_hours', '24'),
('copyrights_sitename', 'Allomani'),
('search_min_letters', '3'),
('msgs_count_limit', '30'),
('mailing_email', 'mailing@{domain_name}'),
('member_download_only', '2'),
('members_register', '1'),
('news_perpage', '10'),
('vote_file_expire_hours', '24'),
('site_pages_lang', 'en-us'),
('site_pages_encoding', 'utf-8'),
('enable_browsing', '1'),
('disable_browsing_msg', '<center> Website Closed Now</center>'),
('register_sec_code', '1'),
('auto_email_activate', '0'),
('register_username_exclude_list', 'admin,mod,webmaster'),
('register_username_min_letters', '4'),
('mailing_default_use_html', '1'),
('mailing_default_encoding', ''),
('count_visitors_info', '1'),
('count_visitors_hits', '1'),
('count_online_visitors', '1'),
('enable_search', '1'),
('default_styleid', '1'),
('uploader_thumb_width', '100'),
('uploader_thumb_hieght', '100'),
('sitename_in_subpages', '0'),
('section_name_in_subpages', '0'),
('videos_perpage', '28'),
('visitors_can_sort_songs', '1'),
('songs_default_orderby', 'name'),
('songs_default_sort', 'asc'),
('videos_member_download_only', '2'),
('songs_multi_select', '1'),
('timezone', 'Asia/Baghdad'),
('date_format', 'd M Y'),
('comments_max_letters', '250'),
('commets_per_request', '10'),
('enable_news_comments', '1'),
('comments_auto_activate', '1'),
('photo_resized_width', '750'),
('photo_resized_height', '750'),
('photo_thumb_width', '100'),
('photo_thumb_height', '100'),
('enable_songs_comments', '1'),
('enable_singer_photo_comments', '1'),
('reports_enabled', '1'),
('online_members_count', '1'),
('send_sec_code', '1'),
('rating_expire_hours', '24'),
('other_votes_limit', '10'),
('other_votes_show', '1'),
('other_votes_orderby', 'id asc'),
('overview_photos_limit', '4'),
('overview_videos_limit', '4'),
('enable_singer_comments', '1'),
('enable_video_comments', '1'),
('enable_album_comments', '1'),
('prev_next_singer', '1'),
('photos_perpage', '28'),
('report_sec_code', '1'),
('reports_for_visitors', '1'),
('username_max_letters', '20'),
('albums_orderby', 'year'),
('albums_sort', 'desc'),
('default_url_id', '1'),
('prev_next_song', '1'),
('prev_next_cat', '1'),
('prev_next_album', '1'),
('prev_next_video', '1'),
('prev_next_video_cat', '1'),
('header_description', 'Allomani Audio & Videos Script v3.0'),
('admin_email', 'noreply@allomani.com'),
('albums_perpage', '28'),
('singers_perpage', '300'),
('cp_singer_img', '1'),
('default_privacy_settings', 'a:8:{s:7:"profile";i:0;s:6:"gender";i:0;s:5:"birth";i:0;s:7:"country";i:0;s:10:"last_login";i:0;s:6:"online";i:0;s:10:"fav_videos";i:0;s:8:"messages";i:0;}'),
('members_profile_pictures', '1'),
('profile_pic_width', '100'),
('profile_pic_height', '100'),
('profile_pic_thumb_width', '30'),
('profile_pic_thumb_height', '30'),
('members_perpage', '20'),
('videos_orderby', 'id'),
('videos_sort', 'desc');

-- --------------------------------------------------------

--
-- Table structure for table `songs_singers`
--

CREATE TABLE IF NOT EXISTS `songs_singers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `img` text NOT NULL,
  `content` text NOT NULL,
  `details` text NOT NULL,
  `last_update` int(10) NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL DEFAULT '0',
  `page_name` varchar(100) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_description` varchar(255) NOT NULL,
  `page_keywords` varchar(255) NOT NULL,
  `votes` int(11) NOT NULL,
  `votes_total` int(11) NOT NULL,
  `rate` float NOT NULL,
  `views` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `songs_count` int(11) NOT NULL,
  `albums_count` int(11) NOT NULL,
  `photos_count` int(11) NOT NULL,
  `videos_count` int(11) NOT NULL,
  `field_1` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `last_update` (`last_update`),
  KEY `cat` (`cat`),
  KEY `active` (`active`),
  KEY `rate` (`rate`),
  KEY `cat_active` (`cat`,`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_singers_fields`
--

CREATE TABLE IF NOT EXISTS `songs_singers_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `style` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL DEFAULT '0',
  `enable_search` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `songs_singers_fields`
--

INSERT INTO `songs_singers_fields` (`id`, `name`, `details`, `type`, `value`, `style`, `ord`, `enable_search`, `active`) VALUES
(1, 'Birth', '', 'text', '', '', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `songs_singers_photos`
--

CREATE TABLE IF NOT EXISTS `songs_singers_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `cat` int(11) NOT NULL DEFAULT '0',
  `img` text NOT NULL,
  `img_resized` text NOT NULL,
  `thumb` text NOT NULL,
  `date` int(10) NOT NULL DEFAULT '0',
  `ord` int(11) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL DEFAULT '0',
  `votes` int(11) NOT NULL DEFAULT '0',
  `votes_total` int(11) NOT NULL DEFAULT '0',
  `rate` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`),
  KEY `ord` (`ord`),
  KEY `rate` (`rate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_singers_photos_tags`
--

CREATE TABLE IF NOT EXISTS `songs_singers_photos_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `singer_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `singer_id` (`singer_id`),
  KEY `photo_id` (`photo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_songs`
--

CREATE TABLE IF NOT EXISTS `songs_songs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album` int(11) NOT NULL DEFAULT '0',
  `album_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `lyrics` text NOT NULL,
  `date` int(11) NOT NULL DEFAULT '0',
  `ext` int(11) NOT NULL DEFAULT '0',
  `c_ext` varchar(50) NOT NULL,
  `votes` int(11) NOT NULL DEFAULT '0',
  `votes_total` int(11) NOT NULL DEFAULT '0',
  `rate` float NOT NULL,
  `video_id` int(11) NOT NULL,
  `url_1` text NOT NULL,
  `downloads_1` int(11) NOT NULL,
  `listens_1` int(11) NOT NULL,
  `field_1` varchar(255) NOT NULL,
  `field_2` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `album` (`album`),
  KEY `album_id` (`album_id`),
  KEY `video_id` (`video_id`),
  KEY `rate` (`rate`),
  KEY `downloads_1` (`downloads_1`),
  KEY `listens_1` (`listens_1`),
  KEY `ext_and_date` (`ext`,`date`),
  KEY `c_ext` (`c_ext`),
  KEY `date` (`date`),
  KEY `ext` (`ext`),
  KEY `field_1` (`field_1`),
  KEY `field_2` (`field_2`),
  KEY `singer_and_album` (`album`,`album_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_songs_fields`
--

CREATE TABLE IF NOT EXISTS `songs_songs_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `style` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL DEFAULT '0',
  `enable_search` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `songs_songs_fields`
--

INSERT INTO `songs_songs_fields` (`id`, `name`, `details`, `type`, `value`, `style`, `ord`, `enable_search`, `active`) VALUES
(1, 'Poet', '', 'text', '', '', 0, 1, 1),
(2, 'Composer', '', 'text', '', '', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `songs_templates`
--

CREATE TABLE IF NOT EXISTS `songs_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `protected` int(11) NOT NULL DEFAULT '0',
  `cat` int(11) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=138 ;

--
-- Dumping data for table `songs_templates`
--

INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`, `views`) VALUES
(1, 'Header', 'header', '<BODY onunload="pop_close()">\r\n\r\n\r\n<div id=''header'' class=''header''><img src="images/logo.jpg"></div><br><br>\r\n\r\n<div id=''page_content'' style="dir:rtl;">', 1, 1, 0),
(2, 'Footer', 'footer', '<br>\r\n\r\n</div>\r\n\r\n<center><div id=''footer'' class=''footer''>\r\n\r\n<div align=right>&nbsp;&nbsp;&nbsp;\r\n<?global $styleid;print_style_selection();?>\r\n</div><br>\r\n\r\n\r\n</div></center>\r\n\r\n</body>\r\n</html>        \r\n        \r\n        ', 1, 1, 0),
(3, 'Blocks', 'block', '<div class=''block_div''><center>{title}{new_line}</center>{content}</div>', 1, 1, 0),
(4, 'Tables', 'table', '<div class=''block_div''>{title}{new_line}<div class=''block_div''>{content}</div></div><br>', 1, 1, 0),
(102, '', 'blocks_banners', '<?\r\nglobal $data;\r\nopen_block();\r\n\r\nprint "<center><a href=''banner.php?id=$data[id]'' target=_blank><img src=''$data[img]'' border=0 title=''$data[title]''></a></center>";\r\n\r\nclose_block();\r\n?>', 1, 1, 0),
(103, '', 'center_banners', '<?\r\nglobal $data;\r\nprint "<center><a href=''banner.php?id=$data[id]'' target=_blank><img src=''$data[img]'' border=0 title=''$data[title]''></a><br></center>";\r\n?>', 1, 1, 0),
(5, 'Contact us Form', 'contactus', '<?\r\nglobal $sec_img,$phrases,$email_name,$email_email,$email_subject,$email_msg;\r\n\r\n open_table("$phrases[contact_us]");  \r\n    print "<center>\r\n              <form action=''contactus.php'' method=post>\r\n\r\n           \r\n              <input type=hidden name=''action'' value=''send''>\r\n              <table width=60%>\r\n\r\n              <tr>\r\n              <td width=23%> $phrases[the_name] </td>\r\n              <td>\r\n              <input name=''email_name'' type=''text'' size=30 value=\\"$email_name\\">\r\n              </td>\r\n              </tr>\r\n\r\n                <tr>\r\n              <td>$phrases[email] </td>\r\n              <td>\r\n              <input name=''email_email'' type=''text'' size=30 value=\\"$email_email\\">\r\n              </td>\r\n              </tr>\r\n\r\n                  <tr>\r\n              <td> $phrases[the_subject] </td>\r\n              <td>\r\n              <input name=''email_subject'' type=''text'' size=30 value=\\"$email_subject\\">\r\n              </td>\r\n              </tr>\r\n            <tr>\r\n              <td> $phrases[the_message] </td>\r\n              <td>\r\n             <textarea name=''email_msg'' rows=5 cols=40>$email_msg</textarea>\r\n              </td>\r\n              </tr>\r\n             <tr>\r\n             <td>$phrases[security_code]</td><td>".$sec_img->output_input_box(''sec_string'',''size=7'')."\r\n           &nbsp;<img src=\\"sec_image.php\\" alt=\\"Verification Image\\" /></td></tr>\r\n           \r\n              <tr><td colspan=2 align=center>\r\n             <input type=\\"submit\\" style=\\"width: 100 ; height: 30\\" value=\\"$phrases[send]\\">\r\n             </td> </tr>\r\n             </form>\r\n             </table>\r\n            </center> ";\r\n  close_table();  \r\n?>', 1, 1, 0),
(6, 'Send song to friend message', 'friend_msg', '<html dir="ltr">\r\n<body>\r\n\r\n<div align=left>\r\n\r\n<p dir=ltr>Your friend sent this song to you</p>\r\n\r\nName : {name_from}<br>\r\nEmail: {email_from}<br><br>\r\n\r\nSong Name : {name} <br><br>\r\n\r\nListen : <br> <a href="{url}" target=_blank>{url}</a>\r\n\r\n\r\n</div>\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n\r\n</body>\r\n</html>\r\n\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ', 1, 1, 0),
(7, 'Send video to friend message', 'friend_msg_clip', '<html dir="ltr">\r\n<body>\r\n\r\n<div align=left>\r\n\r\n\r\n<p>Your friend sent a video to you</p>\r\n\r\nName : {name_from}<br>\r\nEmail : {email_from}<br><br>\r\n\r\n<center><table width=100%><td valign=top width=2><img src=''{img}''></td><td>\r\n<p align=center><b>{name}</b></p>\r\n\r\nWatch: <br> <a href="{url}" target=_blank>{url}</a>\r\n\r\n\r\n</td></tr></table></center>\r\n\r\n</div>\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n\r\n</body>\r\n</html>\r\n\r\n        \r\n        \r\n        \r\n        ', 1, 1, 0),
(47, 'Email Activation Message', 'email_activation_msg', '<html dir=ltr>\r\n<body>\r\n\r\nHello {name}, <br><br>\r\n\r\n\r\nTo Activate your email , please click on the following URL : <br>\r\n\r\n<a href="{url}" target=_blank>{url}</a>\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>\r\n', 1, 1, 0),
(109, '', 'browse_news_sep', '', 1, 1, 0),
(110, '', 'browse_news_footer', '<?\r\nclose_table();\r\n?>', 1, 1, 0),
(123, 'Video Watch Page', 'video_watch', '<?\r\nglobal $data,$settings,$phrases,$scripturl,$links,$style,$global_align_x,$data_song;\r\n\r\n$url = $data[''url''];  \r\n\r\nopen_table("$data[name]");\r\n\r\n\r\nrun_player($url,''video_content'');   \r\n\r\n\r\n print "<center><br><br><table><tr>\r\n<td align=center><a href=\\"".$scripturl."/".str_replace(array(''{id}''),array($data[''id'']),$links[''video_download''])."\\"><img src=\\"$style[images]/save_mid.gif\\" alt=\\"$phrases[download]\\"></a></td>\r\n\r\n<td align=center>\r\n<a href=''http://www.facebook.com/sharer.php?u=".urlencode($scripturl."/".str_replace(array(''{id}''),array($data[''id'']),$links[''video_watch'']))."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook_mid.gif'' alt=''Share it on Facebook'' border=0></a>\r\n</td>";\r\n\r\n//----- send -----//\r\nif($settings[''snd2friend_clip'']){\r\nprint "<td align=center><a href=\\"javascript:send($data[id],''video'');\\"><img src=''images/send_mid.gif'' border=0 title=''$phrases[send2friend]''></a></td>";\r\n}\r\n\r\n//------ fav -------\r\nif(check_member_login() && !$is_user_cp){\r\nprint "<td align=center><a href=\\"javascript:add_to_fav($data[id],''video'');\\"><img src=''images/fav_add_mid.gif'' title=''$phrases[add2favorite]'' border=0></a></td>";\r\n}\r\n\r\n//----------- report -------\r\nif($settings[''reports_enabled'']){\r\nprint "<td align=center>\r\n<a href=\\"javascript:;\\" onClick=\\"report($data[id],''video'');\\"><img src=\\"$style[images]/report.gif\\" title=\\"$phrases[report_do]\\" border=0></a></td>";  \r\n}\r\n//----------------------------\r\n\r\n\r\nprint "\r\n</table>\r\n</center>";\r\n \r\n//------- rating -----------\r\nprint "<br><br><center>";\r\nprint_rating(''video'',$data[''id''],$data[''rate'']);    \r\nprint "</center>";\r\n//-----------------------------\r\n\r\n \r\n   print "<br>\r\n        <img src=''$style[images]/add_date.gif''> &nbsp; <b>$phrases[add_date] : </b>".get_date($data[''date''])."<br>";\r\n        print "<img src=''$style[images]/views.gif''> &nbsp; <b>$phrases[views] : </b>$data[views]"; \r\n\r\nif($data_song[''id'']){\r\n print "<br><img src=''$style[images]/song.gif''> &nbsp; <b>$phrases[song] : </b> <a href=\\"".str_replace(array(''{cat}'',''{id}''),array($settings[''default_url_id''],$data_song[''id'']),$links[''song_listen''])."\\">$data_song[name]</a>"; \r\n}\r\n\r\nprint " <br>";\r\n\r\n ?>\r\n <br>\r\n        \r\n        <table width=100%>        \r\n       <TBODY>\r\n<TR>\r\n<TD class=box2 width="100%">\r\n<TABLE dir=rtl border=0 cellSpacing=0 cellPadding=2 width="100%">\r\n<TBODY>\r\n<TR>\r\n<TD class=000 width="100%"><STRONG><FONT color=#cc6600>Share it on Forums </TD></TR>\r\n<FORM id=embedFormvb name=embedFormvb action="">\r\n<TR>\r\n<TD width="100%"><textarea dir=ltr id=embed_code onclick=javascript:document.embedFormvb.embed_code.focus();document.embedFormvb.embed_code.select(); cols=55 name=embed_code style="BORDER-BOTTOM: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; FONT-FAMILY: Tahoma; FONT-SIZE: 8pt; BORDER-TOP: #c0c0c0 1px solid; BORDER-RIGHT: #c0c0c0 1px solid">\r\n<?\r\nprint "[URL=".$scripturl."/".str_replace("{id}",$data[''id''],$links[''video_watch''])."]{$data[''name'']}[/URL]\r\n</textarea> </TD></TR></FORM></TBODY></TABLE></TD></TR>";\r\n?>\r\n<TR>\r\n<TD class=box2 width="100%">\r\n<TABLE dir=rtl border=0 cellSpacing=0 cellPadding=2 width="100%">\r\n<TBODY>\r\n<TR>\r\n<TD class=000 width="100%"><STRONG><FONT color=#cc6600>Share it on Blogs </TD></TR>\r\n<FORM id=embedFormmsn name=embedFormmsn action="">\r\n<TR>\r\n<TD width="100%"><textarea dir=ltr id=embed_code onclick=javascript:document.embedFormmsn.embed_code.focus();document.embedFormmsn.embed_code.select(); cols=55 name=embed_code style="BORDER-BOTTOM: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; FONT-FAMILY: Tahoma; FONT-SIZE: 8pt; BORDER-TOP: #c0c0c0 1px solid; BORDER-RIGHT: #c0c0c0 1px solid">\r\n<?\r\n\r\nprint $scripturl."/".str_replace(''{id}'',$data[''id''],$links[''video_watch'']);\r\n?>\r\n</textarea> </TD></TR></FORM></TBODY></TABLE></TD></TR></TBODY>\r\n</table>\r\n<?\r\n\r\n\r\n\r\nclose_table();\r\n\r\n\r\n     //------ Comments -------------------\r\nif($settings[''enable_video_comments'']){\r\n    open_table($phrases[''members_comments'']);\r\n    get_comments_box(''video'',$data[''id'']);\r\n    close_table();\r\n}\r\n\r\n?>', 1, 1, 0),
(111, 'Singer''s info Table', 'singer_info_table', '<?\r\nglobal $id,$data,$data_singer,$data_album,$phrases,$settings,$links,$global_align,$style,$global_align_x;\r\n\r\n$singer_fields = get_singers_fields_sets();\r\n\r\n\r\nopen_table();\r\nprint "<table width=100%><tr><td>";\r\n\r\n//------- Singer ----------//\r\n//if(!$data_album[''name'']){\r\nprint "<table width=100%><tr><td width=20% valign=top><img src=\\"".get_image($data_singer[''img''])."\\" border=0 title=\\"$data_singer[name]\\"></td>\r\n<td valign=top> \r\n<span class=title>$data_singer[name]</span><br><br>";\r\n\r\nif($data_singer[''content'']){\r\nprint "$data_singer[content] <br><br>";\r\n}\r\n\r\nprint "\r\n<span><img src=''$style[images]/add_date.gif''>&nbsp;<b>$phrases[last_update]  : </b>".iif($data_singer[''last_update''],get_date($data_singer[''last_update'']),$phrases[''not_available''])."</span><br>\r\n\r\n<span><img src=''$style[images]/views.gif''>&nbsp;<b>$phrases[visits] : </b> $data_singer[views]</span> <br>";\r\n\r\n\r\n//--------- fields -------------\r\nforeach($singer_fields as $field){\r\n$value = $data["field_".$field[''id'']];\r\nif($value){\r\nprint "<span><img src=''$style[images]/info.gif''> &nbsp;<b>$field[name] : </b> ".iif($field[''search''],"<a href=\\"search.php?op=singers&field_id=$field[id]&keyword=".$value."\\">").$value.iif($field[''search''],"</a>")."</span><br>";\r\n}\r\n} \r\n//-------------------------------\r\n\r\n\r\nprint "<br>";\r\n      \r\n\r\n\r\n\r\nprint_rating(''singer'',$data_singer[''id''],$data_singer[''rate'']);    \r\n\r\nprint " </td></tr></table>";\r\n//}\r\n//-------- Album ---------//\r\nif($data_album[''name'']){\r\n\r\n$album_fields = get_albums_fields_sets();\r\n\r\n\r\nprint "<hr class=''separate_line'' size=1 width=\\"40%\\" align=\\"$global_align\\">\r\n<table width=100%>\r\n<tr><td width=20% valign=top><img src=\\"".get_image($data_album[''img''])."\\" border=0 title=\\"$data_singer[name] - $data_album[name]\\"></td>\r\n<td valign=top><span class=title>$phrases[album] $data_album[name]</span>\r\n<br><br>";\r\n\r\nif($data_album[''year'']){\r\nprint "<span><img src=''$style[images]/add_date.gif''>&nbsp;<b>$phrases[release_year] : </b> <a href=\\"".str_replace("{year}",$data_album[''year''],$links[''albums_page_w_year''])."\\" title=\\"$data_album[year]\\">$data_album[year]</a> </span><br>";\r\n}\r\n\r\nprint "<span><img src=''$style[images]/song.gif''>&nbsp;<b> $phrases[the_songs_count] : </b>$data_album[songs_count]</span>\r\n<br>\r\n<span><img src=''$style[images]/views.gif''>&nbsp;<b>$phrases[visits] : </b> $data_album[views] </span><br>";\r\n\r\n//--------- fields -------------\r\nforeach($album_fields as $field){\r\n$value = $data_album["field_".$field[''id'']];\r\nif($value){\r\nprint "<span><img src=''$style[images]/info.gif''> &nbsp;<b>$field[name] : </b> ".iif($field[''search''],"<a href=\\"search.php?op=albums&field_id=$field[id]&keyword=".$value."\\">").$value.iif($field[''search''],"</a>")."</span><br>";\r\n}\r\n} \r\n//-------------------------------\r\n\r\nprint "<br>";\r\n\r\nprint_rating(''album'',$data_album[''id''],$data_album[''rate'']);\r\n\r\n\r\nprint "</td></tr></table>";\r\n}\r\n\r\nprint "</td><td align=''$global_align_x''>";\r\n\r\n\r\nprint "<div class=''singer_btn''>\r\n<a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_overview''])."\\"><img src=''$style[images]/overview.gif''>&nbsp;$phrases[overview]</a>\r\n</div>";\r\n\r\nif($data_singer[''details'']){\r\nprint "<div class=''singer_btn''>\r\n<a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_bio''])."\\"><img src=''$style[images]/bio.gif''>&nbsp;$phrases[bio]</a>\r\n</div>";\r\n}\r\n\r\n\r\nprint "<div class=''singer_btn''><a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_songs''])."\\"><img src=''$style[images]/song.gif''>&nbsp;$phrases[the_songs] ($data_singer[songs_count])</a></div>";\r\n\r\nif($data_singer[''albums_count'']){\r\nprint "<div class=''singer_btn''>\r\n<a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_albums''])."\\"><img src=''$style[images]/album.gif''>&nbsp;$phrases[the_albums] ($data_singer[albums_count])</a></div>";\r\n}\r\n\r\n\r\n\r\nif($data_singer[''photos_count'']){\r\nprint "<div class=''singer_btn''><a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_photos''])."\\"><img src=''images/photos.gif''>&nbsp;$phrases[the_photos] ($data_singer[photos_count])</a></div>";\r\n}\r\n\r\nif($data_singer[''videos_count'']){\r\nprint "<div class=''singer_btn''><a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_videos''])."\\"><img src=''$style[images]/videos.gif''>&nbsp;$phrases[the_videos] ($data_singer[videos_count])</a>\r\n</div>";\r\n}\r\n\r\nprint "</td></tr></table>\r\n<br>\r\n<div align=''$global_align_x''>\r\n<a href=''http://www.facebook.com/sharer.php?u=".urlencode("http://".$_SERVER[''HTTP_HOST''].$_SERVER[''REQUEST_URI''])."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook_mid.gif'' alt=''Share it on Facebook'' border=0></a>\r\n</div>";\r\nclose_table();', 1, 1, 0),
(11, 'Singer''s Letters', 'letters_singers', '<?\r\nglobal $links;\r\n$ltrs = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");\r\n\r\nforeach($ltrs as $ltr){\r\nprint "<a class=\\"big\\" href=\\"".str_replace(''{letter}'',$ltr,$links[''letters_singers''])."\\">{$ltr}</a>&nbsp;";\r\n}\r\n?>', 1, 1, 0),
(12, 'Songs Letters', 'letters_songs', '<?\r\nglobal $links;\r\n\r\n$ltrs = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");\r\n\r\nforeach($ltrs as $ltr){\r\nprint "<a class=\\"big\\" href=\\"".str_replace(''{letter}'',$ltr,$links[''letters_songs''])."\\">{$ltr}</a>&nbsp;";\r\n}\r\n?>', 1, 1, 0),
(125, 'Singer Overview Page', 'singer_overview', '<?\r\nglobal $id,$no_singer_name,$qr_videos,$qr_photos,$data,$qr,$without_tables,$global_align_x,$links,$data_singer,$settings,$phrases;\r\n\r\n$without_tables = true;\r\n\r\n$all_songs_div = "<br>\r\n<div align=''$global_align_x''>\r\n<a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_songs''])."\\">$phrases[all_songs]</a></div>";\r\n\r\n\r\nprint "\r\n<table width=100%>\r\n\r\n<tr><td width=50%>";\r\nopen_table("Last Songs");\r\nsongs_table($id,"all","","id","desc",0,10);\r\n\r\nprint $all_songs_div;\r\n\r\nclose_table();\r\nprint "\r\n</td><td width=50%>";\r\nopen_table("Most Rated");\r\nsongs_table($id,"all","","rate","desc",0,10); \r\n\r\nprint $all_songs_div;\r\n\r\nclose_table();\r\nprint "</td></tr>\r\n\r\n\r\n\r\n<tr><td width=50%>";\r\nopen_table("Most Listened");\r\nsongs_table($id,"all","","listens_1","desc",0,10);\r\nprint $all_songs_div; \r\nclose_table();\r\nprint "\r\n</td><td width=50%>";\r\nopen_table("Most Downloaded");\r\nsongs_table($id,"all","","downloads_1","desc",0,10);  \r\nprint $all_songs_div;\r\nclose_table();\r\nprint "</td></tr></table>";\r\n\r\n\r\n//------------------- photos -----------------------\r\n$qr = $qr_photos;\r\n   if(db_num($qr)){\r\n    open_table($phrases[''singer_photos'']);\r\n    run_template(''browse_photos'');\r\n\r\nprint "<p align=''$global_align_x''><a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_photos''])."\\">All Photos</a></p>";\r\n\r\n    close_table();         \r\n         }\r\n\r\n//--------------- videos ---------------------\r\n\r\n if(db_num($qr_videos)){\r\n   open_table($phrases[''singer_videos'']); \r\n    run_template(''browse_videos_header'');\r\n\r\n    $c=0;\r\nwhile($data = db_fetch($qr_videos)){\r\n\r\n\r\n\r\nif ($c==$settings[''songs_cells'']) {\r\nrun_template("browse_videos_sep");\r\n$c = 0 ;\r\n}\r\n\r\n\r\n    run_template(''browse_videos'');\r\n$c++;\r\n\r\n           }\r\nrun_template(''browse_videos_footer'');\r\n\r\nprint "<p align=''$global_align_x''><a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_videos''])."\\">All Videos</a></p>";\r\nclose_table();\r\n}\r\n\r\n\r\n//------ Comments -------------------\r\nif($settings[''enable_singer_comments'']){\r\n    open_table($phrases[''members_comments'']);\r\n    get_comments_box(''singer'',$id);\r\n    close_table();\r\n}', 1, 1, 0),
(126, '', 'browse_photos', '<?\r\nglobal $qr,$settings,$phrases,$links;\r\n\r\nprint "<center><table width=''100%''><tr>";\r\n$c=0 ;\r\n\r\nwhile($data = db_fetch($qr)){\r\n\r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n\r\n\r\nprint "<td align=center><a href=\\"".str_replace("{id}",$data[''id''],$links[''singer_photo''])."\\"><img border=0 src=\\"".get_image($data[''thumb''])."\\" title=\\"$data[name]\\"></a>";\r\n\r\nif($data[''singer_name'']){\r\nprint "<br><a href=\\"".singer_url($data[''singer_id''],$data[''singer_page_name''],$data[''singer_id''])."\\" title=\\"$data[singer_name]\\">$data[singer_name]</a>";\r\n}\r\n\r\nprint "<br></td>" ;\r\n\r\n$c++;\r\n}\r\n\r\nprint "</tr></table>";', 1, 1, 0),
(13, 'Browse Singers', 'browse_singers', '<?\r\nglobal $data,$data_cat,$action,$links,$settings,$letter;\r\n\r\n\r\n\r\nprint "<center><a href=\\"".singer_url($data[''id''],$data[''page_name''],$data[''name''])."\\" title=\\"$data[name]\\"><img src=\\"".get_image($data[''img''])."\\" alt=\\"$data[name]\\"><br>$data[name]</a>";\r\n\r\n\r\nif(CFN=="index.php"){\r\nif($data[''last_update'']){\r\nprint "<br><font color=#9D9D9D>".get_date($data[''last_update''])."</font>";\r\n}\r\n}\r\n\r\nif(CFN=="search.php" || $letter){\r\nprint "<br><a href=\\"".cat_url($data[''cat_id''],$data[''cat_page_name''],$data[''cat_name''])."\\" title=\\"$data[cat_name]\\">$data[cat_name]</a>";\r\n}\r\n\r\nprint "<br><br></center>";\r\n?>', 1, 1, 0),
(14, 'Browse Albums', 'browse_albums', '<?\r\nglobal $phrases,$data_album,$action;\r\n\r\nprint "<center><a href=\\"".album_url($data_album[''id''],$data_album[''page_name''],$data_album[''name''],$data_album[''singer_id''],$data_album[''singer_page_name''],$data_album[''singer_name''])."\\"><img border=0 src=''".get_image($data_album[''img''])."'' title=\\"$data_album[name]".iif($data_album[''year'']," ($data_album[year])")."\\"><br>";\r\n\r\nif($data_album[''singer_name''] && CFN != "songs.php"){\r\nprint "$data_album[singer_name] - ";\r\n}\r\nprint "$data_album[name]".iif($data_album[''year'']," <br> <font color=#9D9D9D>$data_album[year]</font>")."</a><br><br></center>";\r\n?>', 1, 1, 0),
(20, 'Browse Videos', 'browse_videos', '<?\r\nglobal $data,$data_cat,$settings,$phrases,$action,$is_user_cp,$links;\r\n\r\nprint " <td><center><a href=''".str_replace(''{id}'',$data[''id''],$links[''video_watch''])."'' title=\\"$data[name]\\">\r\n            <img border=0 alt=\\"$data[name]\\"\r\n            src=''".get_image($data[''img''])."''>\r\n            <br>$data[name] </a>";\r\n\r\n\r\n\r\nif(CFN != ''videos.php''){\r\nprint "<br><a href=\\"".str_replace("{id}",$data_cat[''id''],$links[''browse_videos''])."\\" title=\\"$data_cat[name]\\">$data_cat[name]</a>";\r\n}\r\n\r\n\r\nif($data[''fav_id'']){\r\nprint "<br><br>\r\n<a href=\\"usercp.php?action=del_fav&id=$data[fav_id]\\" onclick=\\"return confirm(''$phrases[are_you_sure]'');\\"><img src=''images/delete.gif'' title=''$phrases[delete]'' border=0>$phrases[delete]</a>";\r\n}\r\n\r\n print "</center>    </td>";\r\n        ?>\r\n        \r\n        \r\n        \r\n        ', 1, 1, 0),
(22, 'Browse News - Outside', 'browse_news', '<?\r\nglobal $phrases,$data,$links,$settings;\r\n\r\n$news_date = get_date($data[''date'']);\r\n$details_link = str_replace(''{id}'',$data[''id''],$links[''news_details'']);\r\n\r\n\r\nprint "<table width=100%>\r\n\r\n<tr><td colspan=2 align=center>\r\n<a href=\\"$details_link\\" title=\\"$data[title]\\"><span class=''title''>$data[title]</span></a>\r\n</td></tr>\r\n\r\n\r\n<tr><td align=center width=''80''>\r\n<a href=\\"$details_link\\" title=\\"$data[title]\\"><img src=\\"".get_image($data[''img''])."\\" title=\\"$data[title]\\"></a></td>\r\n<td>\r\n\r\n<font color=''#808080''>$news_date : </font> $data[content] ... <a href=\\"$details_link\\"> $phrases[read_more]</a>\r\n<br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font></td></tr>\r\n\r\n</table>\r\n<hr class=separate_line size=\\"1\\">";\r\n?>', 1, 1, 0),
(18, 'Browse Songs', 'browse_songs', '<?\r\nglobal $data,$song_ext,$data_singer,$op,$settings,$phrases,$lyrics_count,$action,$is_user_cp,$urls_sets,$urls_data,$songs_fields_sets,$links,$is_member,$orderby,$videos_count,$style,$no_singer_name,$tr_class,$scripturl;\r\n\r\n\r\nprint "<div class=''song_div'' searchtext=\\"$data[name]\\">\r\n<table width=100%><tr class=''$tr_class''>\r\n<td>";\r\nif($settings[''songs_multi_select''] && CFN != "singer_overview.php"){\r\nprint "<input type=''checkbox'' name=\\"song_id[]\\" value=\\"$data[id]\\">";\r\n}\r\nprint "<img src=''images/song.gif'' border=0> &nbsp; <a href=\\"".str_replace(array(''{cat}'',''{id}''),array($settings[''default_url_id''],$data[''id'']),$links[''song_listen''])."\\" title=\\"$data[name]\\">$data[name]</a>";\r\n\r\nif($data[''c_ext'']){\r\nprint "&nbsp;&nbsp; <a href=\\"search.php?op=songs&c_ext=1&keyword=$data[c_ext]\\" title=\\"$data[c_ext]\\"><font color=''#808080''><i>$data[c_ext]</i></font></a>";\r\n}\r\n\r\n\r\nif($song_ext[''id'']){\r\nprint "&nbsp;&nbsp; <a href=\\"search.php?op=songs&ext=$song_ext[id]&keyword=$song_ext[name]\\" title=\\"$song_ext[name]\\"><font color=''#D20000''><i>$song_ext[name]</i></font></a>";\r\n}\r\n\r\nif($orderby=="id"){\r\nprint "&nbsp;&nbsp; <font color=''#000000''><i>".get_date($data[''date''])."</i></font>";\r\n}\r\n\r\nif($orderby=="rate"){\r\nprint "&nbsp;&nbsp; <font color=''#000000''><i>$data[rate]/ 5 </i></font>";\r\n}\r\n\r\n\r\n//--------- fields ---------------\r\n$br_printed = false;\r\n\r\nforeach($songs_fields_sets as $field){\r\n$value = $data["field_".$field[''id'']];\r\nif($value){\r\nif(!$br_printed){print "<br>";$br_printed=true;}\r\nprint "<b>$field[name] : </b> ".iif($field[''search''],"<a href=\\"search.php?op=songs&field_id=$field[id]&keyword=".$value."\\">").$value.iif($field[''search''],"</a>")."&nbsp";\r\n}\r\n} \r\n//-------------------------------------\r\n\r\nprint "</td>";\r\n\r\nif($data_singer[''name''] && !$no_singer_name){\r\nprint "<td width=''40%''>".print_link($data_singer[''name''],singer_url($data_singer[''id''],$data_singer[''page_name''],$data_singer[''name'']))."</td>";\r\n}\r\n\r\n\r\nforeach($urls_sets as $set_value){\r\n\r\n//------ int listen ---------------//\r\nif($set_value[''show_listen'']){\r\nif($data["url_".$set_value[''id'']]){\r\nprint "<td align=center width=20><a href=\\"".str_replace(array(''{cat}'',''{id}''),array($set_value[''id''],$data[''id'']),$links[''song_listen''])."\\"".iif($set_value[''listen_type'']==1," onClick=\\"return listen($data[id],$set_value[id]);\\"")."><img src=''".get_image($set_value[''listen_icon''],''images/listen.gif'')."'' title=\\"".str_replace("{listens}",$data["listens_".$set_value[''id'']],$set_value[''listen_alt''])."\\" border=0></a></td>";\r\n}else{\r\nprint "<td></td>";\r\n}\r\n}\r\n\r\n//----------- ext listen --------//\r\n\r\nif($set_value[''show_ext_listen'']){\r\nif($data["url_".$set_value[''id'']]){\r\nprint "<td align=center width=20><a href=\\"".str_replace(array(''{cat}'',''{id}''),array($set_value[''id''],$data[''id'']),$links[''song_ext_listen''])."\\"><img src=''".get_image($set_value[''ext_listen_icon''],''images/listen.gif'')."'' title=\\"".str_replace("{listens}",$data["listens_".$set_value[''id'']],$set_value[''ext_listen_alt''])."\\" border=0></a></td>";\r\n}else{\r\nprint "<td></td>";\r\n}\r\n}\r\n\r\n//------------ download ---------//\r\nif($set_value[''show_download'']){\r\nif($data["url_".$set_value[''id'']]){\r\n print "<td align=center width=20><a href=\\"".str_replace(array(''{cat}'',''{id}''),array($set_value[''id''],$data[''id'']),$links[''song_download''])."\\"><img src=''".get_image($set_value[''download_icon''],''images/save.gif'')."'' title=\\"".str_replace("{downloads}",$data["downloads_".$set_value[''id'']],$set_value[''download_alt''])."\\" border=0></a></td>";\r\n}else{\r\nprint "<td></td>";\r\n}\r\n}\r\n}\r\n\r\n//-------- video ---------//\r\n\r\nif(CFN != "singer_overview.php"){\r\n\r\nif($data[''video_id'']){\r\nprint "<td align=''center'' width=20><a href=\\"".str_replace("{id}",$data[''video_id''],$links[''video_watch''])."\\"><img src=''$style[images]/video.gif'' title=\\"$phrases[video] $data[name]\\" border=0></a></td>";\r\n}else{\r\nif($videos_count){\r\nprint "<td width=20 align=''center''><img src=''$style[images]/video_disabled.gif''></td>";\r\n}\r\n}\r\n\r\n//------- vote -----------//\r\nif($settings[''vote_song'']){\r\n print "<td align=center width=20><a href=\\"javascript:vote(''$data[id]'',''song'')\\"><img src=''images/vote_song.gif'' title=''$phrases[vote_song]'' border=0></a></td>    ";\r\n         \r\n}\r\n\r\n\r\n//-------- send -----------//\r\nif($settings[''snd2friend'']){\r\n print "<td align=center width=20><a href=\\"javascript:send($data[id],''song'')\\" title=''$phrases[send2friend]''><img src=''images/snd.gif'' alt=''$phrases[send2friend]'' border=0></a></td>    ";\r\n         }\r\n\r\n\r\n//-------- share ----------//\r\nprint "<td align=center width=20><a href=''http://www.facebook.com/sharer.php?u=".urlencode($scripturl."/".str_replace(array(''{cat}'',''{id}''),array(1,$data[''id'']),$links[''song_listen'']))."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook.gif'' alt=''Share it on Facebook'' border=0></a></td>";\r\n}\r\n\r\n\r\n//-------- playlist ----------//\r\nprint "<td align=center width=20><a href=\\"javascript:;\\" onClick=\\"".iif($is_member && !$is_user_cp , "playlist_add_song($data[id]);","alert(''$phrases[please_login_first]'');")."\\" title=''$phrases[add_to_playlist]''><img src=''images/playlist_add.gif'' title=''$phrases[add_to_playlist]'' border=0></a></td>";\r\n\r\n\r\n\r\n//----------- lyrics -----------//\r\nif($data[''lyrics'']){\r\nprint" <td align=center width=20><a href=''lyrics-$data[id].html'' title=''$phrases[lyrics]''><img src=''images/lyric.gif'' title=''$phrases[lyrics]'' border=0></a></td>";\r\n}else{\r\nif($lyrics_count > 0){\r\nprint "<td width=20></td>";\r\n}\r\n}\r\n\r\n\r\nprint "</tr></table></div>";\r\n\r\n?>   ', 1, 1, 0),
(42, 'Fonts &amp; Colors', 'CSS', '/*------------ BODY ---------------*/\r\n\r\nBODY {\r\nFONT-SIZE: 8pt; \r\nCOLOR: #1266a5;\r\nFONT-FAMILY: Tahoma; \r\n\r\nmargin-top: 0px;\r\nmargin-right: 0px;\r\nmargin-bottom: 0px;\r\nmargin-left: 0px;\r\n}\r\n\r\n.header {\r\nheight:150px;\r\nwidth:100%px;\r\nbackground-image: url(''images/header_bg.jpg'');\r\n\r\ntext-align: right;\r\nclear:both;\r\n  border:1px solid #e7e7e7;\r\n  -moz-border-radius:5px;\r\n  -webkit-border-radius:5px;\r\n  -o-border-radius:5px;\r\n  border-radius:5px;\r\n}\r\n\r\n.footer {\r\nheight:40px;\r\nwidth:100%px;\r\n\r\nclear:both;\r\n  background:#f6f6f6;\r\n  padding:3em 3em 3em;\r\n  border:1px solid #e7e7e7;\r\n  -moz-border-radius:5px;\r\n  -webkit-border-radius:5px;\r\n  -o-border-radius:5px;\r\n  border-radius:5px;\r\ndirection:ltr;\r\n}\r\n\r\n.block_div {\r\n  clear:both;\r\n  background:#f6f6f6;\r\n  padding:1em 1em 1em;\r\n  border:1px solid #e7e7e7;\r\n  -moz-border-radius:5px;\r\n  -webkit-border-radius:5px;\r\n  -o-border-radius:5px;\r\n  border-radius:5px;\r\ntext-align: left;\r\ndirection:ltr;\r\n\r\n\r\n}\r\n\r\n\r\nimg { \r\nborder: 0px; \r\n}\r\n\r\nfieldset {\r\n	border:  1px solid #e7e7e7;padding: 2;\r\n	\r\n}\r\n\r\n\r\n\r\n\r\n\r\nselect{\r\nborder:1px solid #dcdcdc;border:1px solid rgba(0, 0, 0, 0.1);color:#666;cursor:pointer;min-height:25px;font-family:inherit;}\r\n\r\n\r\n\r\n\r\ninput[type="submit"]{\r\nbackground-image:-webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#f1f1f1));background-image:-webkit-linear-gradient(top,#f5f5f5,#f1f1f1);-webkit-border-radius:2px;-webkit-user-select:none;background-color:#f5f5f5;background-image:linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-o-linear-gradient(top,#f5f5f5,#f1f1f1);border:1px solid #dcdcdc;border:1px solid rgba(0, 0, 0, 0.1);border-radius:2px;color:#666;cursor:pointer;line-height:27px;margin:11px 6px;min-width:54px;padding:0 8px;text-align:center}\r\n\r\ninput[type="submit"]:hover{background-image:-webkit-gradient(linear,left top,left bottom,from(#f8f8f8),to(#f1f1f1));background-image:-webkit-linear-gradient(top,#f8f8f8,#f1f1f1);-webkit-box-shadow:0 1px 1px rgba(0,0,0,0.1);background-color:#f8f8f8;background-image:linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-o-linear-gradient(top,#f8f8f8,#f1f1f1);border:1px solid #c6c6c6;box-shadow:0 1px 1px rgba(0,0,0,0.1);color:#333}\r\n\r\ninput[type="submit"]:focus{border:1px solid #4d90fe;outline:none}\r\n\r\n\r\ninput[type="button"]{\r\nbackground-image:-webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#f1f1f1));background-image:-webkit-linear-gradient(top,#f5f5f5,#f1f1f1);-webkit-border-radius:2px;-webkit-user-select:none;background-color:#f5f5f5;background-image:linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-o-linear-gradient(top,#f5f5f5,#f1f1f1);border:1px solid #dcdcdc;border:1px solid rgba(0, 0, 0, 0.1);border-radius:2px;color:#666;cursor:pointer;line-height:20px;min-width:54px;padding:0 8px;text-align:center}\r\n\r\ninput[type="button"]:hover{background-image:-webkit-gradient(linear,left top,left bottom,from(#f8f8f8),to(#f1f1f1));background-image:-webkit-linear-gradient(top,#f8f8f8,#f1f1f1);-webkit-box-shadow:0 1px 1px rgba(0,0,0,0.1);background-color:#f8f8f8;background-image:linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-o-linear-gradient(top,#f8f8f8,#f1f1f1);border:1px solid #c6c6c6;box-shadow:0 1px 1px rgba(0,0,0,0.1);color:#333}\r\n\r\ninput[type="button"]:focus{border:1px solid #4d90fe;outline:none}\r\n\r\n\r\ninput{font-family:inherit} \r\n\r\n\r\n\r\n.singer_btn{\r\nbackground-image:-webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#f1f1f1));\r\nbackground-image:-webkit-linear-gradient(top,#f5f5f5,#f1f1f1);-webkit-border-radius:2px;-webkit-user-select:none;\r\nbackground-color:#f5f5f5;\r\nbackground-image:linear-gradient(top,#f5f5f5,#f1f1f1);\r\nbackground-image:-o-linear-gradient(top,#f5f5f5,#f1f1f1);\r\nborder:1px solid #dcdcdc;border:1px solid rgba(0, 0, 0, 0.1);\r\nborder-radius:2px;color:#666;line-height:27px;\r\nmargin:6px 6px;\r\nmin-width:200px;padding:0 8px;\r\nwidth:200px;\r\ntext-align:center\r\n}\r\n\r\n\r\n\r\n/*---------- TITLES FONT --------------*/\r\n.title {\r\nFONT-SIZE: 10pt; COLOR: #78a71e; TEXT-DECORATION: none; font-weight:bold;text-align: center;align: center;\r\n}\r\n\r\n\r\n.block_title{\r\n\r\n}\r\n\r\n.table_title{\r\n}\r\n\r\n\r\n/*------------- LINKS ---------------*/\r\nA:link {\r\n	 COLOR: #0066CC;TEXT-DECORATION: none;\r\n}\r\n\r\n\r\nA:active {\r\n	COLOR: #0066CC;TEXT-DECORATION: none;\r\n\r\n}\r\nA:visited {\r\n	COLOR: #0066CC;TEXT-DECORATION: none; \r\n}\r\nA:hover {\r\n	COLOR: #007CF9;TEXT-DECORATION: none; \r\n}\r\n\r\n.big {\r\nFONT-SIZE: 10pt; weight:bold;COLOR: #0066CC; TEXT-DECORATION: none;\r\n}\r\n/*---------- LETTERS LINKS -----------*/\r\nA:link.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; TEXT-DECORATION: none;\r\n}\r\n\r\n\r\nA:active.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; TEXT-DECORATION: none;\r\n\r\n}\r\nA:visited.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; TEXT-DECORATION: none;\r\n}\r\nA:hover.big {\r\n	FONT-SIZE: 10pt; COLOR: #007CF9;TEXT-DECORATION: none;\r\n}\r\n\r\n/*----------- PATH BAR LINKS ------------*/\r\nA:link.path_link {\r\n	COLOR: #0066CC; TEXT-DECORATION: none;\r\n}\r\nA:active.path_link {\r\n	COLOR: #0066CC; TEXT-DECORATION: none;\r\n\r\n}\r\nA:visited.path_link {\r\n	COLOR: #0066CC; TEXT-DECORATION: none;\r\n}\r\nA:hover.path_link {\r\n	COLOR: #007CF9; TEXT-DECORATION: none;\r\n}\r\n\r\n\r\n/*---------- SONGS TABLES COLORS ---------*/\r\n.row_1{\r\nbackground-color: #f7f7f7;\r\n\r\n}\r\n\r\n\r\n.row_2{\r\nbackground-color: #FCFCFC ;\r\n}\r\n\r\n.row_1:hover{\r\nbackground-color: #E8F8FF;\r\n}\r\n\r\n.row_2:hover{\r\nbackground-color: #E8F8FF;\r\n}\r\n\r\n\r\n/*--------- MEMBERS MESSAGES FONT--------*/\r\n.messages {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\n/*------------ SPARATE LINKE -----------------*/\r\n.separate_line{\r\nborder-width: 1px 0 0 0; border-style: solid; border-color: #e7e7e7;\r\n}\r\n/*------------ Search Replace-----------------*/\r\n.search_replace{\r\ncolor: #FF0000;\r\n}\r\n\r\n\r\n/* --------- Slider ---------------*/\r\n\r\n.slider_active {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-width: 1px;\r\n	border-style: solid;\r\n	background-color: #fff;\r\n	color: #000;\r\n	float: left;\r\n	\r\n	cursor: default;\r\n	font-weight: bold;\r\n\r\nmargin: 0 5px; \r\nheight:15;\r\npadding: 3px 5px;\r\n\r\n	font-size: 10pt;\r\n	text-align: center;\r\n	background-image:url(''images/tabs_shade.gif'')\r\n}\r\n\r\n.slider_inactive {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 1px;\r\n	background-color: #ddd;\r\n	color: #777;\r\n	float: left;\r\n        cursor:pointer;\r\n	cursor: hand;\r\n       \r\n\r\nmargin: 0 5px; \r\nheight:15;\r\npadding: 3px 5px;\r\n\r\n	font-size: 10pt;\r\n	text-align: center;\r\n}\r\n\r\n\r\n\r\n\r\n.slider_btnz{\r\ncursor: hand;\r\nwidth:25;\r\n}\r\n\r\n//-------- pop Dialog ---------------\r\n\r\n.boxy-wrapper { position: absolute; left: 50%;\r\n  top: 50%;}\r\n\r\n.boxy-wrapper.fixed { position: fixed;  }\r\n\r\n  /* Modal */\r\n  \r\n  .boxy-modal-blackout { position: absolute; background-color: black; left: 0; top: 0; }\r\n  \r\n  /* Border */\r\n\r\n  .boxy-wrapper { empty-cells: show; }\r\n    .boxy-wrapper .top-left,\r\n    .boxy-wrapper .top-right,\r\n    .boxy-wrapper .bottom-right,\r\n    .boxy-wrapper .bottom-left { width: 10px; height: 10px; padding: 0 ;background-color: black;opacity: 0.6; filter: alpha(opacity=60);}\r\n    \r\n    \r\n	.boxy-wrapper .top,\r\n	.boxy-wrapper .bottom { height: 10px; background-color: black; opacity: 0.6; filter: alpha(opacity=60); padding: 0 }\r\n	\r\n	.boxy-wrapper .left,\r\n	.boxy-wrapper .right { width: 10px; background-color: black; opacity: 0.6; filter: alpha(opacity=60); padding: 0 }\r\n	\r\n	/* Title bar */\r\n	\r\n	.boxy-wrapper .title-bar { background-color: black; padding: 6px; position: relative; text-align:center; }\r\n	  .boxy-wrapper .title-bar.dragging { cursor: move; }\r\n	    .boxy-wrapper .title-bar h2 { font-size: 12px; color: white; line-height: 1; margin: 0; padding: 0; font-weight: normal; }\r\n	    .boxy-wrapper .title-bar .close { color: white; position: absolute; top: 6px; right: 6px; font-size: 90%; line-height: 1; }\r\n		\r\n	/* Content Region */\r\n	\r\n	.boxy-inner { background-color: #FFFFFF; padding: 0 }\r\n	.boxy-content { padding: 15px; }\r\n	\r\n	/* Question Boxes */\r\n\r\n    .boxy-wrapper .question { width: 350px; min-height: 80px; }\r\n    .boxy-wrapper .answers { text-align: left; }\r\n\r\n/*------- Playlist --------------*/\r\n.pl_song_play {\r\n    \r\n    background-image: url("images/play.png");\r\n    background-repeat:no-repeat;\r\n    background-position:right top;\r\n    padding-right:30px;\r\n    height: 20px;\r\n    background-color:#C0C0C0;\r\n    cursor:pointer;\r\n}\r\n.pl_song_stop {\r\n    padding-right:30px;\r\n    height: 20px;\r\n    background-color:#ffffff;\r\n    cursor:pointer;\r\n}\r\n\r\n\r\n/*------------ Pages ------------- */\r\n.pagenavi {\r\n	clear: both;\r\nalign:center;\r\n}\r\n\r\n.pagenavi a, .pagenavi span {\r\n	text-decoration: none;\r\n	border: 1px solid #BFBFBF;\r\n	padding: 3px 5px;\r\n	margin: 1px;\r\n}\r\n\r\n.pagenavi a:hover, .pagenavi span.current {\r\n	border-color: #000;\r\n}\r\n\r\n.pagenavi span.current {\r\n	font-weight: bold;\r\n}', 1, 1, 0),
(104, '', 'news_cats', '<?\r\nglobal $data,$links,$style;\r\n\r\nprint "<td align=center><a href=\\"".str_replace(''{cat}'',$data[''id''],$links[''browse_news''])."\\"><img src=\\"".get_image($data[''img''],"$style[images]/folder.gif")."\\" title=\\"$data[name]\\"><br>$data[name]</a></td>";\r\n\r\n\r\n?>', 1, 1, 0),
(105, '', 'news_cats_header', '<?\r\nopen_table();\r\nprint "<table width=100%><tr>";\r\n?>', 1, 1, 0),
(106, '', 'news_cats_sep', '</tr><tr>', 1, 1, 0),
(107, '', 'news_cats_footer', '<?\r\nprint "</tr></table>";\r\nclose_table();\r\n?>', 1, 1, 0),
(23, 'Page Head', 'page_head', '<?\r\nglobal $settings,$section_name,$title_sub,$sitename,$meta_keywords,$meta_description,$settings,$action,$scripturl;\r\n\r\nif(($section_name && $settings[''section_name_in_subpages'']) || $title_sub){\r\n$full_title = iif($sitename && ($settings[''sitename_in_subpages''] ||  (CFN == "index.php" && !$action)),$sitename,'''');\r\n}else{\r\n$full_title = $sitename;\r\n}\r\nif($section_name && ($settings[''section_name_in_subpages''] || (CFN == "index.php" && !$action))){\r\n$full_title .= iif($full_title," - $section_name",$section_name);\r\n}\r\n\r\nif($title_sub){\r\n$full_title .= iif($full_title," - $title_sub",$title_sub);\r\n}\r\n\r\n\r\nprint "<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\"\r\n         \\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\\">\r\n\r\n<html xmlns=\\"http://www.w3.org/1999/xhtml\\" dir=\\"$settings[html_dir]\\">\r\n\r\n<head>\r\n<base href=\\"$scripturl/\\"".iif(CFN == "listen_window.php"," target=_blank")." />\r\n\r\n<meta http-equiv=\\"Content-Type\\" content=\\"text/html; charset=$settings[site_pages_encoding]\\" />\r\n<meta http-equiv=\\"Content-Language\\" content=\\"$settings[site_pages_lang]\\" />\r\n\r\n";\r\nprint "\r\n\r\n<meta name=\\"generator\\" content=\\"Allomani Audio and Video v3.0\\" />\r\n\r\n<meta name=\\"keywords\\" content=\\"allomani,".$meta_keywords."\\" />\r\n<meta name=\\"description\\" content=\\"$meta_description\\" />\r\n\r\n<meta name=\\"robots\\" content=\\"index, follow\\" />\r\n<meta name=\\"rating\\" content=\\"General\\" /> \r\n<meta name=\\"distribution\\" content=\\"Global\\" />\r\n\r\n\r\n<link type=\\"text/css\\" rel=\\"stylesheet\\" href=\\"css.php\\" />";\r\n\r\nprint "<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Singers\\" href=\\"rss.php\\" />\r\n<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Songs\\" href=\\"rss.php?op=songs\\" />\r\n<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Albums\\" href=\\"rss.php?op=albums\\" />\r\n<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Videos\\" href=\\"rss.php?op=videos\\" />\r\n<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - News\\" href=\\"rss.php?op=news\\" />\r\n<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Photos\\" href=\\"rss.php?op=photos\\" />\r\n\r\n\r\n<title>$full_title</title>\r\n";\r\n?>\r\n<script type="text/javascript">\r\nvar scripturl="<?=$scripturl?>";\r\n</script>\r\n\r\n<script type="text/javascript" src="js/prototype.js"></script>\r\n<script type="text/javascript" src="js/javascript.js"></script>\r\n<script type=''text/javascript'' src=''js/jquery.js''></script>\r\n<script> jQuery.noConflict(); </script>\r\n<script type=''text/javascript'' src=''js/jquery.raty.min.js''></script>\r\n<?\r\n\r\nprint "<script type=''text/javascript'' src=''js/jquery.boxy.allomani.js''></script>";\r\n\r\nif(in_array(CFN,array("listen.php","listen_all.php","video_watch.php","listen_window.php"))){\r\nprint "<script type=''text/javascript'' src=''js/jwplayer.js''></script>";\r\n}\r\n?>\r\n<script type="text/javascript" src="js/scriptaculous/scriptaculous.js"></script>', 1, 1, 0),
(108, '', 'browse_news_header', '<?\r\nglobal $phrases;\r\nopen_table("$phrases[the_news]");\r\nprint "<hr class=separate_line size=\\"1\\">";    \r\n?>', 1, 1, 0),
(43, 'Browse News - Inside', 'browse_news_inside', '<?\r\nglobal $data,$phrases,$settings,$global_align,$global_align_x,$global_dir;\r\n\r\n$news_date = get_date($data[''date'']);\r\n\r\nprint "<table width=100%><tr><td>\r\n\r\n<DIV style=\\"FLOAT: $global_align_x\\"><TABLE border=\\"0\\"><TBODY><TR><TD><TABLE border=\\"0\\"><TBODY><TR><TD align=\\"center\\">\r\n<img src=''".get_image($data[''img''])."''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>$news_date</font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir=\\"$global_dir\\" align=\\"$global_align\\">\r\n$data[details] <br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font>\r\n\r\n</td></tr>\r\n<tr><td colspan=2 align=''$global_align_x''>\r\n<a href=''http://www.facebook.com/sharer.php?u=".urlencode("http://".$_SERVER[''HTTP_HOST''].$_SERVER[''REQUEST_URI''])."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook_mid.gif'' alt=''Share it on Facebook'' border=0></a>\r\n\r\n<a href=''news_print.php?id=$data[id]'' title=''$phrases[printable_copy]''><img src=''images/print.gif'' title=''$phrases[printable_copy]'' alt=''$phrases[printable_copy]'' border=0></a>\r\n\r\n</div>\r\n\r\n</td></tr></table>";\r\n\r\n\r\nprint "<br><br><center>";\r\nprint_rating(''news'',$data[''id''],$data[''rate'']);    \r\nprint "</center>";\r\n?>', 1, 1, 0),
(44, 'Browse News - Print', 'browse_news_print', '<?\r\nglobal $settings,$data,$phrases,$global_align,$global_align_x,$global_dir;\r\n\r\nprint "<html dir=\\"$settings[html_dir]\\">\r\n<head>\r\n<META http-equiv=Content-Language content=\\"$settings[site_pages_lang]\\">\r\n<META http-equiv=Content-Type content=\\"text/html; charset=$settings[site_pages_encoding]\\">\r\n<title>$data[title]</title>\r\n</head>\r\n<body>\r\n\r\n<table width=100%>\r\n<tr>\r\n<td>\r\n<p align=center><font size=5><b>$data[title]</b></font></p>\r\n</td></tr>\r\n\r\n<tr><td>\r\n\r\n<DIV style=\\"FLOAT: $global_align_x\\"><TABLE border=\\"0\\"><TBODY><TR><TD><TABLE border=\\"0\\"><TBODY><TR><TD align=\\"center\\">\r\n<img src=\\"".get_image($data[''img''])."\\">\r\n</TD></TR><TR><TD align=center><font color=''#808080''>".get_date($data[''date''])."</font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir=\\"$global_dir\\" align=\\"$global_align\\">\r\n$data[details] <br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font>\r\n</div>\r\n</td></tr>\r\n\r\n</table>   \r\n</body>\r\n</html>";\r\n?>', 1, 1, 0),
(48, 'Email Change Confirm Message', 'email_change_confirmation_msg', '<html dir=ltr>\r\n<body>\r\n\r\nHello {username} <br><br>\r\n\r\nyou have requested to change your email to this email , if you want to confirm that , click on the following URL : <br>\r\n\r\n<a href="{active_link}" target=_blank>{active_link}</a>\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1, 0),
(49, 'Password Reset Request Message', 'pwd_rest_request_msg', '<html dir=ltr>\r\n<body>\r\n\r\n{name},<br><br>\r\n\r\nYou have requested to reset your current password , to confirm click on the following url : \r\n<br>\r\n<a href="{url}" target=_blank>{url}</a>\r\n<br><br>\r\n\r\nif you didn''t request that , please ignore this message.\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}', 1, 1, 0),
(50, 'New Password Message', 'pwd_rest_done_msg', '<html dir=ltr>\r\n<body>\r\n\r\n{name},<br>\r\nYour Password Has been changed Successfully,\r\n<br><br>\r\n\r\nYour New Password : {password}\r\n\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1, 0),
(55, 'Songs Sort Bar', 'songs_orderby', '<?\r\nglobal $phrases,$data_singer,$links,$start,$orderby,$sort,$album_id,$settings;\r\n\r\n$orders = array("name"=>$phrases[''the_name''],"id"=>$phrases[''add_date''],"rate"=>$phrases[''the_most_voted''],"listens_{$settings[''default_url_id'']}"=>$phrases[''listens''],"downloads_{$settings[''default_url_id'']}"=>$phrases[''downloads'']);\r\n\r\n\r\nprint "<span class=''path''><img src=''images/sort.gif''>&nbsp;<b>$phrases[sort_by] :</b>&nbsp;&nbsp;";\r\n\r\nforeach($orders as $key=>$value){\r\n\r\nprint "<a href=''".str_replace("{start}",$start,singer_url($data_singer[''id''],$data_singer[''page_name''],$data_singer[''name''],$album_id,$key,iif($sort==''asc'' && $key==$orderby,''desc'',''asc'')))."'' class=''path_link''>".iif($orderby==$key,"<b>").$value.iif($orderby==$key,"</b>")."</a>";\r\n\r\n\r\nif($orderby==$key && $sort=="asc"){\r\nprint "<img src=''images/arr_asc_disabled.gif'' border=0 title=\\"$value $phrases[asc]\\"></a>";\r\n}else{\r\nprint "<a href=''".str_replace("{start}",$start,singer_url($data_singer[''id''],$data_singer[''page_name''],$data_singer[''name''],$album_id,$key,''asc''))."'' class=''path_link''><img src=''images/arr_asc.gif'' border=0 title=\\"$value $phrases[asc]\\"></a>";\r\n}\r\n\r\nif($orderby==$key && $sort=="desc"){\r\nprint "<img src=''images/arr_desc_disabled.gif'' border=0 title=\\"$value $phrases[desc]\\">";\r\n}else{\r\nprint "<a href=''".str_replace("{start}",$start,singer_url($data_singer[''id''],$data_singer[''page_name''],$data_singer[''name''],$album_id,$key,''desc''))."'' class=''path_link''><img src=''images/arr_desc.gif'' border=0 title=\\"$value $phrases[desc]\\"></a>";\r\n}\r\n\r\nprint "&nbsp;";\r\n\r\n}\r\n\r\n\r\nprint "</span><br><br>";\r\n\r\n?>', 1, 1, 0),
(56, 'Browse Songs - Header', 'browse_songs_header', '<?\r\nglobal $settings,$action,$urls_sets,$songs_fields_sets,$is_member,$without_tables,$phrases,$letter,$urls_sets,$songs_fields_sets,$letter;\r\n\r\n$is_member = check_member_login();\r\n\r\nif(CFN=="songs.php"){\r\n//----- sort by template ------\r\nif($settings[''visitors_can_sort_songs''] && !$letter){\r\nrun_template("songs_orderby");\r\n}\r\n//--------------------\r\n\r\n\r\nopen_table(iif($letter,$letter,""));\r\n}\r\n\r\nif($settings[''songs_multi_select''] && CFN != "singer_overview.php"){\r\nprint "<form name=''songs_form'' id=''songs_form'' action=''listen_all.php'' method=''post''>";\r\n\r\nprint "\r\n<img src=''images/find.gif''><input id=''quick_search'' onkeyup=quicksearch(this); name=''quick_search''>\r\n\r\n<a onclick=''quicksearch_clear();return false;'' href=''javascript:;'' id=''clearlnk'' style=''display:none;''><img src=''images/del_small.gif''></a><br><br>\r\n\r\n<div style=''display: none;'' id=''no_quicksearch_results'' align=center>$phrases[no_results]</div>";\r\n}\r\n                           \r\n                              ', 1, 1, 0);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`, `views`) VALUES
(57, 'Browse Songs - Footer', 'browse_songs_footer', '<?\r\nglobal $action,$global_dir,$settings,$without_tables,$phrases,$album_id,$id,$songs_limit,$songs_perpage,$page_result,$songs_start,$page_string,$letter;\r\n\r\n\r\nif($settings[''songs_multi_select''] && CFN != "singer_overview.php"){\r\nprint "\r\n\r\n<div id=''select_and_listen''>\r\n<br>\r\n<img src=''images/arrow_".$global_dir.".gif''>&nbsp;\r\n\r\n<input type=''button'' value=''$phrases[check_all]'' onclick=\\"CheckAll(''songs_form'');\\"> <input type=''button'' value=''$phrases[uncheck_all]'' onclick=\\"UncheckAll(''songs_form'');\\"> &nbsp;<img src=''images/arrow_".$global_dir."2.gif''> &nbsp;\r\n<input type=''button'' value=''$phrases[listen_to_songs]''  onclick=\\"\\$(''songs_form'').submit();\\">\r\n</div>\r\n\r\n</form>";\r\n}\r\n\r\nif(CFN=="songs.php"){\r\nclose_table();\r\n}\r\n\r\n//---- pages links ------\r\nif(CFN=="songs.php"){  \r\nprint_pages_links($songs_start,$page_result[''count''],$songs_perpage,$page_string); \r\n}\r\n\r\n\r\nif(CFN=="songs.php" && !$letter){\r\n\r\nif($album_id > 0 && (string)$album_id != "all"){\r\n\r\nif($settings[''enable_album_comments'']){\r\n    open_table($phrases[''members_comments'']);\r\n    get_comments_box(''album'',$album_id);\r\n    close_table();\r\n}\r\n\r\n\r\n}else{\r\n\r\nif($settings[''enable_singer_comments'']){\r\n    open_table($phrases[''members_comments'']);\r\n    get_comments_box(''singer'',$id);\r\n    close_table();\r\n}\r\n\r\n}\r\n}\r\n\r\n?>', 1, 1, 0),
(112, '', 'browse_videos_cats_header', '<?\r\nopen_table();\r\nprint "<table width=100%><tr>";\r\n?>', 1, 1, 0),
(113, '', 'browse_videos_cats_sep', '</tr><tr>', 1, 1, 0),
(114, '', 'browse_videos_cats', '<?\r\nglobal $links,$data;\r\n\r\nprint "<td align=center><a href=\\"".str_replace(''{id}'',$data[''id''],$links[''browse_videos''])."\\" title=\\"$data[name]\\"><img src=\\"".get_image($data[''img''],"images/folder.gif")."\\" alt=\\"$data[name]\\"><br>$data[name]</td>";\r\n?>\r\n', 1, 1, 0),
(115, '', 'browse_videos_cats_footer', '</tr></table>', 1, 1, 0),
(116, '', 'browse_videos_footer', '<?\r\nprint "</tr></table></center>";\r\nif(CFN == "videos.php"){\r\nclose_table();\r\n}\r\n?>', 1, 1, 0),
(117, '', 'browse_videos_sep', '</tr><tr>', 1, 1, 0),
(118, '', 'browse_videos_header', '<?\r\nglobal $data_cat;\r\nif(CFN == "videos.php"){\r\nopen_table($data_cat[''name'']);\r\n}\r\n\r\nprint "<center><table width=100%>" ;\r\n?>', 1, 1, 0),
(119, 'Letters', 'letters', '<?\r\nglobal $settings,$phrases,$action;\r\n\r\nif((CFN=="index.php" && !$action) || CFN=="songs.php" || CFN=="browse.php" || CFN=="singer_overview.php"){\r\n\r\n\r\nif($settings[''letters_songs''] || $settings[''letters_singers'']){\r\n open_table();\r\n if($settings[''letters_songs''] && $settings[''letters_singers'']){\r\n print "<table width=100%><tr><td>  $phrases[the_singers] : </td><td align=center>";\r\n        print_letters_singers();\r\n        print "</td></tr><tr><td>  $phrases[the_songs] : </td><td align=center>";\r\n        print_letters_songs();\r\n        print "</td></tr></table>";\r\n         }else{\r\n    if($settings[''letters_songs'']){\r\nprint "<p align=center>";\r\n            print_letters_songs();\r\nprint "</p>";\r\n            }\r\n        if($settings[''letters_singers'']){\r\nprint "<p align=center>";\r\n            print_letters_singers();\r\nprint "</p>";\r\n            }\r\n  }\r\n close_table();\r\n\r\n        }\r\n\r\n}\r\n?>', 1, 1, 0),
(124, 'Song Listen Page', 'song_listen', '<?\r\nglobal $id,$cat,$data,$url,$settings,$phrases,$data_singer,$scripturl,$links,$no_singer_name,$without_tables,$style,$global_align_x,$data_video;\r\n\r\n$is_member = check_member_login();\r\n\r\n\r\nopen_table($data[''name'']);\r\n\r\n\r\nrun_player($url);\r\n\r\n\r\n print "<center><br><br>\r\n\r\n<table><tr>\r\n<td align=center>\r\n<a href=\\"".$scripturl."/".str_replace(array(''{cat}'',''{id}''),array($cat,$id),$links[''song_download''])."\\" title=\\"$phrases[download]\\"><img src=\\"$style[images]/save_mid.gif\\" alt=\\"$phrases[download]\\"></a>\r\n</td>\r\n\r\n<td align=center>\r\n<a href=''http://www.facebook.com/sharer.php?u=".urlencode($scripturl."/".str_replace(array(''{cat}'',''{id}''),array($cat,$data[''id'']),$links[''song_listen'']))."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook_mid.gif'' alt=''Share it on Facebook'' border=0></a>\r\n</td>";\r\n\r\nif($settings[''snd2friend'']){\r\n print "<td align=center><a href=\\"javascript:send($data[id])\\" title=''$phrases[send2friend]''><img src=''images/send_mid.gif'' alt=''$phrases[send2friend]'' border=0></a></td>    ";\r\n}\r\n\r\n//-------- playlist ----------//\r\nprint "<td align=center><a href=\\"javascript:;\\" onClick=\\"".iif($is_member, "playlist_add_song($data[id]);","alert(''$phrases[please_login_first]'');")."\\" title=''$phrases[add_to_playlist]''><img src=''images/playlist_add_mid.gif'' title=''$phrases[add_to_playlist]'' border=0></a></td>";\r\n\r\n//----------- report -------\r\nif($settings[''reports_enabled'']){\r\nprint "<td align=center>\r\n<a href=\\"javascript:;\\" onClick=\\"report($data[id],''song'');\\"><img src=\\"$style[images]/report.gif\\" title=\\"$phrases[report_do]\\" border=0></a>\r\n</td>";  \r\n}\r\n//-------------------------\r\n\r\n\r\nprint "\r\n</tr></table>\r\n\r\n</center>";\r\n \r\n//------- rating -----------\r\nprint "<br><br><center>";\r\nprint_rating(''song'',$data[''id''],$data[''rate'']);    \r\nprint "</center>";\r\n \r\n//----------------------------\r\n\r\n\r\n   print "<br>\r\n        <img src=''$style[images]/add_date.gif''> &nbsp; <b>$phrases[add_date] : </b>".get_date($data[''date''])."<br>";\r\n        print "<img src=''$style[images]/views.gif''> &nbsp; <b>$phrases[listens] : </b>".$data["listens_{$cat}"]; \r\n\r\nif($data[''video_id'']){\r\n print "<br><img src=''$style[images]/video.gif''> &nbsp; <b>$phrases[video] : </b> <a href=\\"".str_replace(''{id}'',$data[''video_id''],$links[''video_watch''])."\\">$data_video[name]</a>"; \r\n}\r\n\r\n\r\n ?>\r\n <br>\r\n       <br> \r\n        <table width=100%>        \r\n       <TBODY>\r\n<TR>\r\n<TD class=box2 width="100%">\r\n<TABLE dir=rtl border=0 cellSpacing=0 cellPadding=2 width="100%">\r\n<TBODY>\r\n<TR>\r\n<TD class=000 width="100%"><STRONG><FONT color=#cc6600> Share it on Forums </TD></TR>\r\n<FORM id=embedFormvb name=embedFormvb action="">\r\n<TR>\r\n<TD width="100%"><TEXTAREA style="BORDER-BOTTOM: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; FONT-FAMILY: Tahoma; FONT-SIZE: 8pt; BORDER-TOP: #c0c0c0 1px solid; BORDER-RIGHT: #c0c0c0 1px solid" dir=ltr id=embed_code onclick=javascript:document.embedFormvb.embed_code.focus();document.embedFormvb.embed_code.select(); cols=55 name=embed_code>\r\n<?\r\nprint "[URL=".$scripturl."/".str_replace(array(''{cat}'',''{id}''),array($cat,$id),$links[''song_listen''])."]\r\n[img]".iif(!strchr($data_singer[''img''],"http://"),$scripturl."/".get_image($data_singer[''img'']),$data_singer[''img''])."[/img]\r\n[COLOR=\\"Red\\"][B] $data_singer[name] - $data_song[name] [/B][/COLOR][/URL]\r\n[URL=$scripturl][SIZE=\\"1\\"][FONT=\\"Tahoma\\"]".$sitename."[/FONT][/SIZE][/URL]</TEXTAREA> </TD></TR></FORM></TBODY></TABLE></TD></TR>";\r\n?>\r\n<TR>\r\n<TD class=box2 width="100%">\r\n<TABLE dir=rtl border=0 cellSpacing=0 cellPadding=2 width="100%">\r\n<TBODY>\r\n<TR>\r\n<TD class=000 width="100%"><STRONG><FONT color=#cc6600>Share it on Blogs </TD></TR>\r\n<FORM id=embedFormmsn name=embedFormmsn action="">\r\n<TR>\r\n<TD width="100%"><TEXTAREA style="BORDER-BOTTOM: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; FONT-FAMILY: Tahoma; FONT-SIZE: 8pt; BORDER-TOP: #c0c0c0 1px solid; BORDER-RIGHT: #c0c0c0 1px solid" dir=ltr id=embed_code onclick=javascript:document.embedFormmsn.embed_code.focus();document.embedFormmsn.embed_code.select(); cols=55 name=embed_code>\r\n<?\r\n\r\nprint $scripturl."/".str_replace(array(''{cat}'',''{id}''),array($cat,$id),$links[''song_listen'']);\r\n?>\r\n</textarea> </TD></TR></FORM></TBODY></TABLE></TD></TR></TBODY>\r\n</table>\r\n<?\r\n\r\n\r\n\r\nclose_table();\r\n\r\n//----------- another songs ---------------\r\nif(CFN != "listen_window.php"){\r\n$without_tables = ture;\r\nopen_table("$phrases[another_songs]");\r\n$no_singer_name=true;\r\nsongs_table($data[''album''],$data[''album_id''],"","name","asc",0,20);\r\nclose_table();\r\n}\r\n//------ Comments -------------------\r\nif($settings[''enable_songs_comments'']){\r\n    open_table($phrases[''members_comments'']);\r\n    get_comments_box(''song'',$id);\r\n    close_table();\r\n}\r\n?>', 1, 1, 0),
(128, 'Prev. and Next Song', 'prev_next_song', '<?\r\nglobal $phrases,$data_prev,$data_next,$links,$settings;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=left>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_song] : <a href=\\"".str_replace(array(''{cat}'',''{id}''),array($settings[''default_url_id''],$data_prev[''id'']),$links[''song_listen''])."\\" title=\\"$data_prev[name]\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=right>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_song] : <a href=\\"".str_replace(array(''{cat}'',''{id}''),array($settings[''default_url_id''],$data_next[''id'']),$links[''song_listen''])."\\" title=\\"$data_next[name]\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(127, 'Prev. and Next Singer', 'prev_next_singer', '<?\r\nglobal $phrases,$data_prev,$data_next;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=left>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_singer] : <a href=\\"".singer_url($data_prev[''id''],$data_prev[''page_name''],$data_prev[''name''])."\\" title=\\"$data_prev[name]\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=right>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_singer] : <a href=\\"".singer_url($data_next[''id''],$data_next[''page_name''],$data_next[''name''])."\\" title=\\"$data_next[name]\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(129, 'Prev. and Next Video', 'prev_next_video', '<?\r\nglobal $phrases,$data_prev,$data_next,$links;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=left>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_video] : <a href=\\"".str_replace(''{id}'',$data_prev[''id''],$links[''video_watch''])."\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=right>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_video] : <a href=\\"".str_replace(''{id}'',$data_next[''id''],$links[''video_watch''])."\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(130, 'Prev. and Next Category', 'prev_next_cat', '<?\r\nglobal $phrases,$data_prev,$data_next;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=left>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_cat] : <a href=\\"".cat_url($data_prev[''id''],$data_prev[''page_name''],$data_prev[''name''])."\\" title=\\"$data_prev[name]\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=right>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_cat] : <a href=\\"".cat_url($data_next[''id''],$data_next[''page_name''],$data_next[''name''])."\\" title=\\"$data_next[name]\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(131, 'Prev. and Next Video', 'prev_next_video_cat', '<?\r\nglobal $phrases,$data_prev,$data_next,$links;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=left>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_cat] : <a href=\\"".str_replace(''{id}'',$data_prev[''id''],$links[''browse_videos''])."\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=right>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_cat] : <a href=\\"".str_replace(''{id}'',$data_next[''id''],$links[''browse_videos''])."\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(132, 'Prev. and Next Album', 'prev_next_album', '<?\r\nglobal $phrases,$data_prev,$data_next,$data_singer;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=left>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_album] : <a href=\\"".album_url($data_prev[''id''],$data_prev[''page_name''],$data_prev[''name''],$data_singer[''id''],$data_singer[''page_name''],$data_singer[''name''])."\\" title=\\"$data_prev[name]\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=right>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_album] : <a href=\\"".album_url($data_next[''id''],$data_next[''page_name''],$data_next[''name''],$data_singer[''id''],$data_singer[''page_name''],$data_singer[''name''])."\\" title=\\"$data_next[name]\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(133, 'Pages Links', 'pages_links', '<?\r\nglobal $f_page_string,$nextpag,$prevpag,$f_items_perpage,$f_start,$start,$phrases,$f_pages,$f_end,$f_cur_page;\r\n\r\n\r\nprint "<center>\r\n<div class=''pagenavi''> <span class=''page''>$phrases[pages] : </span> ";\r\n\r\n//----- first and prev -----//\r\nif($start >0){\r\nprint "<a title=\\"$phrases[first_page]\\"  href=''".str_replace("{start}",0,$f_page_string)."'' class=''first''><<</a> \\n";\r\n\r\n$previouspage = $start - $f_items_perpage;\r\nprint "<a title=\\"$phrases[prev_page]\\" href=''".str_replace("{start}",$previouspage,$f_page_string)."'' class=''prev''><</a>\\n";\r\n}\r\n\r\n\r\n//----- pages loop -------//\r\nfor ($i = $f_start; $i <= $f_end; $i++) {\r\n$nextpag = $f_items_perpage*($i-1);\r\nif ($nextpag == $start){\r\nprint "<span class=''current''>$i</span>&nbsp;\\n";\r\n}else{\r\nprint "<a href=''".str_replace("{start}",$nextpag,$f_page_string)."'' class=''page''>$i</a>&nbsp;\\n";\r\n}\r\n}\r\n//----- loop end --------//\r\n\r\n\r\nif (! ( ($start/$f_items_perpage) == ($f_pages - 1) ) && ($f_pages != 1) ){\r\n$last_pag = ($f_pages-1)*$f_items_perpage;\r\n$nextpag = $start+$f_items_perpage; \r\n\r\n  \r\n//----- extend and last page num -----//\r\n\r\nif($f_end < $f_pages){  \r\nprint " <span class=''extend''>...</span> <a href=''".str_replace("{start}",$last_pag,$f_page_string)."'' class=''page''>$f_pages</a>\\n";\r\n}\r\n\r\n//------ next and last -------//\r\nprint "<a title=\\"$phrases[next_page]\\" href=''".str_replace("{start}",$nextpag,$f_page_string)."'' class=''next''>></a>\\n";\r\n\r\n\r\nprint "  <a title=\\"$phrases[last_page]\\" href=''".str_replace("{start}",$last_pag,$f_page_string)."'' class=''last''>>></a>\\n";\r\n\r\n}\r\nprint "</div><br>\r\n</center>";\r\n?>', 1, 1, 0),
(134, 'Contact us Message', 'contactus_msg', '<html>\r\n<body>\r\n\r\nSender Name : {name} <br>\r\nSender Email : {email} <br><br>\r\n\r\n----------------------------------<br><br>\r\n\r\n{message}\r\n\r\n<br><br>\r\n\r\n---------------------------------\r\n\r\n</body>\r\n</html>', 1, 1, 0),
(135, '', 'no_title_no_border', '{content}', 0, 1, 0),
(136, 'Photo View', 'photo_view', '<?\r\nglobal $data,$global_align,$global_align_x,$list,$prev_index,$next_index,$phrases,$in_this_photo,$style,$links;\r\n\r\n\r\n print "<table width=100%><tr>\r\n       <td width=''33%'' align=''$global_align''>";\r\n       \r\n       if($list[$prev_index][''id'']){ \r\n      \r\n       print "<a href=\\"".str_replace("{id}",$list[$prev_index][''id''],$links[''singer_photo''])."\\"><img src=\\"images/arrw_$global_align.gif\\" title=\\"$phrases[prev_photo]\\" border=0><br>\r\n       $phrases[prev_photo]</a>";\r\n       }\r\n       \r\n       print "</td>\r\n       <td width=''33%'' align=''center''><a href=\\"$data[img]\\" target=_blank>\r\n       <img src=\\"images/full_size.gif\\" title=\\"$phrases[full_photo_size]\\"><br>$phrases[full_photo_size]</a></td>  \r\n       <td width=''33%'' align=''$global_align_x''>";\r\n    \r\n     if($list[$next_index][''id'']){ \r\n      $next_url = str_replace("{id}",$list[$next_index][''id''],$links[''singer_photo'']); \r\n       print "<a href=\\"".$next_url."\\"><img src=\\"images/arrw_".$global_align_x.".gif\\" title=\\"$phrases[next_photo]\\" border=0><br>\r\n       $phrases[next_photo]</a>";\r\n     }else{\r\n        $next_url = str_replace("{id}",$list[0][''id''],$links[''singer_photo'']);\r\n       }\r\n     \r\n       print "</td>  \r\n       </tr></table><br><br>";\r\n       \r\n \r\n         print "<center><a href=\\"javascript:;\\" onClick=\\"window.location=scripturl+''/$next_url'';\\"><img src=\\"$data[img_resized]\\" title=\\"$data[name]\\" border=0></a><br><br>";\r\n       print_rating(''singer_photo'',$data[''id''],$data[''rate'']);\r\n       print "</center>";\r\n       \r\n       \r\n       print iif($data[''name''],"<br><br> <img src=''$style[images]/info.gif''> &nbsp; $data[name]");\r\n       \r\n       print "<br>\r\n        <img src=''$style[images]/add_date.gif''> &nbsp; <b>$phrases[add_date] : </b>".get_date($data[''date''])."<br>";\r\n        print "<img src=''$style[images]/views.gif''> &nbsp; <b>$phrases[views] : </b>$data[views]"; \r\n        \r\n        \r\n        \r\n      \r\n        \r\n      \r\n         print iif($in_this_photo,"<br><br> <img src=''$style[images]/in_this_photo.gif''> &nbsp; <b>$phrases[in_this_photo] : </b> $in_this_photo");     \r\n      //--------------------------//   \r\n         \r\n       print "<br><br>\r\n\r\n<div align=''$global_align_x''>\r\n<a href=''http://www.facebook.com/sharer.php?u=".urlencode("http://".$_SERVER[''HTTP_HOST''].$_SERVER[''REQUEST_URI''])."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook_mid.gif'' alt=''Share it on Facebook'' border=0></a>\r\n</div>";\r\n?>', 1, 1, 0),
(137, 'New PM Notify Message', 'pm_email_notify_msg', '<html dir="ltr">\r\n<body>\r\n\r\n<div align=left>\r\n\r\nHello, <br>\r\n\r\nYou Have Received a new Message from {name_from} <br><br>\r\n\r\nTo View the message , please visit the following url <br>\r\n\r\n<a href="{url}" target=_blank>{url}</a> <br>\r\n\r\n</div>\r\n</body>\r\n</html>', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `songs_templates_cats`
--

CREATE TABLE IF NOT EXISTS `songs_templates_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `selectable` int(11) NOT NULL DEFAULT '0',
  `images` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `songs_templates_cats`
--

INSERT INTO `songs_templates_cats` (`id`, `name`, `selectable`, `images`) VALUES
(1, 'Default Style', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `songs_urls_fields`
--

CREATE TABLE IF NOT EXISTS `songs_urls_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `download_icon` varchar(255) NOT NULL,
  `listen_icon` varchar(255) NOT NULL,
  `show_listen` int(1) NOT NULL DEFAULT '0',
  `show_download` int(1) NOT NULL DEFAULT '0',
  `ord` int(11) NOT NULL DEFAULT '0',
  `download_alt` varchar(100) NOT NULL,
  `listen_alt` varchar(100) NOT NULL,
  `download_for_members` int(1) NOT NULL,
  `listen_for_members` int(1) NOT NULL,
  `listen_type` int(1) NOT NULL,
  `show_ext_listen` int(1) NOT NULL,
  `ext_listen_icon` varchar(100) NOT NULL,
  `ext_listen_alt` varchar(100) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `songs_urls_fields`
--

INSERT INTO `songs_urls_fields` (`id`, `name`, `download_icon`, `listen_icon`, `show_listen`, `show_download`, `ord`, `download_alt`, `listen_alt`, `download_for_members`, `listen_for_members`, `listen_type`, `show_ext_listen`, `ext_listen_icon`, `ext_listen_alt`, `active`) VALUES
(1, 'Download URL', 'images/save.gif', 'images/listen.gif', 1, 1, 0, 'Download ({downloads} downloads)', 'Listen ({listens} listens) ', 0, 0, 0, 0, 'images/ext_listen.gif', 'External Listen ({listens} listens) ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `songs_user`
--

CREATE TABLE IF NOT EXISTS `songs_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0',
  `permisions` text NOT NULL,
  `cp_permisions` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_videos_cats`
--

CREATE TABLE IF NOT EXISTS `songs_videos_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `img` text NOT NULL,
  `cat` int(11) NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL DEFAULT '0',
  `download_limit` int(1) NOT NULL DEFAULT '0',
  `page_title` varchar(255) NOT NULL,
  `page_description` varchar(255) NOT NULL,
  `page_keywords` varchar(255) NOT NULL,
  `users` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `ord` (`ord`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_videos_data`
--

CREATE TABLE IF NOT EXISTS `songs_videos_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `downloads` int(11) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL DEFAULT '0',
  `date` int(11) NOT NULL,
  `votes` int(11) NOT NULL DEFAULT '0',
  `votes_total` int(11) NOT NULL DEFAULT '0',
  `rate` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`),
  KEY `rate` (`rate`),
  KEY `name` (`name`),
  KEY `downloads` (`downloads`),
  KEY `views` (`views`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_videos_tags`
--

CREATE TABLE IF NOT EXISTS `songs_videos_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `singer_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `singer_id` (`singer_id`),
  KEY `video_id` (`video_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_votes`
--

CREATE TABLE IF NOT EXISTS `songs_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `cnt` int(11) NOT NULL DEFAULT '0',
  `cat` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_votes_cats`
--

CREATE TABLE IF NOT EXISTS `songs_votes_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
