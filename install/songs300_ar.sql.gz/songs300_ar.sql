-- phpMyAdmin SQL Dump
-- version 3.4.3.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 31, 2012 at 01:54 PM
-- Server version: 5.0.67
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `songs300`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_best_visitors`
--

CREATE TABLE IF NOT EXISTS `info_best_visitors` (
  `time` varchar(200) NOT NULL,
  `v_count` int(11) NOT NULL default '0',
  KEY `v_count` (`v_count`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_best_visitors`
--

INSERT INTO `info_best_visitors` (`time`, `v_count`) VALUES
('20-Apr-2011 الساعة : 00:15', 2);

-- --------------------------------------------------------

--
-- Table structure for table `info_browser`
--

CREATE TABLE IF NOT EXISTS `info_browser` (
  `name` varchar(255) NOT NULL default '',
  `count` int(11) NOT NULL default '0',
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_browser`
--

INSERT INTO `info_browser` (`name`, `count`) VALUES
('Netscape', 0),
('MSIE', 0),
('Lynx', 0),
('Opera', 0),
('WebTV', 0),
('Konqueror', 0),
('Bot', 0),
('Other', 0),
('Nokia', 0),
('Android', 0),
('iPhone', 0),
('iPod', 0),
('BlackBerry', 0),
('Firefox', 0),
('Chrome', 14);

-- --------------------------------------------------------

--
-- Table structure for table `info_hits`
--

CREATE TABLE IF NOT EXISTS `info_hits` (
  `date` varchar(12) NOT NULL default '',
  `hits` int(11) NOT NULL default '0',
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_hits`
--

INSERT INTO `info_hits` (`date`, `hits`) VALUES
('25-10-2011', 1),
('04-11-2011', 1),
('15-12-2011', 1),
('07-01-2012', 1);

-- --------------------------------------------------------

--
-- Table structure for table `info_online`
--

CREATE TABLE IF NOT EXISTS `info_online` (
  `time` int(15) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  KEY `ip` (`ip`),
  KEY `time` (`time`),
  KEY `time_and_ip` (`time`,`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_online`
--

INSERT INTO `info_online` (`time`, `ip`) VALUES
(1325949531, '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `info_os`
--

CREATE TABLE IF NOT EXISTS `info_os` (
  `name` varchar(255) NOT NULL default '',
  `count` int(11) NOT NULL default '0',
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_os`
--

INSERT INTO `info_os` (`name`, `count`) VALUES
('Windows', 14),
('Mac', 0),
('Linux', 0),
('FreeBSD', 0),
('SunOS', 0),
('IRIX', 0),
('BeOS', 0),
('OS/2', 0),
('AIX', 0),
('Other', 0),
('BlackBerry', 0),
('Symbian', 0);

-- --------------------------------------------------------

--
-- Table structure for table `songs_access_log`
--

CREATE TABLE IF NOT EXISTS `songs_access_log` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` text NOT NULL,
  `ip` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_albums`
--

CREATE TABLE IF NOT EXISTS `songs_albums` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `img` text NOT NULL,
  `year` int(11) NOT NULL,
  `page_name` varchar(100) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_description` varchar(255) NOT NULL,
  `page_keywords` varchar(255) NOT NULL,
  `votes` int(11) NOT NULL,
  `votes_total` int(11) NOT NULL,
  `rate` float NOT NULL,
  `views` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `field_1` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `year` (`year`),
  KEY `rate` (`rate`),
  KEY `name` (`name`),
  KEY `field_1` (`field_1`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_albums_fields`
--

CREATE TABLE IF NOT EXISTS `songs_albums_fields` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `style` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `enable_search` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `songs_albums_fields`
--

INSERT INTO `songs_albums_fields` (`id`, `name`, `details`, `type`, `value`, `style`, `ord`, `enable_search`, `active`) VALUES
(1, 'انتاج', '', 'text', '', '', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `songs_banners`
--

CREATE TABLE IF NOT EXISTS `songs_banners` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `date` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `type` varchar(20) NOT NULL,
  `views` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0',
  `menu_id` int(11) NOT NULL default '0',
  `menu_pos` varchar(1) NOT NULL,
  `pages` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `c_type` varchar(4) NOT NULL,
  `start_date` int(11) NOT NULL,
  `expire_date` int(11) NOT NULL,
  `active` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `menu_pos` (`menu_pos`),
  KEY `c_type` (`c_type`),
  KEY `active` (`active`),
  KEY `expire_date` (`expire_date`),
  KEY `pos_active_start_end` (`active`,`start_date`,`expire_date`,`menu_pos`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `songs_banners`
--

INSERT INTO `songs_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`, `start_date`, `expire_date`, `active`) VALUES
(1, 'اختبار اعلان جوجل', 'http://allomani.com', 'http://allomani.com/allomani_banner.gif', 1313265448, 1, 'footer', 46599, 38, 0, 'l', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', '<center>\r\n<script type="text/javascript">\r\n<!--\r\ngoogle_ad_client = "ca-pub-5790135166774020";\r\n/* Demos Ad */\r\ngoogle_ad_slot = "2070969509";\r\ngoogle_ad_width = 468;\r\ngoogle_ad_height = 60;\r\n//-->\r\n</script>\r\n<script type="text/javascript"\r\nsrc="http://pagead2.googlesyndication.com/pagead/show_ads.js">\r\n</script>\r\n</center>', 'code', 1312578000, 1704056400, 1),
(2, 'اللوماني للخدمات البرمجية', 'http://allomani.com/', 'http://allomani.com/allomani_banner.gif', 1313265448, 0, 'header', 74872, 22, 0, 'l', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', '', 'img', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `songs_blocks`
--

CREATE TABLE IF NOT EXISTS `songs_blocks` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `pos` varchar(1) NOT NULL,
  `file` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(1) NOT NULL,
  `template` varchar(100) NOT NULL,
  `pages` text NOT NULL,
  `cat` int(11) NOT NULL,
  `hide_title` int(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `pos` (`pos`),
  KEY `active` (`active`),
  KEY `template` (`template`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `songs_blocks`
--

INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`, `cat`, `hide_title`) VALUES
(10, 'البحث', 'r', '<?\r\nglobal $keyword,$op,$phrases;\r\n\r\n$srch_arr = array("songs"=>$phrases[''the_songs''],"singers"=>$phrases[''the_singers''],"videos"=>$phrases[''the_videos''],"news"=>$phrases[''the_news'']);\r\n\r\nprint "<form  action=''search.php''>\r\n<input type=text name=''keyword'' size=''12'' value=\\"".htmlspecialchars($keyword)."\\">";\r\n\r\nprint_select_row("op",$srch_arr,$op);\r\n\r\nprint "<input type=submit value=''بحث''>\r\n</form>";\r\n', 5, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(8, 'القائمة الرئيسية', 'r', '<b>::</b> <a href=''index.php''>الرئيسية </a><br>\r\n<b>::</b> <a href=''news.html''>أرشيف الأخبار</a><br>\r\n<b>::</b> <a href=''albums.html''>الألبومات</a><br>\r\n<b>::</b> <a href=''members.php''>الاعضاء</a><br>\r\n<b>::</b> <a href=''index.php?action=statics''>احصائيات الموقع</a><br>\r\n<b>::</b> <a href=''contactus.php''>الاتصال بنا</a><br>\r\n ', 0, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(17, 'أقسام الأغاني', 'r', '<?\r\n$cats_qr=db_query("select * from songs_cats where active=1 order by ord asc");\r\nwhile($data = db_fetch($cats_qr)){\r\n       print "<b>::</b> <a href=\\"".cat_url($data[''id''],$data[''page_name''],$data[''name''])."\\" title=\\"$data[name]\\">$data[name]</a><br>";\r\n\r\n\r\n        }\r\n', 1, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(11, 'الاستفتاءات', 'l', '<?\r\n$qr_title = db_query("select * from songs_votes_cats  where active=1");\r\nif(db_num($qr_title)){\r\n\r\n$data_title = db_fetch($qr_title);\r\nprint "<center>$data_title[title]</center>";\r\n$qr = mysql_query("select * from songs_votes where cat=$data_title[id]");\r\nprint "<form action=\\"votes.php\\" method=\\"post\\">\r\n<input type=''hidden'' name=''action'' value=''vote_add''>\r\n";\r\n\r\n while ($data = mysql_fetch_array($qr)){\r\n\r\n        print "<input type=''radio'' value=''$data[id]'' name=''vote_id''>$data[title]<br>";\r\n\r\n\r\n\r\n }\r\nprint "<center><br><input type=''submit'' value=''تصويت''> <br><br><a href=''votes.php''>النتائج </a></center></form>";\r\n}else{\r\nprint "<center>  لا توجد تصويتات مفعلة حاليا </center>";\r\n}\r\n?>', 1, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(2, 'الأكثر تحميلا', 'l', '<?\r\nglobal $links,$settings;\r\n\r\n$cat = $settings[''default_url_id''];\r\n\r\n$qr=db_query("select songs_songs.*,songs_singers.name as singer_name  from songs_songs,songs_singers where songs_singers.id=songs_songs.album order by songs_songs.downloads_{$cat} DESC limit 10");\r\n\r\n  $c = 0 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\n\r\n            $c++ ;\r\n\r\n          print "$c.<a href=\\"".str_replace(array(''{id}'',''{cat}''),array($data[''id''],$cat),$links[''song_listen''])."\\" title=\\"$data[singer_name] - $data[name]\\">$data[singer_name] - $data[name]</a> </font><br>";\r\n        }\r\n\r\n\r\n?>', 4, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(4, 'المتواجدون الأن', 'r', '<?\r\nglobal $counter,$settings ;\r\n\r\nprint "<p align=center>  يتصفح الموقع حاليا $counter[online_users] زائر";\r\n\r\nif($settings[''online_members_count'']){\r\nprint " , $counter[online_members] عضو";\r\n}\r\n\r\nprint "</p>";\r\n\r\nprint "<p dir=rtl align=center>أكبر تواجد كان  $counter[best_visit] في : <br> $counter[best_visit_time] <br></p>";\r\n', 9, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(13, 'أخر التحديثات', 'c', '<?\r\nglobal $settings,$data,$phrases;\r\n\r\n$sigers_array = array();   \r\n\r\n\r\n\r\n$qr=db_query("select name,id,last_update,img,page_name from songs_singers where active=1 order by last_update desc limit 8") ;\r\n\r\nif(db_num($qr)){\r\nprint "<table width=100%><tr>";\r\n$c=0 ;\r\nwhile($data = db_fetch($qr)){\r\n\r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\nprint "<td valign=top>";\r\nrun_template(''browse_singers'');\r\nprint "</td>";\r\n              }\r\n\r\nprint "</tr></table>";\r\n}else{\r\nprint "<center>$phrases[no_data]</center>";\r\n}\r\n?>', 1, 1, '0', 'main,', 0, 0),
(18, 'آخر الأخبار', 'c', '<?\r\nglobal $data,$phrases;\r\n\r\n$qr = db_query("select * from songs_news order by id DESC limit 4");\r\n\r\nif(db_num($qr)){\r\nprint "<table width=100%><tr>" ;\r\n\r\nwhile($data = db_fetch($qr)){\r\n\r\n\r\nprint "<tr><td>";\r\nrun_template(''browse_news'');  \r\nprint "</td></tr>";\r\n\r\n        }\r\nprint "</tr></table>";\r\n}else{\r\nprint "<center> $phrases[no_news] </center>";\r\n}\r\n       ?>', 6, 1, '0', 'main,', 0, 0),
(19, 'أكثر الكليبات تحميلا', 'l', '<?\r\nglobal $links;\r\n\r\n$qr=db_query("select *  from songs_videos_data  order by downloads DESC limit 20");\r\n  $c = 0 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\n      ++$c;\r\n          print "$c.<a href=\\"".str_replace(''{id}'',$data[''id''],$links[''video_watch''])."\\" title=\\"$data[name]\\">$data[name]</a><br>";\r\n        }\r\n\r\n\r\n?>', 7, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(20, 'جديد الكليبات', 'c', '<?\r\nglobal $settings,$data,$phrases ;\r\n$qr=db_query("select * from songs_videos_data order by id DESC limit 8") ;\r\nif(db_num($qr)){\r\nprint "<table width=100%><tr>";\r\n$c=0 ;\r\nwhile ($data = db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n run_template(''browse_videos'');   \r\n\r\n              }\r\nprint "</tr></table>";\r\n}else{\r\nprint "<center>$phrases[no_data]</center>";\r\n}\r\n\r\n?>', 3, 1, '0', 'main,', 0, 0),
(21, 'أقسام الكليبات', 'r', '<?\r\nglobal $links;\r\n\r\n$cats_qr=db_query("select * from songs_videos_cats where active=1 and cat=0 order by ord asc");\r\nwhile($data = db_fetch($cats_qr)){\r\n       print "<b>::</b> <a href=''".str_replace(''{id}'',$data[''id''],$links[''browse_videos''])."''>$data[name]</a><br>";\r\n\r\n\r\n        }', 2, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(26, 'جديد الألبومات', 'c', '<?\r\nglobal $settings,$data_album,$settings,$global_align_x,$links,$phrases;\r\n\r\n$qr=mysql_query("select songs_albums.*,songs_singers.name as singer_name,songs_singers.id as singer_id,songs_singers.page_name as singer_page_name,songs_singers.img as singer_img  from songs_albums,songs_singers where songs_singers.active=1 and songs_albums.cat=songs_singers.id order by ".iif($settings[''albums_orderby'']=="year","songs_albums.year $settings[albums_sort] , songs_albums.id $settings[albums_sort]","songs_albums.$settings[albums_orderby] $settings[albums_sort]")." limit 8") ;\r\n\r\nif(db_num($qr)){\r\nprint "<table width=100%><tr>";\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data_album =db_fetch($qr)){\r\n\r\n\r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\nprint "<td valign=top>";\r\n\r\n\r\nif (!$data_album[''img'']){\r\n$data_album[''img''] = $data_album[''singer_img''];\r\n}\r\n\r\nrun_template(''browse_albums'');\r\n\r\nprint "</td>";\r\n              \r\n}\r\n             print "</tr></table>\r\n\r\n<br><div align=''$global_align_x''><a href=\\"$links[albums_page]\\">جميع الألبومات</a></div>";\r\n}else{\r\nprint "<center>$phrases[no_data]</center>";\r\n}\r\n?>', 2, 1, '0', 'main,', 0, 0),
(22, 'الأكثر تقييما', 'l', '<?\r\nglobal $links,$settings;\r\n\r\n$cat = $settings[''default_url_id''];\r\n\r\n$qr=db_query("select songs_songs.*,songs_singers.name as singer_name  from songs_songs,songs_singers where songs_singers.id = songs_songs.album order by songs_songs.rate DESC limit 10");\r\n\r\n  $c = 1 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\nprint "$c. <a href=\\"".str_replace(array(''{id}'',''{cat}''),array($data[''id''],$cat),$links[''song_listen''])."\\" title=\\"$data[singer_name] - $data[name]\\">$data[singer_name] - $data[name]</a> <br>";\r\n\r\n$c++;\r\n}\r\n\r\n\r\n?>', 2, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(23, 'احصائيات', 'r', '<?\r\nglobal $phrases;\r\n\r\n $data1 = db_qr_fetch("select count(id) as count from songs_singers");\r\n  $data3 = db_qr_fetch("select count(id) as count from songs_songs");\r\n   $data5 = db_qr_fetch("select count(id) as count from songs_videos_data");\r\n\r\n\r\nprint "\r\n\r\n<b> $phrases[singers_count] : </b> $data1[count] <br> <b>  $phrases[songs_count] : </b> $data3[count] <br> <b> $phrases[videos_count] : </b> $data5[count] \r\n";\r\n?>', 7, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(24, 'جديد السوق', 'l', '<?\r\nglobal $phrases;\r\n\r\n$cached_newmenu = cache_get("newmenu");\r\n\r\nif($cached_newmenu === false){\r\n\r\n$qr = db_query("select songs_singers.*,songs_new_menu.ord from songs_singers,songs_new_menu where songs_singers.id = songs_new_menu.cat and songs_new_menu.`type` like ''singer''");\r\nwhile($data = db_fetch($qr)){\r\n $arr[$data[''ord'']] = $data;   \r\n $arr[$data[''ord'']][''type''] = "singer";   \r\n}\r\n\r\n$qr=db_query("select songs_new_menu.ord,songs_albums.*,songs_singers.id as singer_id ,songs_singers.name as singer_name,songs_singers.page_name as singer_page_name,songs_singers.img as singer_img from songs_singers,songs_albums,songs_new_menu where songs_albums.cat = songs_singers.id and songs_singers.active=1 and songs_albums.id=songs_new_menu.cat and songs_new_menu.`type` like ''album''");\r\nwhile($data = db_fetch($qr)){\r\n $arr[$data[''ord'']] = $data;   \r\n $arr[$data[''ord'']][''type''] = "album";   \r\n}\r\n\r\nunset($data);\r\n$arr = (array) $arr;\r\nksort($arr);\r\n\r\ncache_set("newmenu",$arr);\r\n}else{\r\n$arr = $cached_newmenu;\r\n$arr = (array) $arr;\r\n}\r\n\r\nprint "<center>";\r\n\r\nif(count($arr)){\r\nforeach($arr as $data){\r\n\r\nif($data[''type'']=="singer"){\r\n\r\nprint "<a href=\\"".singer_url($data[''id''],$data[''page_name''],$data[''name''])."\\" title=\\"$data[name]\\"><img src=\\"".get_image($data[''img''])."\\" alt=\\"$data[name]\\" width=50 hieght=50><br>$data[name]</a><br><br>";\r\n\r\n\r\n\r\n\r\n}else{\r\n\r\nprint "<a href=\\"".album_url($data[''id''],$data[''page_name''],$data[''name''],$data[''singer_id''],$data[''singer_page_name''],$data[''singer_name''])."\\" title=\\"$data[singer_name] - $data[name]\\"><img src=\\"".get_image(iif($data[''img''],$data[''img''],$data[''singer_img'']))."\\" alt=\\"$data[singer_name] - $data[name]\\"  width=50 hieght=50><br>$data[singer_name] - $data[name]</a>".iif($data[''year''],"<br> <font color=#9D9D9D>$data[year]</font>")."<br><br>";\r\n\r\n}\r\n}\r\n}else{\r\nprint $phrases[''no_data''];\r\n}\r\nprint "</center>";\r\n?>', 0, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(25, 'الأكثر استماعا', 'l', '<?\r\nglobal $links,$settings,$phrases;\r\n\r\n$cat = $settings[''default_url_id''];\r\n\r\n$qr=db_query("select songs_songs.*,songs_singers.name as singer_name  from songs_songs,songs_singers where songs_singers.id=songs_songs.album order by songs_songs.listens_{$cat} DESC limit 10");\r\n\r\nif(db_num($qr)){\r\n  $c = 0 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\n\r\n            $c++ ;\r\n\r\n          print "$c.<a href=\\"".str_replace(array(''{id}'',''{cat}''),array($data[''id''],$cat),$links[''song_listen''])."\\" title=\\"$data[singer_name] - $data[name]\\">$data[singer_name] - $data[name]</a> </font><br>";\r\n        }\r\n\r\n}else{\r\nprint "<center>$phrases[no_data]</center>";\r\n}\r\n?>', 3, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(27, 'أكثر الكليبات تقييما', 'l', '<?\r\nglobal $links;\r\n\r\n$qr=db_query("select *  from songs_videos_data order by rate DESC limit 10");\r\n  $c = 0 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\n      ++$c;\r\n          print "$c.<a href=\\"".str_replace(''{id}'',$data[''id''],$links[''video_watch''])."\\" title=\\"$data[name]\\">$data[name]</a> </font><br>";\r\n        }\r\n\r\n\r\n?>', 8, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(31, 'الأعضاء', 'r', '<? if(check_member_login()){\r\nglobal $member_data,$style,$phrases ;\r\n\r\n\r\nprint "<center>  أهلا و سهلا بك يا $member_data[username] <br> <br>" ;\r\n$nw_msgs = db_qr_fetch("select count(id) as count from songs_members_msgs where owner=''$member_data[id]'' and opened=0 and sent=0");\r\n\r\nif($nw_msgs[''count''] >0){\r\nprint "<font color=red> لديك $nw_msgs[count] رسائل جديدة </font><br><br>";\r\n}\r\n\r\nprint "</center>\r\n\r\n<a href=''usercp.php''><img src=''$style[images]/my_favorite.gif''>&nbsp; $phrases[favorite_videos] </a><br>\r\n\r\n\r\n<a href=''messages.php''><img src=''$style[images]/my_messages.gif''>&nbsp; الرسائل الخاصة</a><br>\r\n\r\n<a href=''usercp.php?action=profile''><img src=''$style[images]/my_profile.gif''>&nbsp; الملف الشخصي </a><br>\r\n\r\n<a href=''usercp.php?action=friends''><img src=''$style[images]/friends_list.gif''>&nbsp; الاصدقاء </a><br>\r\n\r\n<a href=''usercp.php?action=black_list''><img src=''$style[images]/black_list.gif''>&nbsp; قائمة التجاهل</a><br>\r\n\r\n<a href=''login.php?action=logout''><img src=''$style[images]/logout.gif''>&nbsp; تسجيل خروج </a>\r\n</center><br>";\r\n}else{\r\n?>\r\n<form method="POST" action="login.php">\r\n<input type=hidden name=action value=login>\r\n<input type=hidden name=re_link value="<? print $_SERVER[REQUEST_URI] ; ?>">\r\n<table border="0" width="100%">\r\n	<tr>\r\n		<td height="15"><span lang="ar-sa">اسم المستخدم :</span></td></tr><tr>\r\n		<td height="15"><input type="text" name="username" size="10"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="12"><span lang="ar-sa">كلمة المرور :</span></td></tr><tr>\r\n		<td height="12" ><input type="password" name="password" size="10"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="23">\r\n		<p align="center"><input type="submit" value="تسجيل دخول"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="38"><span lang="ar-sa">\r\n		<a href="register.php">مستخدم جديد ؟</a><br>\r\n		<a href="index.php?action=forget_pass">نسيت كلمة المرور ؟</a></span></td>\r\n	</tr>\r\n</table>\r\n</form>\r\n\r\n<?\r\n}\r\n?>', 3, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(32, 'اغاني عشوائية', 'r', '<?\r\n$qr = db_query("select id,name from songs_cats where active=1 order by binary name asc");\r\nprint "<form action=''listen_all.php'' method=''post''>\r\n<input type=''hidden'' name=''action'' value=''random''>\r\n\r\n<table><tr><td colspan=2>\r\nالقسم : </td></tr><tr><td colspan=2><select name=cat>\r\n<option value=''''>جميع الأقسام </option>" ;\r\n\r\nwhile($data = db_fetch($qr)){\r\nprint "<option value=''$data[id]''>$data[name]</option>";\r\n}\r\nprint "</select>\r\n</td></tr><tr><td>\r\nالعدد : </td><td>\r\n<select name=num>\r\n<option value=10>10</option>\r\n<option value=15>15</option>\r\n<option value=20>20</option>\r\n</select>\r\n</td></tr><tr><td colspan=2 align=center>\r\n<input type=submit value=''استماع''>\r\n</td></tr></table>\r\n</form>";\r\n', 6, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(34, 'جديد الأغاني', 'c', '<?\r\nglobal $action,$data,$data_singer,$song_ext,$lyrics_count,$urls_sets,$songs_fields_sets,$phrases,$songs_limit,$tr_class,$song_ext,$videos_count,$lyrics_count;\r\n\r\n$songs_limit =  1;\r\n\r\n$qr=db_query("select songs_new_songs_menu.song_id,songs_songs.*,songs_singers.name as singer_name,songs_singers.id as singer_id,songs_singers.page_name as singer_page_name  from songs_new_songs_menu,songs_songs,songs_singers where songs_songs.id=songs_new_songs_menu.song_id and songs_singers.id=songs_songs.album  order by songs_new_songs_menu.ord asc");\r\n\r\n  $c = 0 ;\r\n\r\nif(db_num($qr)){\r\n\r\n//--- save results to array -----------\r\nunset($saved_results);\r\n$lyrics_count = 0;\r\n$videos_count = 0;\r\n      while($data = db_fetch($qr)){  \r\n      $saved_results[] = $data;\r\n      if($data[''lyrics'']){$lyrics_count++;}\r\n      if($data[''video_id'']){$videos_count++;}\r\n      }\r\n//------------------------------------\r\n\r\n\r\nrun_template(''browse_songs_header'');\r\n\r\n\r\nforeach($saved_results as $data){\r\n\r\n   \r\n $song_ext =  get_song_ext($data[''ext''],$data[''date'']) ;\r\n\r\n\r\n$data_singer[''name''] = $data[''singer_name''];\r\n$data_singer[''id''] = $data[''singer_id''];\r\n$data_singer[''page_name''] = $data[''singer_page_name''];\r\n\r\n\r\nif($tr_class == "row_1"){\r\n$tr_class="row_2" ;\r\n}else{\r\n$tr_class="row_1";\r\n}         \r\n   \r\n\r\nrun_template(''browse_songs'');\r\n\r\n        }\r\n\r\nrun_template(''browse_songs_footer'');\r\n}else{\r\nprint "<center>$phrases[err_no_songs]</center>";\r\n}\r\n\r\n?>', 4, 1, '0', 'main,', 0, 0),
(35, 'التغذية', 'r', '<?\r\nglobal $global_align,$phrases,$sitemap_perpage;\r\n\r\n$count_songs = valueof(db_qr_fetch("select count(*) as count from songs_songs"),"count");\r\n\r\n\r\nprint "\r\n<fieldset style=''align:$global_align;''>\r\n<legend><b>RSS</b></legend>\r\n<a href=''rss.php''><img src=''images/rss_small.png''>&nbsp;$phrases[the_singers]</a>\r\n<br>\r\n<a href=''rss.php?op=songs''><img src=''images/rss_small.png''>&nbsp;$phrases[the_songs]</a>\r\n<br>\r\n<a href=''rss.php?op=albums''><img src=''images/rss_small.png''>&nbsp;$phrases[the_albums]</a>\r\n<br>\r\n<a href=''rss.php?op=videos''><img src=''images/rss_small.png''>&nbsp;$phrases[the_videos]</a>\r\n<br>\r\n<a href=''rss.php?op=photos''><img src=''images/rss_small.png''>&nbsp;$phrases[the_photos]</a>\r\n<br>\r\n<a href=''rss.php?op=news''><img src=''images/rss_small.png''>&nbsp;$phrases[the_news]</a>\r\n\r\n\r\n</fieldset>\r\n<br>\r\n\r\n<fieldset style=''align:$global_align;''>\r\n<legend><b>Site Maps</b></legend>\r\n<a href=''sitemap.php''><img src=''images/sitemap_small.gif''>&nbsp;Main Site Map</a>\r\n<br>";\r\n\r\n$pgs = $count_songs / $sitemap_perpage;\r\n$pgs = (int) $pgs;\r\nif($pgs<1){$pgs=1;}\r\n\r\nfor($i=1;$i<=$pgs;$i++){\r\nprint "<a href=''sitemap.php?op=songs".iif($i>1,"&page=$i")."''><img src=''images/sitemap_small.gif''>&nbsp;$phrases[the_songs]".iif($i>1," $i")."</a><br>";\r\n}\r\n\r\nprint "\r\n<a href=''sitemap.php?op=videos''><img src=''images/sitemap_small.gif''>&nbsp;$phrases[the_videos]</a>\r\n<br>\r\n<a href=''sitemap.php?op=photos''><img src=''images/sitemap_small.gif''>&nbsp;$phrases[the_photos]</a>\r\n\r\n</fieldset>";\r\n?>', 8, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(36, 'قائمة التشغيل', 'r', '<?\r\nglobal $member_data,$phrases;\r\nif(check_member_login()){\r\n\r\nprint "\r\n<div id=\\"playlists_select_div\\">\r\n<script>\r\nget_playlists();\r\n</script>\r\n</div>\r\n<div id=\\"playlists_add_div\\" style=\\"display:none\\">\r\n<input type=text id=playlist_name name=playlist_name size=6>&nbsp;<input type=button value=\\"$phrases[add_button]\\" onclick=\\"playlists_submit($(''playlist_name'').value);\\"></div>";\r\n\r\n//----- List Items -----//\r\n\r\n$last_list_id = intval(get_cookie(''last_list_id''));\r\n\r\n\r\nprint "<form name=''playlist_form'' action=''listen_all.php'' method=''post''>\r\n<div id=\\"playlist_div\\" align=center style=\\"background-color:#FFFFFF;border: thin dashed #C0C0C0;\\">\r\n\r\n<script>\r\nget_playlist_items(".$last_list_id.");\r\n</script>";\r\n\r\nprint "</div><br>\r\n<center><input type=submit value=\\"$phrases[listen]\\"></center>\r\n</form>\r\n\r\n<script>\r\ninit_playlist_sortlist();\r\n</script>";\r\n\r\n}else{\r\nprint "<center> $phrases[please_login_first]</center>";\r\n}\r\n', 4, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(37, 'العروض', 'c', '<?\r\n\r\n$qr=db_query("select * from songs_banners where `type` like ''offer'' and active=1 and (start_date <= ".time()." or start_date=0) and (expire_date > ".time()." or expire_date=0) order by ord");\r\nif(db_num($qr)){\r\n\r\ninclude_once("includes/class_slider.php");\r\n\r\nopen_table();\r\n$slider = new slider("slider");      \r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n$ids[] = $data[''id''];\r\n\r\n$slider->start($data[''id'']);\r\nprint "<center>".iif($data[''url''],"<a href=\\"banner.php?id=$data[id]\\" target=_blank title=\\"$data[title]\\">").iif($data[''img''],"<img border=0 src=\\"$data[img]\\" alt=\\"$data[title]\\" title=\\"$data[title]\\"><br><br>").$data[''content''].iif($data[''url''],"</a>")."</center>";\r\n\r\n$slider->end();  \r\n}\r\n\r\n\r\n$slider->run();\r\ndb_query("update songs_banners set views=views+1 where id IN (".implode(",",$ids).")");\r\nclose_table();\r\n}\r\n?>', 0, 1, 'no_title_no_border', 'main,', 0, 1),
(38, 'اكثر الكليبات مشاهدة', 'l', '<?\r\nglobal $links;\r\n\r\n$qr=db_query("select *  from songs_videos_data  order by views DESC limit 20");\r\n  $c = 0 ;\r\nwhile($data=db_fetch($qr)){\r\n\r\n      ++$c;\r\n          print "$c.<a href=\\"".str_replace(''{id}'',$data[''id''],$links[''video_watch''])."\\" title=\\"$data[name]\\">$data[name]</a><br>";\r\n        }\r\n\r\n\r\n?>', 6, 1, '0', 'main,browse.php,singer_overview.php,singer_bio.php,singer_photos.php,singer_videos.php,songs.php,listen.php,lyrics.php,albums.php,videos.php,video_watch.php,news.php,pages,search.php,votes.php,statics,register.php,profile.php,contactus.php,', 0, 0),
(40, 'جديد الصور', 'c', '<?\r\nglobal $phrases,$qr;\r\n\r\n$qr = db_query("select songs_singers_photos.*,songs_singers.id as singer_id , songs_singers.name as singer_name, songs_singers.page_name as singer_page_name from songs_singers_photos,songs_singers where songs_singers.id = songs_singers_photos.cat order by id desc limit 8");\r\n\r\nif(db_num($qr)){\r\n\r\n run_template(''browse_photos''); \r\n\r\n}else{\r\n\r\nprint "<center>$phrases[no_photos]</center>";\r\n}', 5, 1, '0', 'main,', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `songs_cats`
--

CREATE TABLE IF NOT EXISTS `songs_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `ord` int(2) NOT NULL default '0',
  `active` int(1) NOT NULL default '0',
  `download_for_members` int(1) NOT NULL default '0',
  `listen_for_members` int(1) NOT NULL,
  `page_name` varchar(100) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_description` varchar(255) NOT NULL,
  `page_keywords` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `active` (`active`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `songs_cats`
--

INSERT INTO `songs_cats` (`id`, `name`, `ord`, `active`, `download_for_members`, `listen_for_members`, `page_name`, `page_title`, `page_description`, `page_keywords`) VALUES
(1, 'اغاني شامية', 1, 1, 0, 0, 'Shami', '', '', ''),
(2, 'اغاني مصرية', 1, 1, 0, 0, 'Egypt', '', '', ''),
(3, 'اغاني عراقية', 1, 1, 0, 0, 'Iraqi', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `songs_comments`
--

CREATE TABLE IF NOT EXISTS `songs_comments` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL default '0',
  `fid` int(11) NOT NULL default '0',
  `comment_type` varchar(100) NOT NULL default '',
  `content` text NOT NULL,
  `time` int(14) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `fid` (`fid`,`comment_type`,`active`),
  KEY `active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_confirmations`
--

CREATE TABLE IF NOT EXISTS `songs_confirmations` (
  `id` int(11) NOT NULL auto_increment,
  `type` text NOT NULL,
  `old_value` text NOT NULL,
  `new_value` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  `code` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_countries`
--

CREATE TABLE IF NOT EXISTS `songs_countries` (
  `name` varchar(80) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `songs_countries`
--

INSERT INTO `songs_countries` (`name`) VALUES
('Afghanistan'),
('Albania'),
('Algeria'),
('American Samoa'),
('Andorra'),
('Angola'),
('Anguilla'),
('Antarctica'),
('Antigua and Barbuda'),
('Argentina'),
('Armenia'),
('Aruba'),
('Australia'),
('Austria'),
('Azerbaijan'),
('Bahamas'),
('Bahrain'),
('Bangladesh'),
('Barbados'),
('Belarus'),
('Belgium'),
('Belize'),
('Benin'),
('Bermuda'),
('Bhutan'),
('Bolivia'),
('Bosnia and Herzegovina'),
('Botswana'),
('Bouvet Island'),
('Brazil'),
('British Indian Ocean Territory'),
('Brunei Darussalam'),
('Bulgaria'),
('Burkina Faso'),
('Burundi'),
('Cambodia'),
('Cameroon'),
('Canada'),
('Cape Verde'),
('Cayman Islands'),
('Central African Republic'),
('Chad'),
('Chile'),
('China'),
('Christmas Island'),
('Cocos (Keeling) Islands'),
('Colombia'),
('Comoros'),
('Congo'),
('Cook Islands'),
('Costa Rica'),
('Cote D''Ivoire'),
('Croatia'),
('Cuba'),
('Cyprus'),
('Czech Republic'),
('Denmark'),
('Djibouti'),
('Dominica'),
('Dominican Republic'),
('Ecuador'),
('Egypt'),
('El Salvador'),
('Equatorial Guinea'),
('Eritrea'),
('Estonia'),
('Ethiopia'),
('Faroe Islands'),
('Fiji'),
('Finland'),
('France'),
('Gabon'),
('Gambia'),
('Georgia'),
('Germany'),
('Ghana'),
('Gibraltar'),
('Greece'),
('Greenland'),
('Grenada'),
('Guadeloupe'),
('Guam'),
('Guatemala'),
('Guinea'),
('Guinea-Bissau'),
('Guyana'),
('Haiti'),
('Honduras'),
('Hong Kong'),
('Hungary'),
('Iceland'),
('India'),
('Indonesia'),
('Iraq'),
('Ireland'),
('Israel'),
('Italy'),
('Jamaica'),
('Japan'),
('Jordan'),
('Kazakhstan'),
('Kenya'),
('Kiribati'),
('Korea, Republic of'),
('Kuwait'),
('Kyrgyzstan'),
('Latvia'),
('Lebanon'),
('Lesotho'),
('Liberia'),
('Libyan Arab Jamahiriya'),
('Liechtenstein'),
('Lithuania'),
('Luxembourg'),
('Macao'),
('Madagascar'),
('Malawi'),
('Malaysia'),
('Maldives'),
('Mali'),
('Malta'),
('Marshall Islands'),
('Martinique'),
('Mauritania'),
('Mauritius'),
('Mayotte'),
('Mexico'),
('Monaco'),
('Mongolia'),
('Montserrat'),
('Morocco'),
('Mozambique'),
('Myanmar'),
('Namibia'),
('Nauru'),
('Nepal'),
('Netherlands'),
('Netherlands Antilles'),
('New Caledonia'),
('New Zealand'),
('Nicaragua'),
('Niger'),
('Nigeria'),
('Niue'),
('Norfolk Island'),
('Norway'),
('Oman'),
('Pakistan'),
('Palau'),
('Panama'),
('Papua New Guinea'),
('Paraguay'),
('Peru'),
('Philippines'),
('Pitcairn'),
('Poland'),
('Portugal'),
('Puerto Rico'),
('Qatar'),
('Reunion'),
('Romania'),
('Russian Federation'),
('Rwanda'),
('Saint Helena'),
('Saint Kitts and Nevis'),
('Saint Lucia'),
('Saint Pierre and Miquelon'),
('Samoa'),
('San Marino'),
('Sao Tome and Principe'),
('Saudi Arabia'),
('Senegal'),
('Serbia and Montenegro'),
('Seychelles'),
('Sierra Leone'),
('Singapore'),
('Slovakia'),
('Slovenia'),
('Solomon Islands'),
('Somalia'),
('South Africa'),
('Spain'),
('Sri Lanka'),
('Sudan'),
('Suriname'),
('Svalbard and Jan Mayen'),
('Swaziland'),
('Sweden'),
('Switzerland'),
('Syrian Arab Republic'),
('Taiwan, Province of China'),
('Tajikistan'),
('Thailand'),
('Timor-Leste'),
('Togo'),
('Tokelau'),
('Tonga'),
('Trinidad and Tobago'),
('Tunisia'),
('Turkey'),
('Turkmenistan'),
('Turks and Caicos Islands'),
('Tuvalu'),
('Uganda'),
('Ukraine'),
('United Arab Emirates'),
('United Kingdom'),
('United States'),
('Uruguay'),
('Uzbekistan'),
('Vanuatu'),
('Venezuela'),
('Viet Nam'),
('Virgin Islands, British'),
('Virgin Islands, U.s.'),
('Wallis and Futuna'),
('Western Sahara'),
('Yemen'),
('Zambia'),
('Zimbabwe'),
('Palestine');

-- --------------------------------------------------------

--
-- Table structure for table `songs_exts`
--

CREATE TABLE IF NOT EXISTS `songs_exts` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `period_from` int(5) NOT NULL,
  `period_to` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `songs_exts`
--

INSERT INTO `songs_exts` (`id`, `name`, `period_from`, `period_to`) VALUES
(1, 'جديد', 31, 60),
(2, 'جديد جدا', 0, 30),
(3, 'جلسة', 0, 0),
(4, 'حفلة', 0, 0),
(6, 'مفرد', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `songs_hooks`
--

CREATE TABLE IF NOT EXISTS `songs_hooks` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `hookid` text NOT NULL,
  `code` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_links`
--

CREATE TABLE IF NOT EXISTS `songs_links` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `songs_links`
--

INSERT INTO `songs_links` (`id`, `name`, `value`) VALUES
(1, 'cat', 'cat/{id}-{name}.html'),
(2, 'browse_news', 'news_{cat}.html'),
(3, 'browse_news_w_pages', 'news_{cat}_{start}.html'),
(4, 'singer', 'singer/{id}-{name}.html'),
(5, 'album', 'album-{id}-{album_id}.html'),
(6, 'browse_songs_w_pages', 'singer-{id}-{album_id}-{orderby}-{sort}-{start}.html'),
(7, 'browse_videos', 'videos-{id}.html'),
(8, 'browse_videos_w_pages', 'videos-{id}-{start}.html'),
(9, 'song_download', 'song_download_{id}_{cat}'),
(10, 'song_listen', 'song_listen_{id}_{cat}.html'),
(11, 'video_download', 'video_download_{id}'),
(12, 'video_watch', 'video_watch_{id}.html'),
(26, 'singer_songs', 'singer/{id}-{name}-songs.html'),
(14, 'album_w_name', 'album/{singer_id}-{id}-{singer_name}-{name}.html'),
(16, 'news', 'news.html'),
(17, 'news_details', 'news_view_{id}.html'),
(18, 'singer_photo', 'photo_{id}.html'),
(19, 'singer_photos', 'singer/{id}-{name}-photos.html'),
(20, 'singer_videos', 'singer/{id}-{name}-videos.html'),
(21, 'pages', 'page_{id}.html'),
(22, 'profile', 'profile_{id}.html'),
(23, 'letters_songs_w_pages', 'songs-letter-{letter}-{start}.html'),
(24, 'letters_songs', 'songs-letter-{letter}.html'),
(25, 'singer_w_pages', 'singer/{id}-{album_id}-{orderby}-{sort}-{start}-{name}.html'),
(27, 'singer_albums', 'singer/{id}-{name}-albums.html'),
(28, 'singer_overview', 'singer/{id}-{name}.html'),
(29, 'singer_videos_w_pages', 'singer/{id}-{name}-videos-{start}.html'),
(30, 'singer_photos_w_pages', 'singer/{id}-{name}-photos-{start}.html'),
(31, 'singer_bio', 'singer/{id}-{name}-bio.html'),
(32, 'song_ext_listen', 'song_listen_{id}_{cat}'),
(33, 'albums_page', 'albums.html'),
(34, 'albums_page_w_pages', 'albums-{year}-{start}.html'),
(35, 'albums_page_w_year', 'albums-{year}.html'),
(36, 'letters_singers', 'singers-letter-{letter}.html');

-- --------------------------------------------------------

--
-- Table structure for table `songs_members`
--

CREATE TABLE IF NOT EXISTS `songs_members` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `active_code` varchar(35) NOT NULL default '',
  `date` int(11) NOT NULL default '0',
  `last_login` int(11) NOT NULL default '0',
  `usr_group` int(11) NOT NULL default '0',
  `birth` date NOT NULL default '0000-00-00',
  `country` varchar(90) NOT NULL default '',
  `gender` varchar(10) NOT NULL default '',
  `members_list` int(1) NOT NULL default '0',
  `img` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `pm_email_notify` int(1) NOT NULL,
  `privacy_settings` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `active_code` (`active_code`),
  KEY `last_login` (`last_login`),
  KEY `members_list` (`members_list`),
  KEY `gender` (`gender`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_members_black`
--

CREATE TABLE IF NOT EXISTS `songs_members_black` (
  `id` int(11) NOT NULL auto_increment,
  `uid1` int(11) NOT NULL,
  `uid2` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_members_favorites`
--

CREATE TABLE IF NOT EXISTS `songs_members_favorites` (
  `id` int(11) NOT NULL auto_increment,
  `fid` int(11) NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  `type` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_members_friends`
--

CREATE TABLE IF NOT EXISTS `songs_members_friends` (
  `id` int(11) NOT NULL auto_increment,
  `uid1` int(11) NOT NULL,
  `uid2` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_members_msgs`
--

CREATE TABLE IF NOT EXISTS `songs_members_msgs` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `owner` int(11) NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  `username` varchar(255) NOT NULL,
  `opened` int(1) NOT NULL default '0',
  `date` int(11) NOT NULL default '0',
  `sent` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `owner` (`owner`),
  KEY `sent` (`sent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_members_sets`
--

CREATE TABLE IF NOT EXISTS `songs_members_sets` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `details` text NOT NULL,
  `type` text NOT NULL,
  `value` text NOT NULL,
  `style` text NOT NULL,
  `required` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_meta`
--

CREATE TABLE IF NOT EXISTS `songs_meta` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `title` text NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `songs_meta`
--

INSERT INTO `songs_meta` (`id`, `name`, `title`, `description`, `keywords`) VALUES
(1, 'cats', '{name}', '{name} , {name} mp3 , {name} جديدة , {name} حصرية', '{name} , {name} mp3 , {name} جديدة , {name} حصرية'),
(2, 'member_profile', '{name} - الملف الشخصي', 'الملف الشخصي {name} , {name} profile , العضو {name} , الافلام المفصلة {name} , مراسلة {name}', 'الملف الشخصي {name} , {name} profile , العضو {name} , الافلام المفصلة {name} , مراسلة {name}'),
(3, 'news', '{name}', '{name} , اقرأ {name} , خبر {name} , تفاصيل {name}', '{name} , اقرأ {name} , خبر {name} , تفاصيل {name}'),
(4, 'pages', '{name}', 'صفحة {name} , تفاصيل {name}', 'صفحة {name} , تفاصيل {name}'),
(5, 'search', 'البحث عن {name}{sp}{page}', 'البحث عن {name} {page}', 'البحث عن {name} {page}'),
(6, 'singer', '{name} - {cat_name}{sp}{page}', 'معلومات عن {name} , اغاني {name} , البومات {name} ,{cat_name}, {page}  ', 'معلومات عن {name} , اغاني {name} , البومات {name} ,{cat_name}, {page}  '),
(7, 'videos_cat', '{name}{sp}{page}', '{name} , {name} فيديوهات , كليبات {name} ,{name} جديدة , {name} حصرية {page}', '{name} , {name} فيديوهات , كليبات {name} ,{name} جديدة , {name} حصرية {page}'),
(8, 'news_cats', '{name}{sp}{page}', '{name} , اخبار {name} , جديد {name} , {name} news , {name} حصري', '{name} , اخبار {name} , جديد {name} , {name} news , {name} حصري'),
(9, 'letters_songs', 'أغاني حرف {letter}{sp}{page}', 'أغاني حرف {letter}{sp}{page}', 'أغاني حرف {letter}{sp}{page}'),
(10, 'letters_singers', 'مغنيين حرف {letter}', 'مغنيين حرف {letter}', 'مغنيين حرف {letter}'),
(11, 'song_listen', '{name} - {singer_name} - {cat_name}', '{name},{singer_name} {album_name},{cat_name}', '{name},{singer_name} {album_name},{cat_name}'),
(12, 'album', 'ألبوم {album} {album_year} - {name} - {cat_name}{sp}{page}', 'ألبوم {album} {album_year} , اغاني {name} , البومات {name} ,{cat_name}, {page}  ', 'ألبوم {album} {album_year} , اغاني {name} , البومات {name} ,{cat_name}, {page}  '),
(13, 'singer_songs', 'اغاني {name} - {cat_name}{sp}{page}', 'اغاني {name} , البومات {name} ,{cat_name}, {page}  ', 'اغاني {name} , البومات {name} ,{cat_name}, {page}  '),
(14, 'singer_albums', 'البومات {name} - {cat_name}', 'جميع البومات {name} , اغاني {name} , البومات {name} ,{cat_name}', 'جميع البومات {name} , اغاني {name} , البومات {name} ,{cat_name}'),
(15, 'singer_videos', 'كليبات {name} - {cat_name}{sp}{page}', 'كليبات {name} , اغاني {name} , البومات {name} ,{cat_name}, {page}  ', 'كليبات {name} , اغاني {name} , البومات {name} ,{cat_name}, {page}  '),
(16, 'videos', 'الكليبات', 'كليبات , فيديوهات , حفلات , اغاني', 'كليبات , فيديوهات , حفلات , اغاني'),
(17, 'singer_photos', 'صور {name} - {cat_name}{sp}{page}', 'صور {name} , اغاني {name} , البومات {name} ,{cat_name}, {page}  ', 'صور {name} , اغاني {name} , البومات {name} ,{cat_name}, {page}  '),
(18, 'singer_photo', 'صورة {id} - {name} - {cat_name}', 'صورة {id} , {name} , {cat_name}', 'صورة {id} , {name} , {cat_name}'),
(19, 'video_watch', '{name} - {cat_name}', 'كليب {name} , فيديو {name} , جديد {name}, حصري {name}, {cat_name}', 'كليب {name} , فيديو {name} , جديد {name}, حصري {name}, {cat_name}'),
(20, 'song_lyrics', 'كلمات {name} - {singer_name} - {cat_name}', 'كلمات  {name},{singer_name} {album_name},{cat_name}', 'كلمات  {name},{singer_name} {album_name},{cat_name}'),
(21, 'albums_page_w_year', 'ألبومات {year}{sp}{page}', 'ألبومات {year}{sp}{page}', 'ألبومات {year}{sp}{page}'),
(22, 'albums_page', 'الألبومات{sp}{page}', 'جميع الألبومات {page}', 'جميع الألبومات {page}'),
(23, 'contactus', 'الاتصال بنا', 'الاتصال بنا', 'الاتصال بنا'),
(24, 'votes', 'الاستفتائات', 'الاستفتائات', 'الاستفتائات'),
(25, 'members_page', 'الاعضاء {sp}{page}', 'الاعضاء {sp}{page}', 'الاعضاء {sp}{page}'),
(26, 'singer_bio', 'السيرة الذاتية {name} - {cat_name}', 'السيرة الذاتية {name} , اغاني {name} , البومات {name} ,{cat_name}  ', 'السيرة الذاتية {name} , اغاني {name} , البومات {name} ,{cat_name}  ');

-- --------------------------------------------------------

--
-- Table structure for table `songs_news`
--

CREATE TABLE IF NOT EXISTS `songs_news` (
  `id` int(11) NOT NULL auto_increment,
  `writer` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `details` text NOT NULL,
  `date` int(11) NOT NULL,
  `img` text NOT NULL,
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  `rate` float NOT NULL,
  `cat` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `rate` (`rate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_news_cats`
--

CREATE TABLE IF NOT EXISTS `songs_news_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_new_menu`
--

CREATE TABLE IF NOT EXISTS `songs_new_menu` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `type` varchar(10) NOT NULL default '',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `type` (`type`),
  KEY `ord` (`ord`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_new_songs_menu`
--

CREATE TABLE IF NOT EXISTS `songs_new_songs_menu` (
  `id` int(11) NOT NULL auto_increment,
  `song_id` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `song_id` (`song_id`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_pages`
--

CREATE TABLE IF NOT EXISTS `songs_pages` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_phrases`
--

CREATE TABLE IF NOT EXISTS `songs_phrases` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `cat` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=975 ;

--
-- Dumping data for table `songs_phrases`
--

INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES
(1, 'the_songs', 'الأغاني', 'main'),
(2, 'the_singers', 'المغنيين', 'main'),
(3, 'the_songs_count', 'عدد الأغاني', 'main'),
(4, 'the_albums_count', 'عدد الألبومات', 'main'),
(5, 'last_update', 'آخر تحديث', 'main'),
(6, 'contact_us', 'الإتصال بنا', 'main'),
(7, 'no_results', 'لا توجد نتائج', 'main'),
(8, 'search_results', 'نتائج البحث', 'main'),
(9, 'download', 'تحميل', 'main'),
(10, 'listen', 'استماع', 'main'),
(11, 'vote_song', 'تقييم الأغنية', 'main'),
(12, 'send2friend', 'ارسال لصديق', 'main'),
(13, 'lyrics', 'كلمات الأغنية', 'main'),
(14, 'watch', 'مشاهدة', 'main'),
(15, 'vote_video', 'تقييم الفيديو', 'main'),
(16, 'err_no_page', 'عفوا , هذه الصفحة غير موجودة', 'main'),
(17, 'type_search_keyword', 'قم بكتابة شيء للبحث عنه لا يقل عن {letters} أحرف', 'main'),
(18, 'the_name', 'الإسم', 'main'),
(19, 'add_date', 'تاريخ الإضافة', 'main'),
(20, 'err_no_videos', 'لا توجد كليبات تحت هذا القسم', 'main'),
(21, 'err_wrong_url', 'رابط خاطيء', 'main'),
(22, 'err_no_cats', 'عفوا , لا توجد اقسام هنا', 'main'),
(23, 'another_songs', 'اغاني اخرى', 'main'),
(24, 'pages', 'الصفحات', 'main'),
(25, 'err_no_songs', 'لا توجد أغاني', 'main'),
(26, 'the_writer', 'الكاتب', 'main'),
(27, 'the_news_archive', 'أرشيف الأخبار', 'main'),
(28, 'vote_song_thnx_msg', 'شكرا لك .. لقد تم تقييم الأغنية', 'main'),
(29, 'vote_video_thnx_msg', 'شكرا لك .. لقد تم تقييم الكليب', 'main'),
(30, 'vote_select', 'التقييم', 'main'),
(31, 'vote_do', 'تقييم', 'main'),
(32, 'send2friend_subject', 'دعوة من صديقك ', 'main'),
(33, 'send2friend_done', 'لقد تم ارسال الدعوة  لصديقك ', 'main'),
(34, 'your_name', 'اسمك', 'main'),
(35, 'your_email', 'بريدك الإلكتروني', 'main'),
(36, 'your_friend_email', 'بريد صديقك', 'main'),
(37, 'send', 'ارسال', 'main'),
(38, 'err_vote_expire_hours', 'عفوا , يمكنك التصويت كل {vote_expire_hours} ساعة ', 'main'),
(39, 'add2favorite', 'اضافة الى المفضلة', 'main'),
(40, 'add2fav_success', 'تمت الاضافة الى المفضلة', 'main'),
(41, 'register_closed', 'عفوا , التسجيل مغلق', 'main'),
(42, 'no_news', 'لا توجد أخبار', 'main'),
(43, 'err_vote_file_expire_hours', 'عفوا , يمكنك تقييم الملف كل {vote_expire_hours} ساعة ', 'main'),
(44, 'the_phrases', 'العبارات', 'cp'),
(45, 'welcome_to_cp', 'أهلا بك في لوحة التحكم', 'cp'),
(46, 'php_version', 'إصدار PHP', 'cp'),
(47, 'mysql_version', 'إصدار MySQL', 'cp'),
(49, 'the_version', 'الاصدار', 'cp'),
(50, 'cp_available', 'متوفرة', 'cp'),
(51, 'cp_not_available', 'غير متوفرة', 'cp'),
(52, 'gd_library', 'مكتبة GD', 'cp'),
(53, 'gd_install_required', 'يجب عليك تثبيت مكتبة GD لكي يعمل السكريبت على سيرفرك بشكل جيد', 'cp'),
(54, 'cp_addons', 'الإضافات', 'cp'),
(55, 'no_addons', 'لا توجد اضافات', 'cp'),
(56, 'edit', 'تعديل', 'cp'),
(57, 'register', 'التسجيل', 'main'),
(58, 'register_email_exists', 'خطأ :  هذا البريد موجود مسبقا <br>  اذا كان هذا هو بريدك الالكتروني و نسيبت كلمة المرور', 'main'),
(59, 'register_user_exists', 'عفوا .. اسم المستخدم {username} موجود مسبقا , يرجى استخدام اسم مستخدم آخر', 'main'),
(60, 'reg_complete', 'لقد تم اكمال عملية التسجيل بنجاح .', 'main'),
(61, 'err_fileds_not_complete', 'تأكد من تعبئة جميع الحقول', 'main'),
(62, 'err_passwords_not_match', 'كلمة المرور و تأكيدها غير متطابقين', 'main'),
(63, 'email', 'البريد الالكتروني', 'main'),
(64, 'username', 'اسم المستخدم', 'main'),
(65, 'password', 'كلمة المرور', 'main'),
(66, 'cp_login_do', 'تسجيل الدخول', 'cp'),
(67, 'cp_username', 'اسم المستخدم', 'cp'),
(68, 'cp_password', 'كلمة المرور', 'cp'),
(69, 'the_content_type', 'نوع المحتوى', 'cp'),
(70, 'the_url', 'الرابط', 'cp'),
(71, 'bnr_appearance_places', 'مكان الظهور', 'cp'),
(72, 'bnr_appearance_pages', 'صفحات الظهور', 'cp'),
(73, 'add_after_menu_number', 'اضافة بعد قائمة رقم', 'cp'),
(74, 'login_do', 'تسجيل الدخول', 'cp'),
(75, 'bnr_ctype_code', 'كود', 'cp'),
(76, 'bnr_ctype_img', 'صورة / رابط', 'cp'),
(77, 'the_code', 'الكود', 'cp'),
(78, 'bnr_open', 'بانر فتحة', 'cp'),
(79, 'bnr_close', 'بانر قفلة', 'cp'),
(80, 'bnr_menu', 'اعلان قائمة', 'cp'),
(81, 'bnr_header', 'بانر هيدر', 'cp'),
(82, 'bnr_footer', 'بانر فوتر', 'cp'),
(83, 'bnr_menu_pos', 'في', 'cp'),
(84, 'the_left', 'اليسار', 'cp'),
(85, 'the_center', 'الوسط', 'cp'),
(86, 'the_right', 'اليمين', 'cp'),
(87, 'bnr_the_menu', 'القائمة', 'cp'),
(88, 'bnr_the_visits', 'الزيارات', 'cp'),
(89, 'bnr_appearance_count', 'مرات الظهور', 'cp'),
(90, 'add_button', 'اضافة', 'cp'),
(91, 'the_order', 'الترتيب', 'cp'),
(92, 'the_image', 'الصورة', 'cp'),
(93, 'the_title', 'العنوان', 'cp'),
(94, 'delete', 'حذف', 'cp'),
(95, 'pages_lang', 'لغة الصفحات', 'cp'),
(96, 'pages_encoding', 'ترميز الصفحات', 'cp'),
(97, 'cp_enable_browsing', 'تصفح الموقع', 'cp'),
(98, 'cp_opened', 'مفتوح', 'cp'),
(99, 'cp_closed', 'مغلق', 'cp'),
(100, 'cp_browsing_closing_msg', 'رسالة الإغلاق', 'cp'),
(101, 'site_closed_for_visitors', 'الموقع مغلق للزوار', 'main'),
(102, 'cp_mailing_sending_to', 'مراسلة ', 'cp'),
(103, 'cp_send_as', 'إرسال كـ', 'cp'),
(104, 'cp_as_email', 'بريد الكتروني', 'cp'),
(105, 'next_page', 'الصفحة التالية', 'cp'),
(106, 'failed', 'فشل', 'cp'),
(107, 'cp_as_pm', 'رسالة خاصة', 'cp'),
(108, 'cp_send_to', 'إرسال الى', 'cp'),
(109, 'all_members', 'جميع الأعضاء', 'cp'),
(110, 'one_member', 'عضو محدد', 'cp'),
(111, 'sender_name', 'اسم المرسل', 'cp'),
(112, 'sender_email', 'بريد المرسل', 'cp'),
(113, 'msg_type', 'نوع الرسالة', 'cp'),
(114, 'msg_encoding', 'ترميز الرسالة', 'cp'),
(115, 'msg_subject', 'موضوع الرسالة', 'cp'),
(116, 'start_from', 'البدء من', 'cp'),
(117, 'mailing_emails_perpage', 'العدد كل صفحة', 'cp'),
(118, 'auto_pages_redirection', 'انتقال تلقائي بين الصفحات', 'cp'),
(119, 'cp_url_fopen_disabled_msg', 'اعدادات السيرفر لا تسمح بسحب ملف عن طريق رابط خارجي', 'cp'),
(120, 'err_url_x_invalid', 'الرابط {url} غير صحيح', 'cp'),
(121, 'local_file_uploader', 'رفع من الجهاز', 'cp'),
(122, 'external_file_uploader', 'سحب من رابط خارجي', 'cp'),
(123, 'cp_photo_resize_width', 'عرض', 'cp'),
(124, 'cp_photo_resize_hieght', 'طول', 'cp'),
(125, 'view', 'عرض', 'cp'),
(126, 'members_mailing', 'مراسلة الأعضاء', 'cp'),
(127, 'yes', 'نعم', 'main'),
(128, 'no', 'لا', 'main'),
(129, 'cp_mng_members', 'ادارة الأعضاء', 'cp'),
(130, 'members_custom_fields', 'الخانات الاضافية للأعضاء', 'cp'),
(131, 'cp_members_remote_db', 'قاعدة بيانات خارجية', 'cp'),
(132, 'the_members', 'الأعضاء', 'cp'),
(133, 'cp_add_new_template', 'اضافة قالب جديد', 'cp'),
(134, 'the_description', 'الوصف', 'cp'),
(135, 'cp_edit_templates', 'تعديل القوالب', 'cp'),
(136, 'main_page', 'الرئيسية', 'cp'),
(137, 'the_templates', 'القوالب', 'cp'),
(138, 'style_settings', 'اعدادات', 'cp'),
(139, 'add_style', 'اضافة ستايل جديد', 'cp'),
(140, 'style_selectable', 'يمكن للزوار اختياره', 'cp'),
(141, 'template_name', 'اسم القالب', 'cp'),
(142, 'template_description', 'وصف القالب', 'cp'),
(143, 'add_new_template', 'اضافة قالب جديد', 'cp'),
(144, 'are_you_sure', 'هل انت متأكد ؟', 'cp'),
(145, 'the_database', 'قاعدة البيانات', 'cp'),
(146, 'backup', 'نسخة احتياطية', 'cp'),
(147, 'db_repair_tables_do', 'اصلاح الجداول', 'cp'),
(148, 'cp_db_backup_do', 'اخذ نسخة احتياطية الآن', 'cp'),
(149, 'the_file_path', 'مسار الملف', 'cp'),
(150, 'db_backup_saveto_server', 'حفظ النسخة في السيرفر', 'cp'),
(151, 'db_backup_saveto_pc', 'حفظ النسخة الى الجهاز', 'cp'),
(152, 'cp_db_backup', 'نسخة احتياطية من قاعدة البيانات', 'cp'),
(153, 'the_size', 'الحجم', 'cp'),
(154, 'the_table', 'الجدول', 'cp'),
(155, 'the_status', 'الحالة', 'cp'),
(156, 'please_select_tables_to_rapair', 'يرجى اختيار الجداول المراد اصلاحها', 'cp'),
(157, 'cp_repairing_table', 'إصلاح الجدول', 'cp'),
(158, 'done', 'تم', 'cp'),
(159, 'cp_db_check_repair', 'فحص / اصلاح', 'cp'),
(160, 'backup_done_successfully', 'تمت العملية بنجاح', 'cp'),
(161, 'the_search', 'البحث', 'cp'),
(162, 'members_count', 'عدد الأعضاء', 'cp'),
(163, 'cp_remote_members_db', 'قاعدة بيانات أعضاء خارجية ', 'cp'),
(164, 'use_remote_db', 'استخدام قاعدة بيانات خارجية', 'cp'),
(165, 'db_host', 'عنوان السيرفر', 'cp'),
(166, 'db_name', 'اسم قاعدة البيانات', 'cp'),
(167, 'db_username', 'اسم مستخدم البيانات', 'cp'),
(168, 'members_table', 'جدول الأعضاء', 'cp'),
(169, 'note', 'ملاحظة', 'cp'),
(170, 'members_remote_db_wizzard_note', 'عند استخدام قاعدة بيانات اعضاء جديدة يجب عليك استخدام معالج قواعد بيانات الاعضاء للتأكد من توافق قاعدة البيانات و اعدادها للعمل', 'cp'),
(171, 'members_remote_db_wizzard', 'معالج قواعد بيانات الأعضاء', 'cp'),
(172, 'chng_field_type_success', 'تم تغيير نوع الخانة في قاعدة البيانات بنجاح', 'cp'),
(173, 'chng_field_type_failed', 'لم يتمكن السكريبت من تغيير نوع الخانة , يرجى تغييرها يدويا من مدير قاعدة البيانات', 'cp'),
(174, 'add_field_failed', 'لم يتمكن السكريبت من اضافة الخانة , يرجى اضافتها يدويا من مدير قاعدة البيانات', 'cp'),
(175, 'add_field_success', 'تمت اضافة الخانة الى قاعدة البيانات بنجاح', 'cp'),
(176, 'members_remote_db_compatible', 'قاعدة البيانات متوافقة مع السكريبت', 'cp'),
(177, 'members_remote_db_uncompatible', 'قاعدة البيانات غير متوافقة مع السكريبت , يرجى مراجعة الأخطاء و اصلاحهم ثم اعادة الاختبار', 'cp'),
(178, 'wrong_remote_db_name', 'اسم قاعدة البيانات خاطيء , يرجى التأكد منه', 'cp'),
(179, 'wrong_remote_db_connect_info', 'خطأ اثناء الاتصال بالقاعدة , يرجى التأكد من بيانات الاتصال', 'cp'),
(180, 'members_remote_db_disabled', 'النظام غير مفعل', 'cp'),
(181, 'no_members_custom_fields', 'لا توجد خانات اضافية', 'cp'),
(182, 'add_member_custom_field', 'اضافة خانة اضافية', 'cp'),
(183, 'the_type', 'النوع', 'cp'),
(184, 'textbox', 'صندوق نص', 'cp'),
(185, 'textarea', 'صندوق نص متعدد الاسطر', 'cp'),
(186, 'select_menu', 'قائمة منسدلة', 'cp'),
(187, 'radio_button', 'زر اختيار', 'cp'),
(188, 'checkbox', 'خانة اختيار', 'cp'),
(189, 'default_value_or_options', 'القيمة الافتراضية / الخيارات', 'cp'),
(190, 'put_every_option_in_sep_line', 'للخيارات يتم وضع كل خيار في سطر جديد', 'cp'),
(191, 'required', 'مطلوب', 'cp'),
(192, 'addition_style', 'تنسيق اضافي', 'cp'),
(193, 'addition_fields', 'معلومات اضافية', 'cp'),
(194, 'this_member_not_exists', 'هذا العضو غير موجود', 'cp'),
(195, 'members_local_db_clean_wizzard', 'معالج تنظيف جداول الاعضاء المحلية', 'cp'),
(196, 'members_local_db_clean_note', 'عند استخدام قاعدة بيانات محلية او خارجية يتم تخزين بيانات الخانات الاضافية و المفضلة و الرسائل الخاصة و غيرها على بعض الجداول في قاعدة البيانات المحلية , لذلك يفضل تنظيف هذه الجدوال لتسريع عمل القاعدة و تجنبا لعدم حصول اي تداخل في البيانات', 'cp'),
(197, 'members_local_db_clean_description', 'سوف يقوم المعالج بحذف اي بينات تتعلق بالأعضاء كما هو موضح , يرجى التأكد ان الجداول التالية لا تحتوي على اي بيانات ضرورية ثم الضغط على زر التنفيذ ', 'cp'),
(198, 'members_msgs_table', 'جدول رسائل الأعضاء الخاصة', 'cp'),
(199, 'members_favorite_table', 'جدول بيانات الملفات المفضلة للأعضاء', 'cp'),
(200, 'members_custom_fields_table', 'جدول بيانات الخانات الاضافية للأعضاء', 'cp'),
(201, 'members_confirmations_table', 'جدول تأكيدات التغيرات للأعضاء', 'cp'),
(202, 'process_done_successfully', 'تمت العملية بنجاح', 'cp'),
(274, 'from', 'من', 'cp'),
(275, 'plz_enter_username_and_pwd', 'يرجى التأكد من ادخال اسم المستخدم وكلمة المرور', 'main'),
(204, 'pwd_rest_request_msg_subject', 'طلب تغيير كلمة المرور', 'cp'),
(205, 'rest_pwd_request_msg_sent', 'تم ارسال رسالة الى بريدك الالكتروني تحتوي رابط تغيير كلمة المرور', 'cp'),
(206, 'pwd_rest_done_msg_subject', 'كلمة مرورك الجديدة !', 'cp'),
(207, 'pwd_rest_done', 'لقد تم تغيير كلمة مرورك و ارسال كلمة المرور الجديدة الى بريدك الالكتروني', 'cp'),
(208, 'security_code', 'كود التحقق', 'cp'),
(209, 'email_activation_msg_subject', 'تفعيل بريدك الالكتروني', 'cp'),
(210, 'upload_file', 'رفع ملف', 'cp'),
(211, 'search_do', 'بحث', 'cp'),
(212, 'birth', 'تاريخ الميلاد', 'main'),
(213, 'country', 'الدولة', 'main'),
(214, 'select_from_menu', 'اختر من القائمة', 'main'),
(215, 'register_do', 'تسجيل', 'main'),
(216, 'registered_before', 'انت مسجل لدينا مسبقا', 'main'),
(217, 'click_here', 'اضغط هنا', 'main'),
(218, 'forgot_pass', 'نسيت كلمة المرور ؟', 'main'),
(219, 'login_info_sent', 'لقد تم ارسال معلومات الدخول الى بريدك الالكتروني', 'main'),
(220, 'email_not_exists', 'خطأ : هذا البريد غير مسجل لدينا', 'main'),
(221, 'continue', 'متابعة', 'main'),
(222, 'active_account', 'تفعيل الاشتراك', 'main'),
(223, 'active_acc_succ', 'لقد تم تفعيل اشتراكك بنجاح', 'main'),
(224, 'active_acc_err', 'عفوا .. لم يتم التفعيل , قد يكون تم تفعيله مسبقا أو هنالك خطأ في الرابط', 'main'),
(225, 'login', 'تسجيل دخول', 'main'),
(226, 'newuser', 'مستخدم جديد ؟', 'main'),
(227, 'err_function_usage_denied', 'خطأ : لا يمكنك استعمال الدالة', 'main'),
(228, 'err_emails_not_match', 'البريد الإلكتروني و تأكيده غير متطابقين', 'main'),
(229, 'email_confirm', 'تأكيد البريد الإلكتروني', 'main'),
(230, 'err_sec_code_not_valid', 'كود التحقق غير صحيح', 'main'),
(231, 'registration', 'التسجيل', 'cp'),
(232, 'as_every_cat_settings', 'اعدادات كل قسم', 'cp'),
(233, 'enabled_for_all', 'مفعل للكل', 'cp'),
(234, 'stng_download_for_members_only', 'التحميل للأعضاء فقط', 'cp'),
(235, 'security_code_in_registration', 'كود التحقق في التسجيل', 'cp'),
(236, 'auto_email_activate', 'تفعيل البريد الالكتروني تلقائيا', 'cp'),
(237, 'username_min_letters', 'اقل عدد حروف لإسم المستخدم', 'cp'),
(238, 'username_exludes', 'استثنائات اسم المستخدم', 'cp'),
(239, 'emails_msgs_default_type', 'نوع رسائل البريد الالكتروني الافتراضية', 'cp'),
(240, 'emails_msgs_default_encoding', 'ترميز رسائل البريد الالكتروني الافتراضية', 'cp'),
(241, 'leave_blank_to_use_site_encoding', 'اتركه فارغا لإستخدام ترميز الموقع الافتراضي', 'cp'),
(242, 'uploader_system', 'نظام رفع الملفات', 'cp'),
(243, 'disable_uploader_msg', 'رسالة عدم التفعيل', 'cp'),
(244, 'uploader_path', 'مسار الرفع', 'cp'),
(245, 'uploader_allowed_types', 'الأنواع المسموح رفعها', 'cp'),
(246, 'enabled', 'مفعل', 'cp'),
(247, 'disabled', 'معطل', 'cp'),
(248, 'password_confirm', 'تأكيد كلمة المرور', 'main'),
(249, 'err_username_min_letters', 'عدد حروف اسم المستخدم اقل من المسموح به', 'main'),
(250, 'err_email_not_valid', 'البريد الالكتروني غير صحيح', 'main'),
(251, 'err_username_not_allowed', 'اسم المستخدم غير مسموح به', 'main'),
(252, 'reg_complete_need_activation', 'لقد تم اكمال عملية التسجيل بنجاح . سوف يتم ارسال رسالة الى بريد الالكتروني تحتوي على رابط تفعيل اشتراكك', 'main'),
(253, 'req_addition_info', 'معلومات اضافية مطلوبة', 'main'),
(254, 'not_req_addition_info', 'معلومات غير مطلوبة', 'main'),
(255, 'your_email_changed_successfully', 'تم تغيير بريدك الالكتروني بنجاح', 'main'),
(256, 'this_account_already_activated', 'عفوا , هذا الحساب تم تفعيله مسبقا', 'main'),
(257, 'closed_account_cannot_activate', 'عفوا, هذا الحساب مغلق لا يمكنك تفعيله', 'main'),
(258, 'activation_msg_sent_successfully', 'لقد تم ارسال رسالة تفعيل الاشتراك الى بريدك الالكتروني بنجاح', 'main'),
(259, 'register_date', 'تاريخ التسجيل', 'cp'),
(260, 'last_login', 'آخر دخول', 'cp'),
(261, 'member_deleted_successfully', 'تم حذف العضو بنجاح', 'cp'),
(262, 'member_added_successfully', 'تم اضافة العضو بنجاح', 'cp'),
(263, 'please_fill_all_fields', 'يرجى اكمال جميع الحقول', 'cp'),
(264, 'member_edited_successfully', 'تم تعديل العضو بنجاح', 'cp'),
(265, 'add_member', 'اضافة عضو', 'cp'),
(266, 'records_perpage', 'السجلات في الصفحة', 'cp'),
(267, 'member_edit', 'تعديل عضو', 'cp'),
(268, 'member_acc_type', 'نوع الحساب', 'cp'),
(269, 'send_msg_to_member', 'أرسل رسالة للعضو', 'cp'),
(270, 'acc_type_not_activated', 'غير منشط', 'cp'),
(271, 'acc_type_activated', 'مفعل', 'cp'),
(272, 'acc_type_closed', 'مغلق', 'cp'),
(273, 'leave_blank_for_no_change', 'أتركه فارغا لعدم التغيير', 'cp'),
(276, 'this_account_closed_cant_login', 'عفوا, هذا الحساب مغلق , غير مصرح لك بالدخول', 'main'),
(277, 'this_account_not_activated', 'خطأ , لم يتم تفعيل العضوية بعد', 'main'),
(278, 'chng_email_msg_subject', 'تأكيد تغيير بريدك الإلكتروني', 'main'),
(279, 'resend_activation_msg', 'اعادة ارسال رسالة التفعيل', 'main'),
(280, 'invalid_pwd', 'خطأ, كلمة المرور غير صحيحة', 'main'),
(281, 'invalid_username', 'خطأ, اسم المستخدم غير صحيح', 'main'),
(282, 'usercp_menu', 'قائمة التحكم', 'main'),
(283, 'usercp_welcome_msg', 'أهلا بك يا {username} في لوحة التحكم', 'main'),
(284, 'cp_hooks_fix_order', 'ترتيب تلقائي', 'cp'),
(285, 'cp_hooks', 'الاضافات البرمجية المدمجة', 'cp'),
(286, 'no_hooks', 'لا توجد اضافات', 'cp'),
(287, 'add', 'اضافة', 'cp'),
(288, 'the_place', 'المكان', 'cp'),
(289, 'the_options', 'الخيارات', 'cp'),
(290, 'the_default_template', 'القالب الافتراضي', 'cp'),
(291, 'the_videos', 'الكليبات', 'cp'),
(292, 'the_news', 'الأخبار', 'cp'),
(293, 'the_votes', 'الاستفتائات', 'cp'),
(294, 'the_statics', 'الاحصائيات', 'cp'),
(295, 'appearance_places', 'أماكن الظهور', 'cp'),
(296, 'the_blocks', 'القوائم', 'cp'),
(297, 'the_position', 'الموقع', 'cp'),
(298, 'right', 'يمين', 'cp'),
(299, 'center', 'وسط', 'cp'),
(300, 'left', 'يسار', 'cp'),
(301, 'the_template', 'القالب', 'cp'),
(302, 'to_up', 'الى الأعلى', 'cp'),
(303, 'to_down', 'الى الأسفل', 'cp'),
(304, 'enable', 'تنشيط', 'cp'),
(305, 'disable', 'تعطيل', 'cp'),
(306, 'cp_blocks_fix_order', 'تصحيح ترتيب القوائم تلقائيا', 'cp'),
(307, 'cp_no_blocks', 'لا توجد قوائم', 'cp'),
(308, 'the_content', 'المحتوى', 'cp'),
(309, 'logout', 'تسجيل خروج', 'cp'),
(310, 'the_settings', 'الإعدادات', 'cp'),
(311, 'do_button', 'تنفيذ', 'cp'),
(312, 'news_add', 'اضافة خبر', 'cp'),
(313, 'news_short_content', 'النص الخارجي', 'cp'),
(314, 'auto_short_content_create', 'انشاء النص الخارجي تلقائيا', 'cp'),
(315, 'the_date', 'التاريخ', 'main'),
(316, 'all', 'الكل', 'main'),
(317, 'view_do', 'عرض', 'main'),
(318, 'os_and_browsers_statics', 'احصائيات المتصفحات و النظم', 'cp'),
(319, 'visitors_hits_statics', 'احصائيات زيارات الزوار', 'cp'),
(320, 'online_visitors_statics', 'احصائيات المتواجدون الآن', 'cp'),
(321, 'default_style', 'الستايل الافتراضي', 'cp'),
(322, 'search_min_letters', 'أقل عدد للأحرف في البحث', 'cp'),
(323, 'sorry_search_disabled', 'نأسف لك , لقد قامت الادارة بتعطيل البحث', 'main'),
(324, 'uploader_title', 'رفع الملفات', 'cp'),
(325, 'pixel', 'بيكسل', 'cp'),
(326, 'this_filetype_not_allowed', 'نوع الملف غير مسموح به', 'cp'),
(327, 'the_file', 'الملف', 'cp'),
(328, 'auto_photos_resize', 'تصغير تلقائي للصور', 'cp'),
(329, 'upload_file_do', 'رفع الملف', 'cp'),
(330, 'allowed_filetypes', 'الأنواع المسموح رفعها', 'cp'),
(331, 'please_login_first', 'يرجى تسجيل الدخول اولا', 'cp'),
(332, 'uploader_thumb_width', 'عرض المصغرة الافتراضي', 'cp'),
(333, 'uploader_thumb_hieght', 'طول المصغرة الافتراضي', 'cp'),
(334, 'fixed', 'ثابت', 'cp'),
(335, 'send2friend_failed', 'خطأ أثناء الارسال .. حاول مرة اخرى', 'main'),
(336, 'invalid_from_or_to_email', 'يرجى التأكد من صحة بريدك او بريد صديقك الالكتروني', 'main'),
(337, 'bnr_listen', 'الاستماع الخارجي', 'cp'),
(338, 'urls_fields', 'خانات روابط الأغاني', 'cp'),
(339, 'urls_fields_add', 'اضافة رابط اضافي', 'cp'),
(340, 'access_denied', 'غير مصرح بالدخول', 'cp'),
(341, 'no_singers', 'لا يوجد مغنيين', 'cp'),
(342, 'the_cat', 'القسم', 'cp'),
(343, 'singers_list', 'قائمة المغنيين', 'cp'),
(344, 'singer', 'مغني', 'cp'),
(345, 'album', 'البوم', 'cp'),
(346, 'the_albums', 'الألبومات', 'cp'),
(347, 'no_new_files', 'لا توجد ملفات جديدة', 'cp'),
(348, 'err_autosearch_folder_not_exists', 'مجلد البحث التلقائي غير صحيح , يرجى التأكد من اسم المجلد و التجربة مرة اخرى', 'cp'),
(349, 'auto_search', 'البحث التلقائي', 'cp'),
(350, 'add_songs', 'اضافة اغاني', 'cp'),
(351, 'new_songs_menu', 'قائمة جديد الأغاني', 'cp'),
(352, 'new_stores_menu', 'قائمة جديد السوق', 'cp'),
(353, 'the_banners', 'الاعلانات', 'cp'),
(354, 'users_and_permissions', 'المستخدمين و التصاريح', 'cp'),
(355, 'permissions_manage', 'ادارة التصاريح', 'cp'),
(356, 'cp_sections_permissions', 'صلاحيات الدخول للأقسام', 'cp'),
(357, 'videos_cats_permissions', 'تصاريح أقسام الكليبات', 'cp'),
(358, 'songs_cats_permissions', 'تصاريح أقسام الأغاني', 'cp'),
(359, 'cp_err_username_exists', 'خطأ .. اسم المستخدم الذي قمت بإدخاله موجود مسبقا', 'cp'),
(360, 'cp_plz_enter_usr_pwd', 'يرجى ادخال اسم المستخدم و كلمة المرور', 'cp'),
(361, 'cp_edit_user_success', 'تم تعديل المستخدم بنجاح', 'cp'),
(362, 'cp_add_user', 'اضافة مستخدم', 'cp'),
(363, 'cp_email', 'البريد الإلكتروني', 'cp'),
(364, 'cp_user_group', 'الرتبة', 'cp'),
(365, 'cp_user_admin', 'مدير', 'cp'),
(366, 'cp_user_mod', 'مشرف', 'cp'),
(367, 'the_users', 'المستخدمين', 'cp'),
(368, 'edit_personal_acc_only', 'صلاحياتك لا تسمح إلا بتعديل حسابك الشخصي فقط', 'cp'),
(369, 'click_here_to_edit_ur_account', 'لتعديل حسابك إضغط هنا', 'cp'),
(372, 'the_pages', 'الصفحات', 'cp'),
(373, 'pages_add', 'اضافة صفحة', 'cp'),
(374, 'no_pages', 'لا توجد صفحات', 'cp'),
(375, 'err_cat_access_denied', 'لاتملك الصلاحيات للدخول الى هذ القسم', 'cp'),
(376, 'songs_custom_fields', 'خانات الأغاني الاضافية', 'cp'),
(377, 'songs_field_add', 'اضافة خانة جديدة', 'cp'),
(378, 'no_data', 'لا توجد بيانات', 'cp'),
(381, 'songs_default_orderby', 'الترتيب الافتراضي للأغاني', 'cp'),
(380, 'field_style', 'تنسيق اضافي', 'cp'),
(382, 'asc', 'تصاعديا', 'cp'),
(383, 'desc', 'تنازليا', 'cp'),
(384, 'visitors_can_sort_songs', 'امكانية الزوار من اختيار ترتيب الأغاني', 'cp'),
(386, 'the_most_voted', 'الأكثر تقييما', 'cp'),
(387, 'songs_orderby_text', 'الترتيب حسب', 'cp'),
(388, 'the_download', 'التحميل', 'cp'),
(389, 'download_for_all_visitors', 'مفتوح', 'cp'),
(390, 'download_for_members_only', 'للأعضاء فقط', 'cp'),
(391, 'stng_videos_download_for_members_only', 'تحميل الكليبات للأعضاء فقط', 'cp'),
(392, 'add_to_playlist', 'اضافة الى قائمة التشغيل', 'cp'),
(393, 'stng_songs_multi_select', 'امكانية الزوار من التحديد المتعدد للأغاني', 'cp'),
(394, 'playlists_add', 'اضافة قائمة تشغيل جديدة', 'main'),
(395, 'playlists_del', 'حذف قائمة التشغيل الحالية', 'main'),
(396, 'printable_copy', 'نسخة للطباعة', 'main'),
(397, 'members_playlists_table', 'جدول قوائم التشغيل', 'cp'),
(398, 'singers_other_letters', 'غير ذلك', 'main'),
(399, 'the_favorite', 'المفضلة', 'main'),
(400, 'no_files', 'لا توجد ملفات', 'main'),
(401, 'send_new_msg', 'ارسل رسالة جديدة', 'main'),
(402, 'the_messages', 'الرسائل', 'main'),
(403, 'used_messages', 'رسالة مستعملة', 'main'),
(404, 'pm_box_full_warning', 'تحذير : بريدك ممتليء , لن تتمكن من استقبال اي رسائل جديدة', 'main'),
(405, 'no_messages', 'لا توجد رسائل', 'main'),
(406, 'the_sender', 'المرسل', 'main'),
(407, 'the_subject', 'الموضوع', 'main'),
(408, 'reply', 'رد', 'main'),
(409, 'err_sendto_pm_box_full', 'خطأ : البريد الذي تحاول الارسال اليه ممتليء', 'main'),
(410, 'pm_sent_successfully', 'لقد تم ارسال رسالتك بنجاح', 'main'),
(411, 'err_sendto_username_invalid', 'خطأ .. اسم المستخدم المرسل اليه غير صحيح . يرجى التأكد منه و المحاولة مرة اخرى', 'main'),
(412, 'the_message', 'الرسالة', 'main'),
(413, 'chng_email_conf_msg_sent', 'تم ارسال رسالة لك تحتوي رابط تفعيل بريدك الالكتروني الجديد', 'main'),
(414, 'your_profile_updated_successfully', 'تم تحديث بياناتك بنجاح', 'main'),
(415, 'the_profile', 'الملف الشخصي', 'main'),
(416, 'default_playlist', 'القائمة الافتراضية', 'main'),
(417, 'err_wrong_uploader_folder', 'خطأ في مجلد التحميل', 'cp'),
(418, 'register_email_exists2', 'اذا كان هذا هو بريدك الالكتروني و نسيبت كلمة المرور', 'cp'),
(419, 'the_statics_and_counters', 'الاحصائيات و العدادات', 'cp'),
(420, 'cp_visitors_statics', 'احصائيات الزوار', 'cp'),
(421, 'cp_counters_start_date', 'تاريخ بدء العدادات', 'cp'),
(422, 'cp_total_visits', 'مجموع الزيارات', 'cp'),
(423, 'the_hour', 'الساعة', 'cp'),
(424, 'operating_systems', 'أنظمة التشغيل', 'main'),
(425, 'the_browsers', 'المتصفحات', 'main'),
(426, 'monthly_statics_for', 'إحصائيات الزوار الشهرية لعام', 'main'),
(427, 'daily_statics_for', 'إحصائيات الزوار اليومية لشهر', 'main'),
(428, 'the_year', 'العام', 'main'),
(429, 'the_month', 'الشهر', 'main'),
(430, 'right_to_left', 'من اليمن الى اليسار', 'cp'),
(431, 'left_to_right', 'من اليسار الى اليمين', 'cp'),
(432, 'page_dir', 'اتجاه الصفحة', 'cp'),
(433, 'mailing_email', 'بريد المراسلة', 'cp'),
(434, 'copyrights_sitename', 'اسم الموقع في نص الحقوق', 'cp'),
(435, 'section_name', 'اسم القسم', 'cp'),
(436, 'site_name', 'اسم الموقع', 'cp'),
(437, 'page_keywords', 'كلمات مساعدة', 'cp'),
(438, 'votes_expire_time', 'الوقت الفاصل في الاستفتائات', 'cp'),
(439, 'hour', 'ساعة', 'cp'),
(440, 'the_songs_cats', 'أقسام الأغاني', 'cp'),
(441, 'the_songs_and_singers', 'المغنين و الأغاني', 'cp'),
(442, 'the_songs_exts', 'ملحقات الأغاني', 'cp'),
(443, 'add_edit_videos', 'إضافة / تعديل الكليبات', 'cp'),
(444, 'bnr_views', 'ظهور', 'cp'),
(445, 'bnr_visits', 'زيارة', 'cp'),
(446, 'del_cat_warning', 'تحذير : حذف هذا القسم سوف يؤدي الى حذف جميع المغنيين و الأغاني التي يحتويها , هل تريد المتابعة ؟', 'cp'),
(447, 'show_download_icon', 'اظهار ايقونة التحميل', 'cp'),
(448, 'the_download_icon', 'ايقونة التحميل', 'cp'),
(449, 'download_icon_alt', 'وصف أيقونة التحميل', 'cp'),
(450, 'show_listen_icon', 'اظهار ايقونة الاستماع', 'cp'),
(451, 'the_listen_icon', 'أيقونة الاستماع', 'cp'),
(452, 'listen_icon_alt', 'وصف أيقونة الاستماع', 'cp'),
(453, 'listen_file_mime', 'نوع ملف الاستماع', 'cp'),
(454, 'listen_file_name', 'اسم ملف الاستماع', 'cp'),
(455, 'listen_file_content', 'محتوى ملف الاستماع', 'cp'),
(456, 'the_cats', 'الأقسام', 'cp'),
(457, 'del_video_cat_warning', 'حذف هذا القسم سوف يؤدي الى حذف جميع الكليبات التي يحتويها , هل تريد المتابعة ؟', 'cp'),
(458, 'add_video', 'اضافة كليب', 'cp'),
(459, 'add_cat', 'اضافة قسم', 'cp'),
(460, 'no_videos_or_no_permissions', 'لاتوجد كليبات او انك لا تملك الصلاحيات لمشاهدة هذا القسم', 'cp'),
(461, 'default', 'افتراضي', 'cp'),
(462, 'view_page', 'مشاهدة الصفحة', 'cp'),
(463, 'vote_add', 'اضافة تصويت جديد', 'cp'),
(464, 'set_default', 'تعيين افتراضي', 'cp'),
(465, 'edit_or_options', 'تعديل / خيارات', 'cp'),
(466, 'add_options', 'اضافة خيارات', 'cp'),
(467, 'vote_files_expire_time', 'الوقت الفاصل في تقييم الملفات', 'cp'),
(468, 'images_cells_count', 'عدد أعمدة الصور', 'cp'),
(469, 'news_perpage', 'عدد الأخبار في الصفحة الواحدة', 'cp'),
(470, 'back_to_cats', 'الرجوع الى الأقسام', 'cp'),
(471, 'singer_add', 'اضافة مغني', 'cp'),
(472, 'no_singers_or_no_permissions', 'لا يوجد مغنيين او انك لا تملك صلاحيات لإدارة مجموعات المغنيين هذه', 'cp'),
(473, 'move_songs', 'نقل الأغاني', 'cp'),
(474, 'move_from', 'نقل من', 'cp'),
(475, 'move_to', 'نقل الى', 'cp'),
(476, 'please_select_songs_first', 'يرجى تحديد الأغاني أولا', 'cp'),
(477, 'next', 'التالي', 'cp'),
(478, 'without_album', 'بدون ألبوم', 'cp'),
(479, 'the_album', 'الألبوم', 'cp'),
(480, 'move_do', 'نقل', 'cp'),
(481, 'back_to_singers', 'الرجوع الى المغنيين', 'cp'),
(482, 'edit_singer', 'تعديل المغني', 'cp'),
(483, 'del_singer_warning', 'حذف المغني سوف يؤدي الى حذف جميع ألبوماته و أغاني .. هل تريد المتابعة ؟ ', 'cp'),
(484, 'song', 'أغنية', 'cp'),
(485, 'select_all', 'تحديد الكل', 'cp'),
(486, 'select_none', 'الغاء التحديد', 'cp'),
(487, 'change_ext', 'تغيير الملحق', 'cp'),
(488, 'move_to_album', 'انقلهم الى الألبوم', 'cp'),
(489, 'move_to_singer', 'نقل الى مغني', 'cp'),
(490, 'edit_songs', 'تعديل الأغاني', 'cp'),
(491, 'delete_songs', 'حذف الأغاني', 'cp'),
(492, 'add_to_new_songs_menu', 'اضافة الى جديد الاغاني', 'cp'),
(493, 'without_ext', 'بدون ملحق', 'cp'),
(494, 'the_comment', 'التعليق', 'cp'),
(495, 'fields_count', 'عدد الحقول', 'cp'),
(496, 'edit_album', 'تعديل الألبوم', 'cp'),
(497, 'singers_count', 'عدد المغنين', 'cp'),
(498, 'songs_count', 'عدد الأغاني', 'cp'),
(499, 'videos_count', 'عدد الكليبات', 'cp'),
(500, 'users_count', 'عدد المستخدمين', 'cp'),
(501, 'show_sitename_in_subpages', 'اظهار اسم الموقع في الصفحات الفرعية', 'cp'),
(502, 'show_section_name_in_subpages', 'اظهار اسم القسم في الصفحات الفرعية', 'cp'),
(503, 'adding_songs_fields_count', 'عدد الحقول في اضافة الاغاني', 'cp'),
(504, 'songs_perpage', 'عدد الأغاني في الصفحة الواحدة', 'cp'),
(505, 'videos_perpage', 'عدد الكليبات في الصفحة الواحدة', 'cp'),
(506, 'msgs_count_limit', 'حد الرسائل الخاصة', 'cp'),
(507, 'message', 'رسالة', 'cp'),
(508, 'stng_singers_letters', 'شريط الحروف للمغنيين', 'cp'),
(509, 'stng_songs_letters', 'شريط الحروف للأغاني', 'cp'),
(510, 'stng_vote_songs', 'تقييم الأغاني', 'cp'),
(511, 'stng_send_song', 'ارسال الأغنية لصديق', 'cp'),
(512, 'stng_group_singers_by_letters', 'عرض المغنيين في مجموعات حسب الحرف', 'cp'),
(513, 'stng_vote_videos', 'تقييم الكليبات', 'cp'),
(514, 'stng_send_videos', 'ارسال الكليبات لصديق', 'cp'),
(515, 'the_listen_file', 'ملف الاستماع', 'cp'),
(516, 'ram_banner_width', 'عرض نافذة الاعلانات', 'cp'),
(517, 'ram_banner_height', 'طول نافذة الاعلانات', 'cp'),
(518, 'listen_statics_rest_done', 'تم تصفير عدادات استماع الأغاني', 'cp'),
(519, 'download_statics_rest_done', 'تم تصفير عدادات تحميل الأغاني', 'cp'),
(520, 'votes_statics_rest_done', 'تم تصفير عدادات تقييم الأغاني', 'cp'),
(521, 'videos_watch_rest_done', 'تم تصفير عدادات مشاهدة الكليبات', 'cp'),
(522, 'videos_download_rest_done', 'تم تصفير عدادات تحميل الكليبات', 'cp'),
(523, 'videos_votes_rest_done', 'تم تصفير عدادات تقييم الكليبات', 'cp'),
(524, 'songs_listens_statics', 'استماع الأغاني', 'cp'),
(525, 'songs_downloads_statics', 'تحميل الأغاني', 'cp'),
(526, 'songs_votes_statics', 'تقييم الأغاني', 'cp'),
(527, 'videos_watch_statics', 'مشاهدة الكليبات', 'cp'),
(528, 'videos_download_statics', 'تحميل الكليبات', 'cp'),
(529, 'videos_votes_statics', 'تقييم الكليبات', 'cp'),
(530, 'err_invalid_song_id', '<b>خطأ : </b> يرجى التأكد من رقم الاغنية', 'cp'),
(531, 'song_id', 'رقم الاغنية', 'cp'),
(532, 'err_invalid_id', '<b>خطأ : </b> يرجى التأكد من الرقم', 'cp'),
(533, 'the_id', 'الرقم', 'cp'),
(534, 'without_title', 'بدون عنوان', 'cp'),
(535, 'cp_rest_counters', 'تصفير العدادات', 'cp'),
(536, 'cp_rest_counters_do', 'تصفير العدادات', 'cp'),
(537, 'visitors_statics_rest_done', 'تم تصفير عدادات الزوار', 'cp'),
(538, 'cp_no_phrases', 'لا توجد عبارات', 'cp'),
(539, 'cp_no_templates', 'لا توجد قوالب', 'cp'),
(540, 'cp_invalid_pwd', 'كلمة المرور غير صحيحة', 'cp'),
(541, 'cp_invalid_username', 'اسم المستخدم غير صحيح', 'cp'),
(542, 'cp_welcome_msg', 'أهلا و سهلا بك يا {username}', 'cp'),
(543, 'cp_statics', 'احصائيات', 'cp'),
(544, 'search', 'بحث', 'cp'),
(545, 'forgot_pwd_msg_subject', 'استرجاع كلمة المرور', 'cp'),
(546, 'without_selection', 'بدون اختيار', 'cp'),
(547, 'create_main_user', 'انشاء المستخدم الرئيسي', 'cp'),
(898, 'in_this_video', 'في هذا الكليب', 'main'),
(556, 'عدد أعمدة صور الفيلم', 'movie_photos_cells', 'cp'),
(562, 'rating_expire_msg', 'عفوا , يمكنك التقييم كل {hours} ساعة', 'cp'),
(563, 'the_files_count', 'عدد الملفات', 'main'),
(565, 'home_page', 'الرئيسية', 'main'),
(567, 'back_to_news', 'الرجوع الى الأخبار', 'main'),
(568, 'no_banners', 'لا توجد اعلانات', 'cp'),
(571, 'watch_for_members', 'المشاهدة للاعضاء فقط', 'cp'),
(572, 'download_for_members', 'التحميل للاعضاء فقط', 'cp'),
(573, 'cat_del_warn', 'حذف هذا القسم سوف يؤدي الى حذف جميع الأقسام و الأفلام التي يحتويها , هل تريد المتابعة ؟', 'cp'),
(574, 'add_by_name', 'اضافة بواسطة الاسم', 'cp'),
(575, 'news_votes', 'تقييم الاخبار', 'cp'),
(576, 'add_by_id', 'اضافة بواسطة الرقم', 'cp'),
(577, 'news_views', 'زيارات الاخبار', 'cp'),
(579, 'sex', 'الجنس', 'main'),
(580, 'male', 'ذكر', 'main'),
(581, 'female', 'أنثى', 'main'),
(594, 'click_and_drag_to_change_order', 'انقر و اسحب لتغيير الترتيب', 'cp'),
(595, 'access_log', 'سجل الدخول', 'cp'),
(596, 'comment_is_waiting_admin_review', 'تم اضافة تعليقك و في انتظار موافقة الادارة', 'cp'),
(598, 'admin_email', 'بريد الادارة', 'cp'),
(599, 'page_description', 'وصف الصفحة', 'cp'),
(600, 'hide_title', 'اخفاء العنوان', 'cp'),
(601, 'page_number_x', 'الصفحة {x}', 'main'),
(602, 'the_details', 'التفاصيل', 'cp'),
(605, 'default_value', 'القيمة الافتراضية', 'cp'),
(606, 'pages_links_settings', 'اعدادات روابط الصفحات', 'cp'),
(607, 'seo_settings', 'اعدادات SEO', 'cp'),
(608, 'pages_meta_settings', 'اعدادات بيانات الصفحات', 'cp'),
(610, 'months_ago', 'شهر', 'main'),
(611, 'weeks_ago', 'اسبوع', 'main'),
(612, 'images_folder', 'مجلد الصور', 'cp'),
(613, 'edit_templates', 'تعديل القوالب', 'cp'),
(614, 'you_can_edit_this_values_from_config_file', 'يمكنك تعديل هذه القيم من ملف الاعدادات config.php', 'cp'),
(617, 'new', 'جديد', 'main'),
(619, 'fields_options_add_note', 'بعد اضافة الخانة قم بالضغط على خيار التعديل لتعديل الخيارات', 'cp'),
(621, 'black_list_note', 'الاعضاء في هذه القائمة لن يتمكنوا من مراسلتك او رؤية ملفك الشخصي', 'main'),
(623, 'not_available_now', 'غير متوفر حاليا', 'main'),
(624, 'update', 'تحديث', 'main'),
(625, 'orderby', 'الترتيب حسب', 'main'),
(626, 'remove_from_fav', 'حذف من المفضلة', 'main'),
(627, 'to', 'الى', 'main'),
(629, 'enlarge_pic', 'اضغط لتكبير الصورة', 'main'),
(630, 'not_selected', 'غير محدد', 'main'),
(632, 'year_ago', 'سنة', 'main'),
(633, 'for_members_only', 'للأعضاء فقط', 'cp'),
(634, 'pm_send_denied', 'عفوا , لا يمكنك مراسلة هذا العضو', 'main'),
(635, 'add_to_friends_list', 'اضافة الى قائمة الاصدقاء', 'main'),
(636, 'last_page', 'الصفحة الأخيرة', 'main'),
(637, 'prev_page', 'الصفحة السابقة', 'main'),
(638, 'seconds_ago', 'ثانية', 'main'),
(639, 'redirection_msg', 'جاري التحويل , اذا كان متصفحك لا يدعم التحويل التلقائي', 'main'),
(643, 'download_for_all', 'للجميع', 'cp'),
(644, 'count', 'عدد', 'main'),
(646, 'prev_votes', 'استفتائات سابقة', 'main'),
(647, 'no_options', 'لا توجد خيارات', 'main'),
(649, 'not_available', 'غير متوفر', 'main'),
(650, 'first_page', 'الصفحة الأولى', 'main'),
(652, 'for_no_one', 'لا احد', 'main'),
(653, 'for_any_one', 'الكل', 'main'),
(656, 'not_saved', 'غير محفوظ', 'main'),
(657, 'minutes_ago', 'دقيقة', 'main'),
(658, 'telephone', 'رقم الاتصال', 'main'),
(659, 'hours_ago', 'ساعة', 'main'),
(660, 'city', 'المدينة', 'main'),
(661, 'days_ago', 'يوم', 'main'),
(662, 'the_count', 'العدد', 'main'),
(665, 'gender', 'الجنس', 'main'),
(666, 'tabbed_to', 'القائمة الرئيسية', 'cp'),
(667, 'without_tabbed_menu', 'بدون قائمة رئيسية', 'cp'),
(668, 'prev', 'السابق', 'main'),
(669, 'offers_menu', 'قائمة العروض', 'main'),
(670, 'show_prev_votes', 'عرض الاستفتائات السابقة', 'cp'),
(671, 'max_count', 'اقصى عدد', 'cp'),
(672, 'random', 'عشوائي', 'cp'),
(673, 'cats_permissions', 'تصاريح الاقسام', 'cp'),
(674, 'cats_permissions_note', 'يمكنك ادارة تصاريح الاقسام للمشرفين بالضغط على رابط تعديل القسم و تحديد المشرفين له', 'cp'),
(676, 'for_friends_only', 'الاصدقاء فقط', 'main'),
(677, 'add_to_black_list', 'اضافة الى قائمة التجاهل', 'main'),
(678, 'other', 'غير ذلك', 'main'),
(680, 'leave_blank_to_use_default_settings', 'اتركه فارغ لاستخدام الاعدادات الافتراضية', 'cp'),
(681, 'activate', 'تفعيل', 'cp'),
(682, 'the_member', 'العضو', 'main'),
(683, 'delete_picture', 'حذف الصورة', 'main'),
(685, 'update_data', 'تحديث البيانات', 'cp'),
(688, 'text_color', 'لون النص', 'cp'),
(690, 'sending_form_code', 'كود فورم الارسال', 'cp'),
(692, 'short_description', 'الوصف القصير', 'cp'),
(693, 'fields_search_menu', 'قائمة البحث', 'cp'),
(694, 'options_edit', 'تعديل الخيارات', 'cp'),
(695, 'the_value', 'القيمة', 'cp'),
(696, 'without_main_cat', 'بدون قسم رئيسي', 'cp'),
(697, 'sent_messages', 'الرسائل الصادرة', 'main'),
(698, 'received_msgs', 'الرسائل الواردة', 'main'),
(699, 'move_the_cats', 'نقل الأقسام', 'cp'),
(700, 'please_select_cats_first', 'يرجى تحديد الاقسام أولا', 'cp'),
(701, 'add2fav_already_exists', 'هذا الملف موجود مسبقا في المفضلة', 'main'),
(702, 'err_invalid_cat_id', '<b> خطأ : </b> يرجى التأكد من رقم القسم', 'cp'),
(703, 'err_cats_not_selected', '<b> خطأ : </b> لم يتم تحديد الأقسام', 'cp'),
(704, 'move', 'نقل', 'cp'),
(705, 'profile_access_denied', 'عفوا , لا يمكنك مشاهدة هذا الملف الشخصي', 'main'),
(706, 'the_moderators', 'المشرفين', 'cp'),
(707, 'page_custom_info', 'بيانات مخصصة للصفحة', 'cp'),
(708, 'the_page_keywords', 'الكلمات المساعدة', 'cp'),
(709, 'comment_type', 'نوع التعليق', 'cp'),
(710, 'add2fav_confirm_msg', 'هل انت متأكد انك تريد اضافة "{name}" الى المفضلة', 'main'),
(711, 'photos_count', 'عدد الصور', 'cp'),
(712, 'remaining_letters', 'حروف متبقية', 'cp'),
(713, 'the_comments', 'التعليقات', 'cp'),
(714, 'add_photos', 'اضافة صور', 'cp'),
(715, 'no_photos', 'لا توجد صور', 'cp'),
(716, 'no_moderators', 'لا يوجد مشرفين', 'cp'),
(717, 'available', 'متوفر', 'cp'),
(719, 'comments_waiting_admin_review', 'تعليقات تنتظر الموافقة', 'cp'),
(720, 'write_your_comment', 'اكتب تعليقك', 'cp'),
(721, 'phrases_name_exists', 'لم تتم الاضافة , هذا الاسم مستخدم مسبقا', 'cp'),
(722, 'the_players', 'المشغلات', 'cp'),
(723, 'no_players', 'لا توجد مشغلات', 'cp'),
(724, 'extensions', 'الامتدادات', 'cp'),
(725, 'players_add', 'اضافة مشغل', 'cp'),
(726, 'ioncube_version', 'اصدار ionCube', 'cp'),
(727, 'internal_player', 'المشغل الداخلي', 'cp'),
(728, 'external_player', 'المشغل الخارجي', 'cp'),
(729, 'file_name', 'اسم الملف', 'cp'),
(730, 'the_icon_url', 'رابط الأيقونة', 'cp'),
(731, 'the_icon_alt', 'عنوان الأيقونة', 'cp'),
(732, 'use_comma_between_types', 'استخدم فاصلة (Comma) بين الأنواع', 'cp'),
(734, 'no_cats', 'لا توجد اقسام', 'main'),
(736, 'close', 'اغلاق', 'main'),
(741, 'download_url', 'رابط التحميل', 'cp'),
(742, 'watch_url', 'رابط المشاهدة', 'cp'),
(744, 'add_files', 'اضافة ملفات', 'cp'),
(747, 'members_comments', 'تعلقيات الأعضاء', 'main'),
(754, 'manage_photos', 'ادارة الصور', 'cp'),
(756, 'player_view_style', 'طريقة العرض', 'cp'),
(759, 'player_view_ext_page', 'صفحة خارجية', 'cp'),
(761, 'next_photo', 'الصورة التالية', 'cp'),
(762, 'the_photo', 'الصورة', 'cp'),
(763, 'prev_photo', 'الصورة السابقة', 'cp'),
(764, 'full_photo_size', 'الحجم الكامل', 'cp'),
(765, 'rating_exire_time', 'الوقت الفاصل بين التقييمات', 'cp'),
(768, 'delete_cover', 'حذف الصورة', 'cp'),
(969, 'show_in_members_list', 'الظهور في قائمة الاعضاء', 'main'),
(970, 'members_perpage', 'عدد الاعضاء في الصفحة', 'cp'),
(971, 'rating', 'التقييم', 'cp'),
(972, 'select_video', 'اختيار كليب', 'cp'),
(973, 'video_id', 'رقم الكليب', 'cp'),
(974, 'videos_orderby', 'ترتيب الكليبات حسب', 'cp'),
(781, 'release_year', 'سنة الأصدار', 'main'),
(782, 'err', 'خطأ', 'main'),
(783, 'edit_done', 'تم التعديل', 'cp'),
(784, 'please_select_photos', 'يرجى اختيار الصور', 'cp'),
(787, 'in_this_photo', 'في هذه الصورة', 'main'),
(788, 'more', 'المزيد', 'main'),
(790, 'no_comments', 'لا توجد تعليقات', 'main'),
(791, 'please_login', 'يرجى تسجل الدخول', 'main'),
(792, 'err_empty_comment', 'لم يتم كتابة التعليق', 'main'),
(793, 'older_comments', 'تعليقات أقدم', 'main'),
(794, 'no_files_selected', 'لم يتم اخيار الملفات', 'main'),
(795, 'the_files', 'الملفات', 'main'),
(796, 'activated', 'مفعل', 'cp'),
(797, 'not_activated', 'غير مفعل', 'cp'),
(798, 'since', 'منذ', 'cp'),
(799, 'rating_done', 'تم التقييم', 'cp'),
(800, 'report_file', 'الابلاغ عن الملف', 'cp'),
(801, 'comment_is_not_exist', 'التعليق غير موجود', 'cp'),
(802, 'report_number_x', 'بلاغ رقم', 'cp'),
(803, 'security_code_in_report', 'كود التحقق', 'main'),
(804, 'security_code_in_send', 'كود التحقق', 'main'),
(805, 'err_upload_max_size', 'يرجى التأكد من ان حجم الملف اقل من', 'main'),
(806, 'photo_not_saved', 'لم يتم حفظ الصورة', 'main'),
(807, 'new_pm_email_notify', 'ابلاغ بالبريد عند استلام رسالة خاصة جديدة', 'main'),
(808, 'pm_email_notify_subject', 'رسالة خاصة جديدة', 'main'),
(809, 'not_classified', 'غير مصنف', 'main'),
(810, 'sort_by', 'الترتيب حسب', 'main'),
(917, 'photos_perpage', 'عدد الصور في الصفحة الواحدة', 'cp'),
(916, 'prev_singer', 'المغني السابق', 'main'),
(813, 'online_status', 'التواجد', 'main'),
(814, 'online', 'متصل', 'main'),
(815, 'offline', 'غير متصل', 'main'),
(915, 'next_singer', 'المغني التالي', 'main'),
(914, 'prev_next_singer', 'المغني السابق و التالي', 'cp'),
(818, 'enable_search', 'تفعيل البحث', 'cp'),
(819, 'add_custom_field', 'اضافة خانة اضافية', 'cp'),
(820, 'report_sent', 'شكرا لك , تم ابلاغ الادارة', 'main'),
(821, 'the_explanation', 'التوضيح', 'main'),
(822, 'new_reports', 'بلاغات جديدة', 'main'),
(823, 'report_type', 'نوع البلاغ', 'main'),
(824, 'the_reports', 'البلاغات', 'cp'),
(825, 'no_reports', 'لا توجد بلاغات', 'cp'),
(826, 'reports_count', 'عدد البلاغات', 'cp'),
(913, 'overview', 'ملخص', 'main'),
(828, 'report_do', 'ارسال بلاغ', 'main'),
(829, 'member_is_not_exist', 'العضو غير موجود', 'cp'),
(912, 'listen_to_songs', 'الاستماع للأغاني', 'main'),
(831, 'comment_count', 'عدد التعليقات', 'cp'),
(832, 'deactivate', 'تعطيل', 'cp'),
(833, 'profile_picture', 'الصورة الشخصية', 'main'),
(834, 'profile_preview', 'معاينة الملف الشخصي', 'main'),
(835, 'views', 'عدد المشاهدات', 'main'),
(836, 'date_format', 'صيغة التاريخ', 'cp'),
(837, 'the_counters', 'العدادات', 'cp'),
(838, 'contactus_send_successfully', 'شكرا لك , تم ارسال الرسالة بنجاح', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES
(839, 'contactus_send_failed', 'عفوا , حدث خطأ أثناء الارسال يرجى المحاولة مرة اخرى لاحقا', 'main'),
(840, 'without_subject', 'بدون عنوان', 'main'),
(841, 'counters_reset', 'تصفير العدادات', 'cp'),
(842, 'members_connectors', 'ربط الاعضاء', 'cp'),
(844, 'cats_count', 'عدد الاقسام', 'main'),
(845, 'files_count', 'عدد الملفات', 'main'),
(846, 'comments_count', 'عدد التعليقات', 'main'),
(847, 'visitors_can_send_reports', 'امكانية الزوار من ارسال البلاغات', 'cp'),
(848, 'general_settings', 'اعدادات عامة', 'cp'),
(849, 'mailing_settings', 'اعدادات المراسلة', 'cp'),
(850, 'default_privacy_settings', 'الاعدادات الافتراضية للخصوصية', 'cp'),
(851, 'pic_width', 'عرض الصورة', 'cp'),
(852, 'pic_height', 'طول الصورة', 'cp'),
(853, 'pic_max_width', 'اقصى عرض للصورة', 'cp'),
(854, 'pic_max_height', 'اقصى طول للصورة', 'cp'),
(855, 'thumb_width', 'عرض المصغرة', 'cp'),
(856, 'thumb_height', 'طول المصغرة', 'cp'),
(857, 'the_photos', 'الصور', 'cp'),
(911, 'uncheck_all', 'الغاء التحديد', 'main'),
(910, 'check_all', 'تحديد الكل', 'main'),
(862, 'news_cat_del_warn', 'حذف هذا القسم سوف يؤدي على حذف جميع الاخبار في داخله , هل تريد المتابعة ؟', 'cp'),
(863, 'read_more', 'اقرأ المزيد', 'main'),
(864, 'please_select_news_first', 'يرجى اختيار الاخبار اولا', 'cp'),
(909, 'this_song_only', 'هذه الاغنية فقط', 'cp'),
(867, 'time_and_date', 'الوقت و التاريخ', 'cp'),
(868, 'timezone', 'المنطقة الزمنية', 'cp'),
(869, 'privacy_settings', 'اعدادات الخصوصية', 'main'),
(870, 'profile_view', 'مشاهدة الملف الشخصي', 'main'),
(908, 'video', 'كليب', 'main'),
(872, 'receive_pm_from', 'استقبال رسائل خاصة من', 'main'),
(873, 'this_member_exist_in_list', 'هذا العضو موجود في القائمة مسبقا', 'main'),
(874, 'add_done_successfully', 'تمت الاضافة بنجاح', 'main'),
(875, 'friends_list', 'قائمة الاصدقاء', 'main'),
(876, 'no_friends_in_list', 'لا يوجد اصدقاء في القائمة', 'main'),
(877, 'black_list', 'قائمة التجاهل', 'main'),
(878, 'no_members_in_list', 'لا يوجد اعضاء في القائمة', 'main'),
(881, 'max_letters', 'اقصى عدد احرف', 'cp'),
(907, 'playlist', 'قائمة التشغيل', 'cp'),
(906, 'visits', 'عدد الزيارات', 'main'),
(886, 'news_comments', 'تعليقات على الاخبار', 'cp'),
(887, 'comments_auto_activate', 'تفعيل تلقائي للتعليقات', 'cp'),
(888, 'show_online_members_count', 'اظهار عدد الاعضاء المتواجدون', 'cp'),
(905, 'the_ext', 'الملحق', 'cp'),
(890, 'commets_per_request', 'التعليقات لكل طلب', 'cp'),
(891, 'err_no_singers', 'لا يوجد مغنيين', 'main'),
(892, 'add_album', 'اضافة ألبوم', 'cp'),
(893, 'no_albums', 'لا يوجد ألبومات', 'cp'),
(894, 'file_is_not_available', 'الملف غير متوفر', 'main'),
(895, 'page_file_name', 'اسم ملف الصفحة', 'cp'),
(896, 'photos_add', 'اضافة صور', 'cp'),
(897, 'singer_photos', 'صور المغني', 'main'),
(899, 'singer_videos', 'كليبات المغني', 'main'),
(900, 'songs_comments', 'تعليقات الأغاني', 'cp'),
(901, 'singer_info', 'بيانات المغني', 'cp'),
(902, 'the_singer', 'المغني', 'cp'),
(903, 'add_videos', 'اضافة كليبات', 'cp'),
(904, 'new_songs_menu_note', 'يمكنك ايضا الاضافة الى هذه القائمة من خلال الدخول الى صفحة المغني و تحديد الاغاني ثم اختيار اضافة الى قائمة الجديد من الخيارات في الاسفل', 'cp'),
(918, 'bio', 'السيرة الذاتية', 'main'),
(919, 'username_max_letters', 'اقصى عدد احرف لاسم المستخدم', 'cp'),
(920, 'err_username_max_letters', 'عدد حروف اسم المستخدم اكثر من المسموح به', 'main'),
(921, 'albums_orderby', 'ترتيب الألبومات حسب', 'cp'),
(922, 'downloads', 'مرات التحميل', 'cp'),
(923, 'listens', 'مرات الاستماع', 'cp'),
(924, 'prev_next_song', 'الاغنية السابقة و التالية', 'cp'),
(925, 'prev_next_cat', 'القسم السابق و التالي', 'cp'),
(926, 'prev_next_album', 'الألبوم السابق و التالي', 'cp'),
(927, 'prev_next_video', 'الكليب السابق و التالي', 'cp'),
(928, 'prev_next_video_cat', 'قسم الكليبات السابق و التالي', 'cp'),
(929, 'prev_song', 'الاغنية السابقة', 'main'),
(930, 'next_song', 'الاغنية التالية', 'main'),
(931, 'next_video', 'الكليب التالي', 'main'),
(932, 'prev_video', 'الكليب السابق', 'main'),
(933, 'prev_cat', 'القسم السابق', 'main'),
(934, 'next_cat', 'القسم التالي', 'main'),
(935, 'prev_album', 'الألبوم السابق', 'main'),
(936, 'next_album', 'الألبوم التالي', 'main'),
(937, 'all_songs', 'جميع الاغاني', 'main'),
(938, 'for_all_visitors', 'لجميع الزوار', 'cp'),
(939, 'listen_permission', 'تصريح الاستماع', 'cp'),
(940, 'download_permission', 'تصريح التحميل', 'cp'),
(941, 'listen_type', 'نوع الاستماع', 'cp'),
(942, 'in_site_page', 'صفحة داخل الموقع', 'cp'),
(943, 'ext_listen', 'الاستماع الخارجي', 'cp'),
(944, 'path_sep', '->', 'main'),
(945, 'singers_fields', 'خانات المغنيين الاضافية', 'cp'),
(946, 'albums_fields', 'خانات الالبومات الاضافية', 'cp'),
(947, 'favorite_videos', 'الكليبات المفضلة', 'main'),
(948, 'custom_ext', 'ملحق مخصص', 'cp'),
(949, 'auto', 'تلقائي', 'cp'),
(950, 'day', 'يوم', 'cp'),
(951, 'ext_auto_note', 'يمكنك من هذا الخيار تحديد المدة المطلوبة لظهور الملحق تلقائيا على الاغاني بين فترة محدد من تاريخ الاضافة , يمكنك وضع الرقم 0 في القيم لتعطيل النظام التلقائي', 'cp'),
(952, 'singers_perpage', 'عدد المغنيين في الصفحة', 'cp'),
(953, 'albums_perpage', 'عدد الألبومات في الصفحة', 'cp'),
(954, 'cp_show_singer_img', 'اظهار صور المغنيين في لوحة التحكم', 'cp'),
(955, 'videos_cats_permissions_note', 'يمكنك ادارة تصاريح الاقسام للمشرفين بالضغط على رابط تعديل القسم و تحديد المشرفين له', 'cp'),
(956, 'please_select_videos', 'يرجى اختيار الكليبات', 'cp'),
(957, 'tools', 'ادوات', 'cp'),
(958, 'update_counters', 'تحديث العدادات', 'cp'),
(959, 'delete_w_songs', 'حذف مع الأغاني', 'cp'),
(960, 'del_with_songs_warn', 'هذا الخيار سوف يقوم بحذف الألبوم مع الأغاني التي يحتويها , هل تريد المتابعة ؟', 'cp'),
(961, 'please_select_albums', 'يرجى اختيار الالبومات', 'cp'),
(962, 'album_move', 'نقل ألبوم', 'cp'),
(963, 'expire_date', 'تاريخ الانتهاء', 'cp'),
(964, 'without_expire', 'بدون انتهاء', 'cp'),
(965, 'start_date', 'تاريخ البدء', 'cp'),
(966, 'singer_overview_page', 'صفحة ملخص المغني', 'cp'),
(967, 'the_age', 'العمر', 'main'),
(968, 'year', 'سنة', 'main');

-- --------------------------------------------------------

--
-- Table structure for table `songs_phrases_cats`
--

CREATE TABLE IF NOT EXISTS `songs_phrases_cats` (
  `id` text NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY  (`id`(20))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `songs_phrases_cats`
--

INSERT INTO `songs_phrases_cats` (`id`, `name`) VALUES
('main', 'العبارات العامة'),
('cp', 'لوحة التحكم / النظام');

-- --------------------------------------------------------

--
-- Table structure for table `songs_players`
--

CREATE TABLE IF NOT EXISTS `songs_players` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `int_content` text NOT NULL,
  `playlist_content` text NOT NULL,
  `video_content` text NOT NULL,
  `exts` varchar(255) NOT NULL default '',
  `ext_content` text NOT NULL,
  `ext_mime` varchar(100) NOT NULL default '',
  `ext_filename` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `exts` (`exts`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `songs_players`
--

INSERT INTO `songs_players` (`id`, `name`, `int_content`, `playlist_content`, `video_content`, `exts`, `ext_content`, `ext_mime`, `ext_filename`) VALUES
(1, 'المشغل الافتراضي', '<center>\r\n<OBJECT id=''rvocx'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n          width="500" height=''30''>\r\n          <param name=''src'' value="{url}">\r\n          <param name=''autostart'' value="true">\r\n          <param name=''controls'' value=''ControlPanel''>\r\n          <param name=''console'' value=''video''>\r\n          <EMBED src="{url}" width="500" height=''30''  controls=''ControlPanel'' type=''audio/x-pn-realaudio-plugin'' console=''video'' autostart="true">\r\n          </EMBED>\r\n          </OBJECT></center>\r\n', '<center>\r\n <embed src="{url}" width="500" height=''60''  controls=''ControlPanel,StatusBar'' type=''audio/x-pn-realaudio-plugin'' console=''one'' autostart="true" id=''RVOCX'' name=''RVOCX''></embed></center>\r\n\r\n<script>\r\nif(!tm){\r\n  var tm =  new PeriodicalExecuter(function(pe) {\r\nif($(''RVOCX'')){\r\n    var argx = $(''RVOCX'').GetLength();\r\n    var argy =  $(''RVOCX'').GetPosition();\r\n \r\n    \r\n    if(argy > 0){\r\n    if( argy >=  argx-1000){\r\n       play_song({next_index});  \r\n    }\r\n    \r\n    \r\n    }\r\n    \r\n}\r\n}, 1);\r\n}\r\n</script>', '<table border=''0'' cellpadding=''0'' align="center">\r\n        <tr><td>\r\n        <OBJECT id=''RVOCX'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n        width="500" height="300">\r\n        <param name=''src'' value="{url}">\r\n        <param name=''autostart'' value="true">\r\n        <param name=''controls'' value=''imagewindow''>\r\n        <param name=''console'' value=''video''>\r\n        <param name=''loop'' value="true">\r\n        <EMBED src="{url}" width="500" height="300" \r\n        loop="true" type=''audio/x-pn-realaudio-plugin'' controls=''imagewindow'' console=''video'' autostart="true">\r\n        </EMBED>\r\n        </OBJECT>\r\n        </td></tr>\r\n          <tr><td>\r\n          <OBJECT id=''RVOCX'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n          width="500" height=''30''>\r\n          <param name=''src'' value="{url}">\r\n          <param name=''autostart'' value="true">\r\n          <param name=''controls'' value=''ControlPanel''>\r\n          <param name=''console'' value=''video''>\r\n          <EMBED src="{url}" width="500" height=''30'' \r\n          controls=''ControlPanel'' type=''audio/x-pn-realaudio-plugin'' console=''video'' autostart="true">\r\n          </EMBED>\r\n          </OBJECT>\r\n          </td></tr>\r\n      </table>', '', '<?\r\nglobal $num_ramadv,$scripturl;\r\n\r\n\r\nif($num_ramadv){\r\n$adv_ram_link = "?rpcontextwidth=600&rpcontextheight=300&rpcontexturl=".$scripturl."/ram_banners.php";\r\n}else{\r\n$adv_ram_link = "";\r\n}\r\n\r\nprint "{url}".$adv_ram_link;\r\n\r\n?>', 'audio/x-pn-realaudio', 'listen.ram'),
(2, 'JW Flash Player', '<center>\r\n<div id=''player_div''></div>\r\n</center>\r\n\r\n<script>\r\n jwplayer("player_div").setup({\r\n    file: "{url}",\r\n    flashplayer: scripturl+"/players/player.swf",\r\n  ''controlbar'': ''bottom'',\r\n    height: 24,\r\n    width: 500,\r\n    autostart: true\r\n   \r\n  });\r\n</script>', '<script>\r\n jwplayer("player_div").setup({\r\n    file: "{url}",\r\n    flashplayer: scripturl+"/players/player.swf",\r\n  ''controlbar'': ''bottom'',\r\n    height: 24,\r\n    width: 500,\r\n    autostart: true\r\n   \r\n  });\r\n\r\n jwplayer("player_div").onComplete(function() {     \r\n play_song({next_index}); \r\n });\r\n</script>', '<center>\r\n<div id=''player_div''></div>\r\n</center>\r\n\r\n<script>\r\n jwplayer("player_div").setup({\r\n    file: "{url}",\r\n    flashplayer: scripturl+"/players/player.swf",\r\n    height: 300,\r\n    width: 500,\r\n    autostart: true\r\n   \r\n  });\r\n</script>', '.mp3,.flv,youtube.com,.mp4', '<?\r\nglobal $num_ramadv,$scripturl;\r\n\r\n\r\nif($num_ramadv){\r\n$adv_ram_link = "?rpcontextwidth=600&rpcontextheight=300&rpcontexturl=".$scripturl."/ram_banners.php";\r\n}else{\r\n$adv_ram_link = "";\r\n}\r\n\r\nprint "{url}".$adv_ram_link;\r\n\r\n?>', 'audio/x-pn-realaudio', 'listen.ram'),
(3, 'Windows Media Player', '    <table border=''0'' cellpadding=''0'' align="center">\r\n      <tr><td>\r\n      <OBJECT id=''mediaPlayer'' width="400" height="305"\r\n      classid=''CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95''\r\n      codebase=''http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701''\r\n      standby=''Loading Microsoft Windows Media Player components...'' type=''application/x-oleobject''>\r\n      <param name=''fileName'' value="{url}">\r\n      <param name=''animationatStart'' value=''true''>\r\n      <param name=''transparentatStart'' value=''true''>\r\n      <param name=''autoStart'' value="true">\r\n      <param name=''showControls'' value="true">\r\n      <param name=''loop'' value="false">\r\n      <EMBED type=''application/x-mplayer2''\r\n        pluginspage=''http://microsoft.com/windows/mediaplayer/en/download/''\r\n        id=''mediaPlayer'' name=''mediaPlayer'' displaysize=''4'' autosize=''-1''\r\n        bgcolor=''darkblue'' showcontrols="true" showtracker=''-1''\r\n        showdisplay=''0'' showstatusbar=''-1'' videoborder3d=''-1'' width="400" height="305"\r\n        src="{url}" autostart="true" designtimesp=''5311'' loop="false">\r\n      </EMBED>\r\n      </OBJECT>\r\n      </td></tr>\r\n      <!-- ...end embedded WindowsMedia file -->\r\n    <!-- begin link to launch external media player... -->\r\n      \r\n      </table>', '', '', '.wmv', '', '', ''),
(4, 'Divx Player', '<center>\r\n<object classid="clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616" width="600" height="358" codebase="http://go.divx.com/plugin/DivXBrowserPlugin.cab">\r\n  <param name="custommode" value="none" />\r\n  <param name="autoPlay" value="true" />\r\n  <param name="src" value="{url}" />\r\n  <embed type="video/divx"\r\n         src="{url}"\r\n         custommode="none"\r\n         width="600" height="358"\r\n         autoPlay="false"\r\n         pluginspage="http://go.divx.com/plugin/download/">\r\n  </embed>\r\n</object>\r\n', '', '', '.avi,.mkv', '', '', ''),
(6, 'Real Player', '<center>\r\n <embed src="{url}" width="500" height=''60''  controls=''ControlPanel,StatusBar'' type=''audio/x-pn-realaudio-plugin'' console=''one'' autostart="true" id=''RVOCX'' name=''RVOCX''></embed></center>', '<center>\r\n <embed src="{url}" width="500" height=''60''  controls=''ControlPanel,StatusBar'' type=''audio/x-pn-realaudio-plugin'' console=''one'' autostart="true" id=''RVOCX'' name=''RVOCX''></embed></center>\r\n\r\n<script>\r\nif(!tm){\r\n  var tm =  new PeriodicalExecuter(function(pe) {\r\nif($(''RVOCX'')){\r\n    var argx = $(''RVOCX'').GetLength();\r\n    var argy =  $(''RVOCX'').GetPosition();\r\n \r\n    \r\n    if(argy > 0){\r\n    if( argy >=  argx-1000){\r\n       play_song({next_index});  \r\n    }\r\n    \r\n    \r\n    }\r\n    \r\n}\r\n}, 1);\r\n}\r\n</script>', '<table border=''0'' cellpadding=''0'' align="center">\r\n        <tr><td>\r\n        <OBJECT id=''RVOCX'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n        width="500" height="300">\r\n        <param name=''src'' value="{url}">\r\n        <param name=''autostart'' value="true">\r\n        <param name=''controls'' value=''imagewindow''>\r\n        <param name=''console'' value=''video''>\r\n        <param name=''loop'' value="true">\r\n        <EMBED src="{url}" width="500" height="300" \r\n        loop="true" type=''audio/x-pn-realaudio-plugin'' controls=''imagewindow'' console=''video'' autostart="true">\r\n        </EMBED>\r\n        </OBJECT>\r\n        </td></tr>\r\n          <tr><td>\r\n          <OBJECT id=''RVOCX'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n          width="500" height=''30''>\r\n          <param name=''src'' value="{url}">\r\n          <param name=''autostart'' value="true">\r\n          <param name=''controls'' value=''ControlPanel''>\r\n          <param name=''console'' value=''video''>\r\n          <EMBED src="{url}" width="500" height=''30'' \r\n          controls=''ControlPanel'' type=''audio/x-pn-realaudio-plugin'' console=''video'' autostart="true">\r\n          </EMBED>\r\n          </OBJECT>\r\n          </td></tr>\r\n      </table>', '.rm,.rmvb,.rv', '<?\r\nglobal $num_ramadv,$scripturl;\r\n\r\n\r\nif($num_ramadv){\r\n$adv_ram_link = "?rpcontextwidth=600&rpcontextheight=300&rpcontexturl=".$scripturl."/ram_banners.php";\r\n}else{\r\n$adv_ram_link = "";\r\n}\r\n\r\nprint "{url}".$adv_ram_link;\r\n\r\n?>', 'audio/x-pn-realaudio', 'listen.ram');

-- --------------------------------------------------------

--
-- Table structure for table `songs_playlists`
--

CREATE TABLE IF NOT EXISTS `songs_playlists` (
  `id` int(11) NOT NULL auto_increment,
  `member_id` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_playlists_data`
--

CREATE TABLE IF NOT EXISTS `songs_playlists_data` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `song_id` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `member_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `member_ord_cat` (`cat`,`member_id`,`ord`),
  KEY `member_id` (`member_id`,`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_reports`
--

CREATE TABLE IF NOT EXISTS `songs_reports` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `report_type` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date` int(11) NOT NULL,
  `opened` int(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `report_type` (`report_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_settings`
--

CREATE TABLE IF NOT EXISTS `songs_settings` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `songs_settings`
--

INSERT INTO `songs_settings` (`name`, `value`) VALUES
('snd2friend', '1'),
('vote_song', '1'),
('sitename', 'اللوماني'),
('section_name', 'الصوتيات و المرئيات v3.0'),
('songs_add_fields', '5'),
('letters_songs', '1'),
('letters_singers', '1'),
('html_dir', 'rtl'),
('header_keywords', 'أغاني , مغنيين , كليبات '),
('uploader', '1'),
('uploader_path', 'uploads'),
('uploader_msg', 'نأسف لك , رفع الملفات غير مفعل في النسخة التجريبية'),
('uploader_types', 'jpg,gif,png,rm,mp3'),
('songs_add_limit', '10'),
('singers_groups', '1'),
('songs_perpage', '100'),
('songs_cells', '4'),
('vote_clip', '1'),
('snd2friend_clip', '1'),
('votes_expire_hours', '24'),
('copyrights_sitename', 'اللوماني'),
('search_min_letters', '3'),
('msgs_count_limit', '30'),
('mailing_email', 'mailing@{domain_name}'),
('member_download_only', '2'),
('members_register', '1'),
('news_perpage', '10'),
('vote_file_expire_hours', '24'),
('site_pages_lang', 'ar-sa'),
('site_pages_encoding', 'utf-8'),
('enable_browsing', '1'),
('disable_browsing_msg', '<center> عفوا , الموقع مغلق حاليا</center>'),
('register_sec_code', '1'),
('auto_email_activate', '0'),
('register_username_exclude_list', 'admin,mod,webmaster'),
('register_username_min_letters', '4'),
('mailing_default_use_html', '1'),
('mailing_default_encoding', ''),
('count_visitors_info', '1'),
('count_visitors_hits', '1'),
('count_online_visitors', '1'),
('enable_search', '1'),
('default_styleid', '1'),
('uploader_thumb_width', '100'),
('uploader_thumb_hieght', '100'),
('sitename_in_subpages', '0'),
('section_name_in_subpages', '0'),
('videos_perpage', '28'),
('visitors_can_sort_songs', '1'),
('songs_default_orderby', 'name'),
('songs_default_sort', 'asc'),
('videos_member_download_only', '2'),
('songs_multi_select', '1'),
('timezone', 'Asia/Baghdad'),
('date_format', 'd M Y'),
('comments_max_letters', '250'),
('commets_per_request', '10'),
('enable_news_comments', '1'),
('comments_auto_activate', '1'),
('photo_resized_width', '750'),
('photo_resized_height', '750'),
('photo_thumb_width', '100'),
('photo_thumb_height', '100'),
('enable_songs_comments', '1'),
('enable_singer_photo_comments', '1'),
('reports_enabled', '1'),
('online_members_count', '1'),
('send_sec_code', '1'),
('rating_expire_hours', '24'),
('other_votes_limit', '10'),
('other_votes_show', '1'),
('other_votes_orderby', 'id asc'),
('overview_photos_limit', '4'),
('overview_videos_limit', '4'),
('enable_singer_comments', '1'),
('enable_video_comments', '1'),
('enable_album_comments', '1'),
('prev_next_singer', '1'),
('photos_perpage', '28'),
('report_sec_code', '1'),
('reports_for_visitors', '1'),
('username_max_letters', '20'),
('albums_orderby', 'year'),
('albums_sort', 'desc'),
('default_url_id', '1'),
('prev_next_song', '1'),
('prev_next_cat', '1'),
('prev_next_album', '1'),
('prev_next_video', '1'),
('prev_next_video_cat', '1'),
('header_description', 'وصف'),
('admin_email', 'noreply@allomani.com'),
('albums_perpage', '28'),
('singers_perpage', '300'),
('cp_singer_img', '1'),
('default_privacy_settings', 'a:8:{s:7:"profile";i:0;s:6:"gender";i:0;s:5:"birth";i:0;s:7:"country";i:0;s:10:"last_login";i:0;s:6:"online";i:0;s:10:"fav_videos";i:0;s:8:"messages";i:0;}'),
('members_profile_pictures', '1'),
('profile_pic_width', '100'),
('profile_pic_height', '100'),
('profile_pic_thumb_width', '30'),
('profile_pic_thumb_height', '30'),
('members_perpage', '20'),
('videos_orderby', 'id'),
('videos_sort', 'desc');

-- --------------------------------------------------------

--
-- Table structure for table `songs_singers`
--

CREATE TABLE IF NOT EXISTS `songs_singers` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `img` text NOT NULL,
  `content` text NOT NULL,
  `details` text NOT NULL,
  `last_update` int(10) NOT NULL default '0',
  `active` int(1) NOT NULL default '0',
  `page_name` varchar(100) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_description` varchar(255) NOT NULL,
  `page_keywords` varchar(255) NOT NULL,
  `votes` int(11) NOT NULL,
  `votes_total` int(11) NOT NULL,
  `rate` float NOT NULL,
  `views` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `songs_count` int(11) NOT NULL,
  `albums_count` int(11) NOT NULL,
  `photos_count` int(11) NOT NULL,
  `videos_count` int(11) NOT NULL,
  `field_1` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`),
  KEY `last_update` (`last_update`),
  KEY `cat` (`cat`),
  KEY `active` (`active`),
  KEY `rate` (`rate`),
  KEY `cat_active` (`cat`,`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_singers_fields`
--

CREATE TABLE IF NOT EXISTS `songs_singers_fields` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `style` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `enable_search` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `songs_singers_fields`
--

INSERT INTO `songs_singers_fields` (`id`, `name`, `details`, `type`, `value`, `style`, `ord`, `enable_search`, `active`) VALUES
(1, 'تاريخ الميلاد', '', 'text', '', '', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `songs_singers_photos`
--

CREATE TABLE IF NOT EXISTS `songs_singers_photos` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `cat` int(11) NOT NULL default '0',
  `img` text NOT NULL,
  `img_resized` text NOT NULL,
  `thumb` text NOT NULL,
  `date` int(10) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  `rate` float NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `ord` (`ord`),
  KEY `rate` (`rate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_singers_photos_tags`
--

CREATE TABLE IF NOT EXISTS `songs_singers_photos_tags` (
  `id` int(11) NOT NULL auto_increment,
  `photo_id` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `singer_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `singer_id` (`singer_id`),
  KEY `photo_id` (`photo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_songs`
--

CREATE TABLE IF NOT EXISTS `songs_songs` (
  `id` int(11) NOT NULL auto_increment,
  `album` int(11) NOT NULL default '0',
  `album_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `lyrics` text NOT NULL,
  `date` int(11) NOT NULL default '0',
  `ext` int(11) NOT NULL default '0',
  `c_ext` varchar(50) NOT NULL,
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  `rate` float NOT NULL,
  `video_id` int(11) NOT NULL,
  `url_1` text NOT NULL,
  `downloads_1` int(11) NOT NULL,
  `listens_1` int(11) NOT NULL,
  `field_1` varchar(255) NOT NULL,
  `field_2` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`),
  KEY `album` (`album`),
  KEY `album_id` (`album_id`),
  KEY `video_id` (`video_id`),
  KEY `rate` (`rate`),
  KEY `downloads_1` (`downloads_1`),
  KEY `listens_1` (`listens_1`),
  KEY `ext_and_date` (`ext`,`date`),
  KEY `c_ext` (`c_ext`),
  KEY `date` (`date`),
  KEY `ext` (`ext`),
  KEY `field_1` (`field_1`),
  KEY `field_2` (`field_2`),
  KEY `singer_and_album` (`album`,`album_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_songs_fields`
--

CREATE TABLE IF NOT EXISTS `songs_songs_fields` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `style` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `enable_search` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `songs_songs_fields`
--

INSERT INTO `songs_songs_fields` (`id`, `name`, `details`, `type`, `value`, `style`, `ord`, `enable_search`, `active`) VALUES
(1, 'الشاعر', '', 'text', '', '', 0, 1, 1),
(2, 'الملحن', '', 'text', '', '', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `songs_templates`
--

CREATE TABLE IF NOT EXISTS `songs_templates` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `name` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  `protected` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=137 ;

--
-- Dumping data for table `songs_templates`
--

INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`, `views`) VALUES
(1, 'الهيدر', 'header', '<BODY onunload="pop_close()">\r\n\r\n\r\n<div id=''header'' class=''header''><img src="images/logo.jpg"></div><br><br>\r\n\r\n<div id=''page_content'' style="dir:rtl;">', 1, 1, 2),
(2, 'الفوتر', 'footer', '<br>\r\n\r\n</div>\r\n\r\n<center><div id=''footer'' class=''footer''>\r\n\r\n<div align=right>&nbsp;&nbsp;&nbsp;\r\n<?global $styleid;print_style_selection();?>\r\n</div><br>\r\n\r\n\r\n</div></center>\r\n\r\n</body>\r\n</html>        \r\n        \r\n        ', 1, 1, 0),
(3, 'القوائم', 'block', '<div class=''block_div''><center>{title}{new_line}</center>{content}</div>', 1, 1, 0),
(4, 'الجداول', 'table', '<div class=''block_div''>{title}{new_line}<div class=''block_div''>{content}</div></div><br>', 1, 1, 0),
(102, '', 'blocks_banners', '<?\r\nglobal $data;\r\nopen_block();\r\n\r\nprint "<center><a href=''banner.php?id=$data[id]'' target=_blank><img src=''$data[img]'' border=0 title=''$data[title]''></a></center>";\r\n\r\nclose_block();\r\n?>', 1, 1, 0),
(103, '', 'center_banners', '<?\r\nglobal $data;\r\nprint "<center><a href=''banner.php?id=$data[id]'' target=_blank><img src=''$data[img]'' border=0 title=''$data[title]''></a><br></center>";\r\n?>', 1, 1, 0),
(5, 'الاتصال بنا', 'contactus', '<?\r\nglobal $sec_img,$phrases,$email_name,$email_email,$email_subject,$email_msg;\r\n\r\n open_table("$phrases[contact_us]");  \r\n    print "<center>\r\n              <form action=''contactus.php'' method=post>\r\n\r\n           \r\n              <input type=hidden name=''action'' value=''send''>\r\n              <table width=60%>\r\n\r\n              <tr>\r\n              <td width=23%> $phrases[the_name] </td>\r\n              <td>\r\n              <input name=''email_name'' type=''text'' size=30 value=\\"$email_name\\">\r\n              </td>\r\n              </tr>\r\n\r\n                <tr>\r\n              <td>$phrases[email] </td>\r\n              <td>\r\n              <input name=''email_email'' type=''text'' size=30 value=\\"$email_email\\">\r\n              </td>\r\n              </tr>\r\n\r\n                  <tr>\r\n              <td> $phrases[the_subject] </td>\r\n              <td>\r\n              <input name=''email_subject'' type=''text'' size=30 value=\\"$email_subject\\">\r\n              </td>\r\n              </tr>\r\n            <tr>\r\n              <td> $phrases[the_message] </td>\r\n              <td>\r\n             <textarea name=''email_msg'' rows=5 cols=40>$email_msg</textarea>\r\n              </td>\r\n              </tr>\r\n             <tr>\r\n             <td>$phrases[security_code]</td><td>".$sec_img->output_input_box(''sec_string'',''size=7'')."\r\n           &nbsp;<img src=\\"sec_image.php\\" alt=\\"Verification Image\\" /></td></tr>\r\n           \r\n              <tr><td colspan=2 align=center>\r\n             <input type=\\"submit\\" style=\\"width: 100 ; height: 30\\" value=\\"$phrases[send]\\">\r\n             </td> </tr>\r\n             </form>\r\n             </table>\r\n            </center> ";\r\n  close_table();  \r\n?>', 1, 1, 0),
(6, 'رسالة ارسال اغنية لصديق', 'friend_msg', '<html dir="rtl">\r\n<body>\r\n\r\n<div align=right>\r\n\r\n<p dir=rtl>قام صديقك بإرسال هذه الأغنية لك </p>\r\n\r\nاسم صديقك : {name_from}<br>\r\nبريد صديقك : {email_from}<br><br>\r\n\r\nاسم الأغنية : {name} <br><br>\r\n\r\nللاستماع : <br> <a href="{url}" target=_blank>{url}</a>\r\n\r\n\r\n</div>\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n\r\n</body>\r\n</html>\r\n\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ', 1, 1, 0),
(7, 'رسالة الارسال لصديق - كليبات', 'friend_msg_clip', '<html dir="rtl">\r\n<body>\r\n\r\n<div align=right>\r\n\r\n\r\n<p>قام صديقك بإرسال هذا الفيديو لك</p>\r\n\r\nاسم صديقك : {name_from}<br>\r\nبريد صديقك : {email_from}<br><br>\r\n\r\n<center><table width=100%><td valign=top width=2><img src=''{img}''></td><td>\r\n<p align=center><b>{name}</b></p>\r\n\r\nمشاهدة : <br> <a href="{url}" target=_blank>{url}</a>\r\n\r\n\r\n</td></tr></table></center>\r\n\r\n</div>\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n\r\n</body>\r\n</html>\r\n\r\n        \r\n        \r\n        \r\n        ', 1, 1, 0),
(47, 'رسالة تفعيل البريد الالكتروني', 'email_activation_msg', '<html dir=rtl>\r\n<body>\r\n\r\nمرحبا {name}, <br><br>\r\n\r\n\r\nلتفعيل بريدك الالكتروني يرجى الضغط على الرابط التالي : <br>\r\n\r\n{url} \r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>\r\n', 1, 1, 0),
(109, '', 'browse_news_sep', '', 1, 1, 0),
(110, '', 'browse_news_footer', '<?\r\nclose_table();\r\n?>', 1, 1, 0),
(123, 'صفحة مشاهدة الفيديو', 'video_watch', '<?\r\nglobal $data,$settings,$phrases,$scripturl,$links,$style,$global_align_x,$data_song;\r\n\r\n$url = $data[''url''];  \r\n\r\nopen_table("$data[name]");\r\n\r\n\r\nrun_player($url,''video_content'');   \r\n\r\n\r\n print "<center><br><br><table><tr>\r\n<td align=center><a href=\\"".$scripturl."/".str_replace(array(''{id}''),array($data[''id'']),$links[''video_download''])."\\"><img src=\\"$style[images]/save_mid.gif\\" alt=\\"$phrases[download]\\"></a></td>\r\n\r\n<td align=center>\r\n<a href=''http://www.facebook.com/sharer.php?u=".urlencode($scripturl."/".str_replace(array(''{id}''),array($data[''id'']),$links[''video_watch'']))."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook_mid.gif'' alt=''Share it on Facebook'' border=0></a>\r\n</td>";\r\n\r\n//----- send -----//\r\nif($settings[''snd2friend_clip'']){\r\nprint "<td align=center><a href=\\"javascript:send($data[id],''video'');\\"><img src=''images/send_mid.gif'' border=0 title=''$phrases[send2friend]''></a></td>";\r\n}\r\n\r\n//------ fav -------\r\nif(check_member_login() && !$is_user_cp){\r\nprint "<td align=center><a href=\\"javascript:add_to_fav($data[id],''video'');\\"><img src=''images/fav_add_mid.gif'' title=''$phrases[add2favorite]'' border=0></a></td>";\r\n}\r\n\r\n//----------- report -------\r\nif($settings[''reports_enabled'']){\r\nprint "<td align=center>\r\n<a href=\\"javascript:;\\" onClick=\\"report($data[id],''video'');\\"><img src=\\"$style[images]/report.gif\\" title=\\"$phrases[report_do]\\" border=0></a></td>";  \r\n}\r\n//----------------------------\r\n\r\n\r\nprint "\r\n</table>\r\n</center>";\r\n \r\n//------- rating -----------\r\nprint "<br><br><center>";\r\nprint_rating(''video'',$data[''id''],$data[''rate'']);    \r\nprint "</center>";\r\n//-----------------------------\r\n\r\n \r\n   print "<br>\r\n        <img src=''$style[images]/add_date.gif''> &nbsp; <b>$phrases[add_date] : </b>".get_date($data[''date''])."<br>";\r\n        print "<img src=''$style[images]/views.gif''> &nbsp; <b>$phrases[views] : </b>$data[views]"; \r\n\r\nif($data_song[''id'']){\r\n print "<br><img src=''$style[images]/song.gif''> &nbsp; <b>$phrases[song] : </b> <a href=\\"".str_replace(array(''{cat}'',''{id}''),array($settings[''default_url_id''],$data_song[''id'']),$links[''song_listen''])."\\">$data_song[name]</a>"; \r\n}\r\n\r\nprint " <br>";\r\n\r\n ?>\r\n <br>\r\n        \r\n        <table width=100%>        \r\n       <TBODY>\r\n<TR>\r\n<TD class=box2 width="100%">\r\n<TABLE dir=rtl border=0 cellSpacing=0 cellPadding=2 width="100%">\r\n<TBODY>\r\n<TR>\r\n<TD class=000 width="100%"><STRONG><FONT color=#cc6600>هل انت مشترك في اي منتدى؟</FONT></STRONG> <BR>يمكنك اضافة رابط هذا الكليب الى موضوعك بالمنتدى الان! <BR>اكتب موضوعاً و انسخ الرابط التالي اليه! </TD></TR>\r\n<FORM id=embedFormvb name=embedFormvb action="">\r\n<TR>\r\n<TD width="100%"><textarea dir=ltr id=embed_code onclick=javascript:document.embedFormvb.embed_code.focus();document.embedFormvb.embed_code.select(); cols=55 name=embed_code style="BORDER-BOTTOM: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; FONT-FAMILY: Tahoma; FONT-SIZE: 8pt; BORDER-TOP: #c0c0c0 1px solid; BORDER-RIGHT: #c0c0c0 1px solid">\r\n<?\r\nprint "[URL=".$scripturl."/".str_replace("{id}",$data[''id''],$links[''video_watch''])."]{$data[''name'']}[/URL]\r\n</textarea> </TD></TR></FORM></TBODY></TABLE></TD></TR>";\r\n?>\r\n<TR>\r\n<TD class=box2 width="100%">\r\n<TABLE dir=rtl border=0 cellSpacing=0 cellPadding=2 width="100%">\r\n<TBODY>\r\n<TR>\r\n<TD class=000 width="100%"><STRONG><FONT color=#cc6600>هل لديك موقع أو مدونة؟</FONT></STRONG> <BR>يمكنك اضافة رابط هذا الكليب الى موقعك او مدونتك ! <BR>انسخ الكود التالي و ضعه في موقعك الآن! </TD></TR>\r\n<FORM id=embedFormmsn name=embedFormmsn action="">\r\n<TR>\r\n<TD width="100%"><textarea dir=ltr id=embed_code onclick=javascript:document.embedFormmsn.embed_code.focus();document.embedFormmsn.embed_code.select(); cols=55 name=embed_code style="BORDER-BOTTOM: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; FONT-FAMILY: Tahoma; FONT-SIZE: 8pt; BORDER-TOP: #c0c0c0 1px solid; BORDER-RIGHT: #c0c0c0 1px solid">\r\n<?\r\n\r\nprint $scripturl."/".str_replace(''{id}'',$data[''id''],$links[''video_watch'']);\r\n?>\r\n</textarea> </TD></TR></FORM></TBODY></TABLE></TD></TR></TBODY>\r\n</table>\r\n<?\r\n\r\n\r\n\r\nclose_table();\r\n\r\n\r\n     //------ Comments -------------------\r\nif($settings[''enable_video_comments'']){\r\n    open_table($phrases[''members_comments'']);\r\n    get_comments_box(''video'',$data[''id'']);\r\n    close_table();\r\n}\r\n\r\n?>', 1, 1, 3),
(111, 'جدول بيانات المغني', 'singer_info_table', '<?\r\nglobal $id,$data,$data_singer,$data_album,$phrases,$settings,$links,$global_align,$style,$global_align_x;\r\n\r\n$singer_fields = get_singers_fields_sets();\r\n\r\n\r\nopen_table();\r\nprint "<table width=100%><tr><td>";\r\n\r\n//------- Singer ----------//\r\n//if(!$data_album[''name'']){\r\nprint "<table width=100%><tr><td width=20% valign=top><img src=\\"".get_image($data_singer[''img''])."\\" border=0 title=\\"$data_singer[name]\\"></td>\r\n<td valign=top> \r\n<span class=title>$data_singer[name]</span><br><br>";\r\n\r\nif($data_singer[''content'']){\r\nprint "$data_singer[content] <br><br>";\r\n}\r\n\r\nprint "\r\n<span><img src=''$style[images]/add_date.gif''>&nbsp;<b>$phrases[last_update]  : </b>".iif($data_singer[''last_update''],get_date($data_singer[''last_update'']),$phrases[''not_available''])."</span><br>\r\n\r\n<span><img src=''$style[images]/views.gif''>&nbsp;<b>$phrases[visits] : </b> $data_singer[views]</span> <br>";\r\n\r\n\r\n//--------- fields -------------\r\nforeach($singer_fields as $field){\r\n$value = $data["field_".$field[''id'']];\r\nif($value){\r\nprint "<span><img src=''$style[images]/info.gif''> &nbsp;<b>$field[name] : </b> ".iif($field[''search''],"<a href=\\"search.php?op=singers&field_id=$field[id]&keyword=".$value."\\">").$value.iif($field[''search''],"</a>")."</span><br>";\r\n}\r\n} \r\n//-------------------------------\r\n\r\n\r\nprint "<br>";\r\n      \r\n\r\n\r\n\r\nprint_rating(''singer'',$data_singer[''id''],$data_singer[''rate'']);    \r\n\r\nprint " </td></tr></table>";\r\n//}\r\n//-------- Album ---------//\r\nif($data_album[''name'']){\r\n\r\n$album_fields = get_albums_fields_sets();\r\n\r\n\r\nprint "<hr class=''separate_line'' size=1 width=\\"40%\\" align=\\"$global_align\\">\r\n<table width=100%>\r\n<tr><td width=20% valign=top><img src=\\"".get_image($data_album[''img''])."\\" border=0 title=\\"$data_singer[name] - $data_album[name]\\"></td>\r\n<td valign=top><span class=title>$phrases[album] $data_album[name]</span>\r\n<br><br>";\r\n\r\nif($data_album[''year'']){\r\nprint "<span><img src=''$style[images]/add_date.gif''>&nbsp;<b>$phrases[release_year] : </b> <a href=\\"".str_replace("{year}",$data_album[''year''],$links[''albums_page_w_year''])."\\" title=\\"$data_album[year]\\">$data_album[year]</a> </span><br>";\r\n}\r\n\r\nprint "<span><img src=''$style[images]/song.gif''>&nbsp;<b> $phrases[the_songs_count] : </b>$data_album[songs_count]</span>\r\n<br>\r\n<span><img src=''$style[images]/views.gif''>&nbsp;<b>$phrases[visits] : </b> $data_album[views] </span><br>";\r\n\r\n//--------- fields -------------\r\nforeach($album_fields as $field){\r\n$value = $data_album["field_".$field[''id'']];\r\nif($value){\r\nprint "<span><img src=''$style[images]/info.gif''> &nbsp;<b>$field[name] : </b> ".iif($field[''search''],"<a href=\\"search.php?op=albums&field_id=$field[id]&keyword=".$value."\\">").$value.iif($field[''search''],"</a>")."</span><br>";\r\n}\r\n} \r\n//-------------------------------\r\n\r\nprint "<br>";\r\n\r\nprint_rating(''album'',$data_album[''id''],$data_album[''rate'']);\r\n\r\n\r\nprint "</td></tr></table>";\r\n}\r\n\r\nprint "</td><td align=''$global_align_x''>";\r\n\r\n\r\nprint "<div class=''singer_btn''>\r\n<a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_overview''])."\\"><img src=''$style[images]/overview.gif''>&nbsp;$phrases[overview]</a>\r\n</div>";\r\n\r\nif($data_singer[''details'']){\r\nprint "<div class=''singer_btn''>\r\n<a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_bio''])."\\"><img src=''$style[images]/bio.gif''>&nbsp;$phrases[bio]</a>\r\n</div>";\r\n}\r\n\r\n\r\nprint "<div class=''singer_btn''><a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_songs''])."\\"><img src=''$style[images]/song.gif''>&nbsp;$phrases[the_songs] ($data_singer[songs_count])</a></div>";\r\n\r\nif($data_singer[''albums_count'']){\r\nprint "<div class=''singer_btn''>\r\n<a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_albums''])."\\"><img src=''$style[images]/album.gif''>&nbsp;$phrases[the_albums] ($data_singer[albums_count])</a></div>";\r\n}\r\n\r\n\r\n\r\nif($data_singer[''photos_count'']){\r\nprint "<div class=''singer_btn''><a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_photos''])."\\"><img src=''images/photos.gif''>&nbsp;$phrases[the_photos] ($data_singer[photos_count])</a></div>";\r\n}\r\n\r\nif($data_singer[''videos_count'']){\r\nprint "<div class=''singer_btn''><a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_videos''])."\\"><img src=''$style[images]/videos.gif''>&nbsp;$phrases[the_videos] ($data_singer[videos_count])</a>\r\n</div>";\r\n}\r\n\r\nprint "</td></tr></table>\r\n<br>\r\n<div align=''$global_align_x''>\r\n<a href=''http://www.facebook.com/sharer.php?u=".urlencode("http://".$_SERVER[''HTTP_HOST''].$_SERVER[''REQUEST_URI''])."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook_mid.gif'' alt=''Share it on Facebook'' border=0></a>\r\n</div>";\r\nclose_table();', 1, 1, 1),
(11, 'شريط الحروف للمغنيين', 'letters_singers', '<?\r\nglobal $links;\r\n$ltrs = array("ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي");\r\n\r\nforeach($ltrs as $ltr){\r\nprint "<a class=\\"big\\" href=\\"".str_replace(''{letter}'',$ltr,$links[''letters_singers''])."\\">{$ltr}</a>&nbsp;";\r\n}\r\n?>', 1, 1, 1),
(12, 'شريط الحروف للأغاني', 'letters_songs', '<?\r\nglobal $links;\r\n\r\n$ltrs = array("ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي");\r\n\r\nforeach($ltrs as $ltr){\r\nprint "<a class=\\"big\\" href=\\"".str_replace(''{letter}'',$ltr,$links[''letters_songs''])."\\">{$ltr}</a>&nbsp;";\r\n}\r\n?>', 1, 1, 1),
(125, '', 'singer_overview', '<?\r\nglobal $id,$no_singer_name,$qr_videos,$qr_photos,$data,$qr,$without_tables,$global_align_x,$links,$data_singer,$settings,$phrases;\r\n\r\n$without_tables = true;\r\n\r\n$all_songs_div = "<br>\r\n<div align=''$global_align_x''>\r\n<a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_songs''])."\\">$phrases[all_songs]</a></div>";\r\n\r\n\r\nprint "\r\n<table width=100%>\r\n\r\n<tr><td width=50%>";\r\nopen_table("اخر الاضافات");\r\nsongs_table($id,"all","","id","desc",0,10);\r\n\r\nprint $all_songs_div;\r\n\r\nclose_table();\r\nprint "\r\n</td><td width=50%>";\r\nopen_table("الاكثر تقييما");\r\nsongs_table($id,"all","","rate","desc",0,10); \r\n\r\nprint $all_songs_div;\r\n\r\nclose_table();\r\nprint "</td></tr>\r\n\r\n\r\n\r\n<tr><td width=50%>";\r\nopen_table("الاكثر استماعا");\r\nsongs_table($id,"all","","listens_1","desc",0,10);\r\nprint $all_songs_div; \r\nclose_table();\r\nprint "\r\n</td><td width=50%>";\r\nopen_table("الاكثر تحميلا");\r\nsongs_table($id,"all","","downloads_1","desc",0,10);  \r\nprint $all_songs_div;\r\nclose_table();\r\nprint "</td></tr></table>";\r\n\r\n\r\n//------------------- photos -----------------------\r\n$qr = $qr_photos;\r\n   if(db_num($qr)){\r\n    open_table($phrases[''singer_photos'']);\r\n    run_template(''browse_photos'');\r\n\r\nprint "<p align=''$global_align_x''><a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_photos''])."\\">جميع الصور</a></p>";\r\n\r\n    close_table();         \r\n         }\r\n\r\n//--------------- videos ---------------------\r\n\r\n if(db_num($qr_videos)){\r\n   open_table($phrases[''singer_videos'']); \r\n    run_template(''browse_videos_header'');\r\n\r\n    $c=0;\r\nwhile($data = db_fetch($qr_videos)){\r\n\r\n\r\n\r\nif ($c==$settings[''songs_cells'']) {\r\nrun_template("browse_videos_sep");\r\n$c = 0 ;\r\n}\r\n\r\n\r\n    run_template(''browse_videos'');\r\n$c++;\r\n\r\n           }\r\nrun_template(''browse_videos_footer'');\r\n\r\nprint "<p align=''$global_align_x''><a href=\\"".str_replace(array("{id}","{name}"),array($data_singer[''id''],singer_url_name($data_singer[''page_name''],$data_singer[''name''])),$links[''singer_videos''])."\\">جميع الكليبات</a></p>";\r\nclose_table();\r\n}\r\n\r\n\r\n//------ Comments -------------------\r\nif($settings[''enable_singer_comments'']){\r\n    open_table($phrases[''members_comments'']);\r\n    get_comments_box(''singer'',$id);\r\n    close_table();\r\n}', 1, 1, 1),
(126, '', 'browse_photos', '<?\r\nglobal $qr,$settings,$phrases,$links;\r\n\r\nprint "<center><table width=''100%''><tr>";\r\n$c=0 ;\r\n\r\nwhile($data = db_fetch($qr)){\r\n\r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n\r\n\r\nprint "<td align=center><a href=\\"".str_replace("{id}",$data[''id''],$links[''singer_photo''])."\\"><img border=0 src=\\"".get_image($data[''thumb''])."\\" title=\\"$data[name]\\"></a>";\r\n\r\nif($data[''singer_name'']){\r\nprint "<br><a href=\\"".singer_url($data[''singer_id''],$data[''singer_page_name''],$data[''singer_id''])."\\" title=\\"$data[singer_name]\\">$data[singer_name]</a>";\r\n}\r\n\r\nprint "<br></td>" ;\r\n\r\n$c++;\r\n}\r\n\r\nprint "</tr></table>";', 1, 1, 2),
(13, 'عرض المغنيين', 'browse_singers', '<?\r\nglobal $data,$data_cat,$action,$links,$settings,$letter;\r\n\r\n\r\n\r\nprint "<center><a href=\\"".singer_url($data[''id''],$data[''page_name''],$data[''name''])."\\" title=\\"$data[name]\\"><img src=\\"".get_image($data[''img''])."\\" alt=\\"$data[name]\\"><br>$data[name]</a>";\r\n\r\n\r\nif(CFN=="index.php"){\r\nif($data[''last_update'']){\r\nprint "<br><font color=#9D9D9D>".get_date($data[''last_update''])."</font>";\r\n}\r\n}\r\n\r\nif(CFN=="search.php" || $letter){\r\nprint "<br><a href=\\"".cat_url($data[''cat_id''],$data[''cat_page_name''],$data[''cat_name''])."\\" title=\\"$data[cat_name]\\">$data[cat_name]</a>";\r\n}\r\n\r\nprint "<br><br></center>";\r\n?>', 1, 1, 0),
(14, 'عرض الألبومات', 'browse_albums', '<?\r\nglobal $phrases,$data_album,$action;\r\n\r\nprint "<center><a href=\\"".album_url($data_album[''id''],$data_album[''page_name''],$data_album[''name''],$data_album[''singer_id''],$data_album[''singer_page_name''],$data_album[''singer_name''])."\\"><img border=0 src=''".get_image($data_album[''img''])."'' title=\\"$data_album[name]".iif($data_album[''year'']," ($data_album[year])")."\\"><br>";\r\n\r\nif($data_album[''singer_name''] && CFN != "songs.php"){\r\nprint "$data_album[singer_name] - ";\r\n}\r\nprint "$data_album[name]".iif($data_album[''year'']," <br> <font color=#9D9D9D>$data_album[year]</font>")."</a><br><br></center>";\r\n?>', 1, 1, 1),
(20, 'عرض الكليبات', 'browse_videos', '<?\r\nglobal $data,$data_cat,$settings,$phrases,$action,$is_user_cp,$links;\r\n\r\nprint " <td><center><a href=''".str_replace(''{id}'',$data[''id''],$links[''video_watch''])."'' title=\\"$data[name]\\">\r\n            <img border=0 alt=\\"$data[name]\\"\r\n            src=''".get_image($data[''img''])."''>\r\n            <br>$data[name] </a>";\r\n\r\n\r\n\r\nif(CFN != ''videos.php''){\r\nprint "<br><a href=\\"".str_replace("{id}",$data_cat[''id''],$links[''browse_videos''])."\\" title=\\"$data_cat[name]\\">$data_cat[name]</a>";\r\n}\r\n\r\n\r\nif($data[''fav_id'']){\r\nprint "<br><br>\r\n<a href=\\"usercp.php?action=del_fav&id=$data[fav_id]\\" onclick=\\"return confirm(''$phrases[are_you_sure]'');\\"><img src=''images/delete.gif'' title=''$phrases[delete]'' border=0>$phrases[delete]</a>";\r\n}\r\n\r\n print "</center>    </td>";\r\n        ?>\r\n        \r\n        \r\n        \r\n        ', 1, 1, 2),
(22, 'عرض الأخبار - خارجي', 'browse_news', '<?\r\nglobal $phrases,$data,$links,$settings;\r\n\r\n$news_date = get_date($data[''date'']);\r\n$details_link = str_replace(''{id}'',$data[''id''],$links[''news_details'']);\r\n\r\n\r\nprint "<table width=100%>\r\n\r\n<tr><td colspan=2 align=center>\r\n<a href=\\"$details_link\\" title=\\"$data[title]\\"><span class=''title''>$data[title]</span></a>\r\n</td></tr>\r\n\r\n\r\n<tr><td align=center width=''80''>\r\n<a href=\\"$details_link\\" title=\\"$data[title]\\"><img src=\\"".get_image($data[''img''])."\\" title=\\"$data[title]\\"></a></td>\r\n<td>\r\n\r\n<font color=''#808080''>$news_date : </font> $data[content] ... <a href=\\"$details_link\\"> $phrases[read_more]</a>\r\n<br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font></td></tr>\r\n\r\n</table>\r\n<hr class=separate_line size=\\"1\\">";\r\n?>', 1, 1, 0),
(18, 'عرض الأغاني', 'browse_songs', '<?\r\nglobal $data,$song_ext,$data_singer,$op,$settings,$phrases,$lyrics_count,$action,$is_user_cp,$urls_sets,$urls_data,$songs_fields_sets,$links,$is_member,$orderby,$videos_count,$style,$no_singer_name,$tr_class,$scripturl;\r\n\r\n\r\nprint "<div class=''song_div'' searchtext=\\"$data[name]\\">\r\n<table width=100%><tr class=''$tr_class''>\r\n<td>";\r\nif($settings[''songs_multi_select''] && CFN != "singer_overview.php"){\r\nprint "<input type=''checkbox'' name=\\"song_id[]\\" value=\\"$data[id]\\">";\r\n}\r\nprint "<img src=''images/song.gif'' border=0> &nbsp; <a href=\\"".str_replace(array(''{cat}'',''{id}''),array($settings[''default_url_id''],$data[''id'']),$links[''song_listen''])."\\" title=\\"$data[name]\\">$data[name]</a>";\r\n\r\nif($data[''c_ext'']){\r\nprint "&nbsp;&nbsp; <a href=\\"search.php?op=songs&c_ext=1&keyword=$data[c_ext]\\" title=\\"$data[c_ext]\\"><font color=''#808080''><i>$data[c_ext]</i></font></a>";\r\n}\r\n\r\n\r\nif($song_ext[''id'']){\r\nprint "&nbsp;&nbsp; <a href=\\"search.php?op=songs&ext=$song_ext[id]&keyword=$song_ext[name]\\" title=\\"$song_ext[name]\\"><font color=''#D20000''><i>$song_ext[name]</i></font></a>";\r\n}\r\n\r\nif($orderby=="id"){\r\nprint "&nbsp;&nbsp; <font color=''#000000''><i>".get_date($data[''date''])."</i></font>";\r\n}\r\n\r\nif($orderby=="rate"){\r\nprint "&nbsp;&nbsp; <font color=''#000000''><i>$data[rate]/ 5 </i></font>";\r\n}\r\n\r\n\r\n//--------- fields ---------------\r\n$br_printed = false;\r\n\r\nforeach($songs_fields_sets as $field){\r\n$value = $data["field_".$field[''id'']];\r\nif($value){\r\nif(!$br_printed){print "<br>";$br_printed=true;}\r\nprint "<b>$field[name] : </b> ".iif($field[''search''],"<a href=\\"search.php?op=songs&field_id=$field[id]&keyword=".$value."\\">").$value.iif($field[''search''],"</a>")."&nbsp";\r\n}\r\n} \r\n//-------------------------------------\r\n\r\nprint "</td>";\r\n\r\nif($data_singer[''name''] && !$no_singer_name){\r\nprint "<td width=''40%''>".print_link($data_singer[''name''],singer_url($data_singer[''id''],$data_singer[''page_name''],$data_singer[''name'']))."</td>";\r\n}\r\n\r\n\r\nforeach($urls_sets as $set_value){\r\n\r\n//------ int listen ---------------//\r\nif($set_value[''show_listen'']){\r\nif($data["url_".$set_value[''id'']]){\r\nprint "<td align=center width=20><a href=\\"".str_replace(array(''{cat}'',''{id}''),array($set_value[''id''],$data[''id'']),$links[''song_listen''])."\\"".iif($set_value[''listen_type'']==1," onClick=\\"return listen($data[id],$set_value[id]);\\"")."><img src=''".get_image($set_value[''listen_icon''],''images/listen.gif'')."'' title=\\"".str_replace("{listens}",$data["listens_".$set_value[''id'']],$set_value[''listen_alt''])."\\" border=0></a></td>";\r\n}else{\r\nprint "<td></td>";\r\n}\r\n}\r\n\r\n//----------- ext listen --------//\r\n\r\nif($set_value[''show_ext_listen'']){\r\nif($data["url_".$set_value[''id'']]){\r\nprint "<td align=center width=20><a href=\\"".str_replace(array(''{cat}'',''{id}''),array($set_value[''id''],$data[''id'']),$links[''song_ext_listen''])."\\"><img src=''".get_image($set_value[''ext_listen_icon''],''images/listen.gif'')."'' title=\\"".str_replace("{listens}",$data["listens_".$set_value[''id'']],$set_value[''ext_listen_alt''])."\\" border=0></a></td>";\r\n}else{\r\nprint "<td></td>";\r\n}\r\n}\r\n\r\n//------------ download ---------//\r\nif($set_value[''show_download'']){\r\nif($data["url_".$set_value[''id'']]){\r\n print "<td align=center width=20><a href=\\"".str_replace(array(''{cat}'',''{id}''),array($set_value[''id''],$data[''id'']),$links[''song_download''])."\\"><img src=''".get_image($set_value[''download_icon''],''images/save.gif'')."'' title=\\"".str_replace("{downloads}",$data["downloads_".$set_value[''id'']],$set_value[''download_alt''])."\\" border=0></a></td>";\r\n}else{\r\nprint "<td></td>";\r\n}\r\n}\r\n}\r\n\r\n//-------- video ---------//\r\n\r\nif(CFN != "singer_overview.php"){\r\n\r\nif($data[''video_id'']){\r\nprint "<td align=''center'' width=20><a href=\\"".str_replace("{id}",$data[''video_id''],$links[''video_watch''])."\\"><img src=''$style[images]/video.gif'' title=\\"$phrases[video] $data[name]\\" border=0></a></td>";\r\n}else{\r\nif($videos_count){\r\nprint "<td width=20 align=''center''><img src=''$style[images]/video_disabled.gif''></td>";\r\n}\r\n}\r\n\r\n//------- vote -----------//\r\nif($settings[''vote_song'']){\r\n print "<td align=center width=20><a href=\\"javascript:vote(''$data[id]'',''song'')\\"><img src=''images/vote_song.gif'' title=''$phrases[vote_song]'' border=0></a></td>    ";\r\n         \r\n}\r\n\r\n\r\n//-------- send -----------//\r\nif($settings[''snd2friend'']){\r\n print "<td align=center width=20><a href=\\"javascript:send($data[id],''song'')\\" title=''$phrases[send2friend]''><img src=''images/snd.gif'' alt=''$phrases[send2friend]'' border=0></a></td>    ";\r\n         }\r\n\r\n\r\n//-------- share ----------//\r\nprint "<td align=center width=20><a href=''http://www.facebook.com/sharer.php?u=".urlencode($scripturl."/".str_replace(array(''{cat}'',''{id}''),array(1,$data[''id'']),$links[''song_listen'']))."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook.gif'' alt=''Share it on Facebook'' border=0></a></td>";\r\n}\r\n\r\n\r\n//-------- playlist ----------//\r\nprint "<td align=center width=20><a href=\\"javascript:;\\" onClick=\\"".iif($is_member && !$is_user_cp , "playlist_add_song($data[id]);","alert(''$phrases[please_login_first]'');")."\\" title=''$phrases[add_to_playlist]''><img src=''images/playlist_add.gif'' title=''$phrases[add_to_playlist]'' border=0></a></td>";\r\n\r\n\r\n\r\n//----------- lyrics -----------//\r\nif($data[''lyrics'']){\r\nprint" <td align=center width=20><a href=''lyrics-$data[id].html'' title=''$phrases[lyrics]''><img src=''images/lyric.gif'' title=''$phrases[lyrics]'' border=0></a></td>";\r\n}else{\r\nif($lyrics_count > 0){\r\nprint "<td width=20></td>";\r\n}\r\n}\r\n\r\n\r\nprint "</tr></table></div>";\r\n\r\n?>   ', 1, 1, 0),
(42, 'قالب الخطوط و الألون العامة', 'CSS', '/*------------ BODY ---------------*/\r\n\r\nBODY {\r\nFONT-SIZE: 8pt; \r\nCOLOR: #1266a5;\r\nFONT-FAMILY: Tahoma; \r\n\r\nmargin-top: 0px;\r\nmargin-right: 0px;\r\nmargin-bottom: 0px;\r\nmargin-left: 0px;\r\n}\r\n\r\n.header {\r\nheight:150px;\r\nwidth:100%px;\r\nbackground-image: url(''images/header_bg.jpg'');\r\n\r\ntext-align: right;\r\nclear:both;\r\n  border:1px solid #e7e7e7;\r\n  -moz-border-radius:5px;\r\n  -webkit-border-radius:5px;\r\n  -o-border-radius:5px;\r\n  border-radius:5px;\r\n}\r\n\r\n.footer {\r\nheight:40px;\r\nwidth:100%px;\r\n\r\nclear:both;\r\n  background:#f6f6f6;\r\n  padding:3em 3em 3em;\r\n  border:1px solid #e7e7e7;\r\n  -moz-border-radius:5px;\r\n  -webkit-border-radius:5px;\r\n  -o-border-radius:5px;\r\n  border-radius:5px;\r\ndirection:rtl;\r\n}\r\n\r\n.block_div {\r\n  clear:both;\r\n  background:#f6f6f6;\r\n  padding:1em 1em 1em;\r\n  border:1px solid #e7e7e7;\r\n  -moz-border-radius:5px;\r\n  -webkit-border-radius:5px;\r\n  -o-border-radius:5px;\r\n  border-radius:5px;\r\ntext-align: right;\r\ndirection:rtl;\r\n\r\n\r\n}\r\n\r\n\r\nimg { \r\nborder: 0px; \r\n}\r\n\r\nfieldset {\r\n	border:  1px solid #e7e7e7;padding: 2;\r\n	\r\n}\r\n\r\n\r\n\r\n\r\n\r\nselect{\r\nborder:1px solid #dcdcdc;border:1px solid rgba(0, 0, 0, 0.1);color:#666;cursor:pointer;min-height:25px;font-family:inherit;}\r\n\r\n\r\n\r\n\r\ninput[type="submit"]{\r\nbackground-image:-webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#f1f1f1));background-image:-webkit-linear-gradient(top,#f5f5f5,#f1f1f1);-webkit-border-radius:2px;-webkit-user-select:none;background-color:#f5f5f5;background-image:linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-o-linear-gradient(top,#f5f5f5,#f1f1f1);border:1px solid #dcdcdc;border:1px solid rgba(0, 0, 0, 0.1);border-radius:2px;color:#666;cursor:pointer;line-height:27px;margin:11px 6px;min-width:54px;padding:0 8px;text-align:center}\r\n\r\ninput[type="submit"]:hover{background-image:-webkit-gradient(linear,left top,left bottom,from(#f8f8f8),to(#f1f1f1));background-image:-webkit-linear-gradient(top,#f8f8f8,#f1f1f1);-webkit-box-shadow:0 1px 1px rgba(0,0,0,0.1);background-color:#f8f8f8;background-image:linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-o-linear-gradient(top,#f8f8f8,#f1f1f1);border:1px solid #c6c6c6;box-shadow:0 1px 1px rgba(0,0,0,0.1);color:#333}\r\n\r\ninput[type="submit"]:focus{border:1px solid #4d90fe;outline:none}\r\n\r\n\r\ninput[type="button"]{\r\nbackground-image:-webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#f1f1f1));background-image:-webkit-linear-gradient(top,#f5f5f5,#f1f1f1);-webkit-border-radius:2px;-webkit-user-select:none;background-color:#f5f5f5;background-image:linear-gradient(top,#f5f5f5,#f1f1f1);background-image:-o-linear-gradient(top,#f5f5f5,#f1f1f1);border:1px solid #dcdcdc;border:1px solid rgba(0, 0, 0, 0.1);border-radius:2px;color:#666;cursor:pointer;line-height:20px;min-width:54px;padding:0 8px;text-align:center}\r\n\r\ninput[type="button"]:hover{background-image:-webkit-gradient(linear,left top,left bottom,from(#f8f8f8),to(#f1f1f1));background-image:-webkit-linear-gradient(top,#f8f8f8,#f1f1f1);-webkit-box-shadow:0 1px 1px rgba(0,0,0,0.1);background-color:#f8f8f8;background-image:linear-gradient(top,#f8f8f8,#f1f1f1);background-image:-o-linear-gradient(top,#f8f8f8,#f1f1f1);border:1px solid #c6c6c6;box-shadow:0 1px 1px rgba(0,0,0,0.1);color:#333}\r\n\r\ninput[type="button"]:focus{border:1px solid #4d90fe;outline:none}\r\n\r\n\r\ninput{font-family:inherit} \r\n\r\n\r\n\r\n.singer_btn{\r\nbackground-image:-webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#f1f1f1));\r\nbackground-image:-webkit-linear-gradient(top,#f5f5f5,#f1f1f1);-webkit-border-radius:2px;-webkit-user-select:none;\r\nbackground-color:#f5f5f5;\r\nbackground-image:linear-gradient(top,#f5f5f5,#f1f1f1);\r\nbackground-image:-o-linear-gradient(top,#f5f5f5,#f1f1f1);\r\nborder:1px solid #dcdcdc;border:1px solid rgba(0, 0, 0, 0.1);\r\nborder-radius:2px;color:#666;line-height:27px;\r\nmargin:6px 6px;\r\nmin-width:200px;padding:0 8px;\r\nwidth:200px;\r\ntext-align:center\r\n}\r\n\r\n\r\n\r\n/*---------- TITLES FONT --------------*/\r\n.title {\r\nFONT-SIZE: 10pt; COLOR: #78a71e; TEXT-DECORATION: none; font-weight:bold;text-align: center;align: center;\r\n}\r\n\r\n\r\n.block_title{\r\n\r\n}\r\n\r\n.table_title{\r\n}\r\n\r\n\r\n/*------------- LINKS ---------------*/\r\nA:link {\r\n	 COLOR: #0066CC;TEXT-DECORATION: none;\r\n}\r\n\r\n\r\nA:active {\r\n	COLOR: #0066CC;TEXT-DECORATION: none;\r\n\r\n}\r\nA:visited {\r\n	COLOR: #0066CC;TEXT-DECORATION: none; \r\n}\r\nA:hover {\r\n	COLOR: #007CF9;TEXT-DECORATION: none; \r\n}\r\n\r\n.big {\r\nFONT-SIZE: 10pt; weight:bold;COLOR: #0066CC; TEXT-DECORATION: none;\r\n}\r\n/*---------- LETTERS LINKS -----------*/\r\nA:link.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; TEXT-DECORATION: none;\r\n}\r\n\r\n\r\nA:active.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; TEXT-DECORATION: none;\r\n\r\n}\r\nA:visited.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; TEXT-DECORATION: none;\r\n}\r\nA:hover.big {\r\n	FONT-SIZE: 10pt; COLOR: #007CF9;TEXT-DECORATION: none;\r\n}\r\n\r\n/*----------- PATH BAR LINKS ------------*/\r\nA:link.path_link {\r\n	COLOR: #0066CC; TEXT-DECORATION: none;\r\n}\r\nA:active.path_link {\r\n	COLOR: #0066CC; TEXT-DECORATION: none;\r\n\r\n}\r\nA:visited.path_link {\r\n	COLOR: #0066CC; TEXT-DECORATION: none;\r\n}\r\nA:hover.path_link {\r\n	COLOR: #007CF9; TEXT-DECORATION: none;\r\n}\r\n\r\n\r\n/*---------- SONGS TABLES COLORS ---------*/\r\n.row_1{\r\nbackground-color: #f7f7f7;\r\n\r\n}\r\n\r\n\r\n.row_2{\r\nbackground-color: #FCFCFC ;\r\n}\r\n\r\n.row_1:hover{\r\nbackground-color: #E8F8FF;\r\n}\r\n\r\n.row_2:hover{\r\nbackground-color: #E8F8FF;\r\n}\r\n\r\n\r\n/*--------- MEMBERS MESSAGES FONT--------*/\r\n.messages {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\n/*------------ SPARATE LINKE -----------------*/\r\n.separate_line{\r\nborder-width: 1px 0 0 0; border-style: solid; border-color: #e7e7e7;\r\n}\r\n/*------------ Search Replace-----------------*/\r\n.search_replace{\r\ncolor: #FF0000;\r\n}\r\n\r\n\r\n/* ---------- Tabs ------------ */\r\n.tabs {\r\nwidth: 100%;\r\n\r\n		margin: 0px;\r\n}\r\n\r\n.tab_active {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-width: 1px;\r\n	border-style: solid;\r\n	background-color: #fff;\r\n	color: #000;\r\n	float: right;\r\n	width: 150px;\r\n	cursor: default;\r\n	font-weight: bold;\r\n	padding: 2px;\r\n	font-size: 10pt;\r\n	text-align: center;\r\n	background-image:url(''images/tabs_shade.gif'')\r\n}\r\n\r\n.tab_inactive {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 1px;\r\n	background-color: #ddd;\r\n	color: #777;\r\n	float: right;\r\n	width: 150px;\r\n        cursor:pointer;\r\n	cursor: hand;\r\n	padding: 2px;\r\n	font-size: 10pt;\r\n	text-align: center;\r\n}\r\n\r\n.tab_content {\r\n	-moz-border-radius: 0px 10px 10px 10px;\r\n	width: 99%;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 0px;\r\n	color: #000;\r\n	float: right;\r\n	text-align: right;\r\n	padding: 10px;\r\n}\r\n\r\n.tab_container {\r\nwidth: 100%;\r\nalign: center;\r\ntext-align: center;\r\n}\r\n\r\n\r\n\r\n/* --------- Slider ---------------*/\r\n\r\n.slider_active {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-width: 1px;\r\n	border-style: solid;\r\n	background-color: #fff;\r\n	color: #000;\r\n	float: right;\r\n	\r\n	cursor: default;\r\n	font-weight: bold;\r\n\r\nmargin: 0 5px; \r\nheight:15;\r\npadding: 3px 5px;\r\n\r\n	font-size: 10pt;\r\n	text-align: center;\r\n	background-image:url(''images/tabs_shade.gif'')\r\n}\r\n\r\n.slider_inactive {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 1px;\r\n	background-color: #ddd;\r\n	color: #777;\r\n	float: right;\r\n        cursor:pointer;\r\n	cursor: hand;\r\n       \r\n\r\nmargin: 0 5px; \r\nheight:15;\r\npadding: 3px 5px;\r\n\r\n	font-size: 10pt;\r\n	text-align: center;\r\n}\r\n\r\n\r\n\r\n\r\n.slider_btnz{\r\ncursor: hand;\r\nwidth:25;\r\n}\r\n\r\n//-------- pop Dialog ---------------\r\n\r\n.boxy-wrapper { position: absolute; left: 50%;\r\n  top: 50%;}\r\n\r\n.boxy-wrapper.fixed { position: fixed;  }\r\n\r\n  /* Modal */\r\n  \r\n  .boxy-modal-blackout { position: absolute; background-color: black; left: 0; top: 0; }\r\n  \r\n  /* Border */\r\n\r\n  .boxy-wrapper { empty-cells: show; }\r\n    .boxy-wrapper .top-left,\r\n    .boxy-wrapper .top-right,\r\n    .boxy-wrapper .bottom-right,\r\n    .boxy-wrapper .bottom-left { width: 10px; height: 10px; padding: 0 ;background-color: black;opacity: 0.6; filter: alpha(opacity=60);}\r\n    \r\n    \r\n	.boxy-wrapper .top,\r\n	.boxy-wrapper .bottom { height: 10px; background-color: black; opacity: 0.6; filter: alpha(opacity=60); padding: 0 }\r\n	\r\n	.boxy-wrapper .left,\r\n	.boxy-wrapper .right { width: 10px; background-color: black; opacity: 0.6; filter: alpha(opacity=60); padding: 0 }\r\n	\r\n	/* Title bar */\r\n	\r\n	.boxy-wrapper .title-bar { background-color: black; padding: 6px; position: relative; text-align:center; }\r\n	  .boxy-wrapper .title-bar.dragging { cursor: move; }\r\n	    .boxy-wrapper .title-bar h2 { font-size: 12px; color: white; line-height: 1; margin: 0; padding: 0; font-weight: normal; }\r\n	    .boxy-wrapper .title-bar .close { color: white; position: absolute; top: 6px; right: 6px; font-size: 90%; line-height: 1; }\r\n		\r\n	/* Content Region */\r\n	\r\n	.boxy-inner { background-color: #FFFFFF; padding: 0 }\r\n	.boxy-content { padding: 15px; }\r\n	\r\n	/* Question Boxes */\r\n\r\n    .boxy-wrapper .question { width: 350px; min-height: 80px; }\r\n    .boxy-wrapper .answers { text-align: right; }\r\n\r\n/*------- Playlist --------------*/\r\n.pl_song_play {\r\n    \r\n    background-image: url("images/play.png");\r\n    background-repeat:no-repeat;\r\n    background-position:right top;\r\n    padding-right:30px;\r\n    height: 20px;\r\n    background-color:#C0C0C0;\r\n    cursor:pointer;\r\n}\r\n.pl_song_stop {\r\n    padding-right:30px;\r\n    height: 20px;\r\n    background-color:#ffffff;\r\n    cursor:pointer;\r\n}\r\n\r\n\r\n/*------------ Pages ------------- */\r\n.pagenavi {\r\n	clear: both;\r\nalign:center;\r\n}\r\n\r\n.pagenavi a, .pagenavi span {\r\n	text-decoration: none;\r\n	border: 1px solid #BFBFBF;\r\n	padding: 3px 5px;\r\n	margin: 1px;\r\n}\r\n\r\n.pagenavi a:hover, .pagenavi span.current {\r\n	border-color: #000;\r\n}\r\n\r\n.pagenavi span.current {\r\n	font-weight: bold;\r\n}', 1, 1, 5),
(104, '', 'news_cats', '<?\r\nglobal $data,$links,$style;\r\n\r\nprint "<td align=center><a href=\\"".str_replace(''{cat}'',$data[''id''],$links[''browse_news''])."\\"><img src=\\"".get_image($data[''img''],"$style[images]/folder.gif")."\\" title=\\"$data[name]\\"><br>$data[name]</a></td>";\r\n\r\n\r\n?>', 1, 1, 0),
(105, '', 'news_cats_header', '<?\r\nopen_table();\r\nprint "<table width=100%><tr>";\r\n?>', 1, 1, 0),
(106, '', 'news_cats_sep', '</tr><tr>', 1, 1, 0),
(107, '', 'news_cats_footer', '<?\r\nprint "</tr></table>";\r\nclose_table();\r\n?>', 1, 1, 0),
(23, 'رأس الصفحة', 'page_head', '<?\r\nglobal $settings,$section_name,$title_sub,$sitename,$meta_keywords,$meta_description,$settings,$action,$scripturl;\r\n\r\nif(($section_name && $settings[''section_name_in_subpages'']) || $title_sub){\r\n$full_title = iif($sitename && ($settings[''sitename_in_subpages''] ||  (CFN == "index.php" && !$action)),$sitename,'''');\r\n}else{\r\n$full_title = $sitename;\r\n}\r\nif($section_name && ($settings[''section_name_in_subpages''] || (CFN == "index.php" && !$action))){\r\n$full_title .= iif($full_title," - $section_name",$section_name);\r\n}\r\n\r\nif($title_sub){\r\n$full_title .= iif($full_title," - $title_sub",$title_sub);\r\n}\r\n\r\n\r\nprint "<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\"\r\n         \\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\\">\r\n\r\n<html xmlns=\\"http://www.w3.org/1999/xhtml\\" dir=\\"$settings[html_dir]\\">\r\n\r\n<head>\r\n<base href=\\"$scripturl/\\"".iif(CFN == "listen_window.php"," target=_blank")." />\r\n\r\n<meta http-equiv=\\"Content-Type\\" content=\\"text/html; charset=$settings[site_pages_encoding]\\" />\r\n<meta http-equiv=\\"Content-Language\\" content=\\"$settings[site_pages_lang]\\" />\r\n\r\n";\r\nprint "\r\n\r\n<meta name=\\"generator\\" content=\\"Allomani Audio and Video v3.0\\" />\r\n\r\n<meta name=\\"keywords\\" content=\\"allomani,اللوماني,".$meta_keywords."\\" />\r\n<meta name=\\"description\\" content=\\"$meta_description\\" />\r\n\r\n<meta name=\\"robots\\" content=\\"index, follow\\" />\r\n<meta name=\\"rating\\" content=\\"General\\" /> \r\n<meta name=\\"distribution\\" content=\\"Global\\" />\r\n\r\n\r\n<link type=\\"text/css\\" rel=\\"stylesheet\\" href=\\"css.php\\" />";\r\n\r\nprint "<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Singers\\" href=\\"rss.php\\" />\r\n<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Songs\\" href=\\"rss.php?op=songs\\" />\r\n<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Albums\\" href=\\"rss.php?op=albums\\" />\r\n<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Videos\\" href=\\"rss.php?op=videos\\" />\r\n<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - News\\" href=\\"rss.php?op=news\\" />\r\n<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Photos\\" href=\\"rss.php?op=photos\\" />\r\n\r\n\r\n<title>$full_title</title>\r\n";\r\n?>\r\n<script type="text/javascript">\r\nvar scripturl="<?=$scripturl?>";\r\n</script>\r\n\r\n<script type="text/javascript" src="js/prototype.js"></script>\r\n<script type="text/javascript" src="js/javascript.js"></script>\r\n<script type=''text/javascript'' src=''js/jquery.js''></script>\r\n<script> jQuery.noConflict(); </script>\r\n<script type=''text/javascript'' src=''js/jquery.raty.min.js''></script>\r\n<?\r\n\r\nprint "<script type=''text/javascript'' src=''js/jquery.boxy.allomani.js''></script>";\r\n\r\nif(in_array(CFN,array("listen.php","listen_all.php","video_watch.php","listen_window.php"))){\r\nprint "<script type=''text/javascript'' src=''js/jwplayer.js''></script>";\r\n}\r\n?>\r\n<script type="text/javascript" src="js/scriptaculous/scriptaculous.js"></script>', 1, 1, 1),
(108, '', 'browse_news_header', '<?\r\nglobal $phrases;\r\nopen_table("$phrases[the_news]");\r\nprint "<hr class=separate_line size=\\"1\\">";    \r\n?>', 1, 1, 0),
(43, 'عرض الخبر - داخلي', 'browse_news_inside', '<?\r\nglobal $data,$phrases,$settings,$global_align,$global_align_x,$global_dir;\r\n\r\n$news_date = get_date($data[''date'']);\r\n\r\nprint "<table width=100%><tr><td>\r\n\r\n<DIV style=\\"FLOAT: $global_align_x\\"><TABLE border=\\"0\\"><TBODY><TR><TD><TABLE border=\\"0\\"><TBODY><TR><TD align=\\"center\\">\r\n<img src=''".get_image($data[''img''])."''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>$news_date</font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir=\\"$global_dir\\" align=\\"$global_align\\">\r\n$data[details] <br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font>\r\n\r\n</td></tr>\r\n<tr><td colspan=2 align=''$global_align_x''>\r\n<a href=''http://www.facebook.com/sharer.php?u=".urlencode("http://".$_SERVER[''HTTP_HOST''].$_SERVER[''REQUEST_URI''])."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook_mid.gif'' alt=''Share it on Facebook'' border=0></a>\r\n\r\n<a href=''news_print.php?id=$data[id]'' title=''$phrases[printable_copy]''><img src=''images/print.gif'' title=''$phrases[printable_copy]'' alt=''$phrases[printable_copy]'' border=0></a>\r\n\r\n</div>\r\n\r\n</td></tr></table>";\r\n\r\n\r\nprint "<br><br><center>";\r\nprint_rating(''news'',$data[''id''],$data[''rate'']);    \r\nprint "</center>";\r\n?>', 1, 1, 0),
(44, 'عرض الخبر - طباعة', 'browse_news_print', '<?\r\nglobal $settings,$data,$phrases,$global_align,$global_align_x,$global_dir;\r\n\r\nprint "<html dir=\\"$settings[html_dir]\\">\r\n<head>\r\n<META http-equiv=Content-Language content=\\"$settings[site_pages_lang]\\">\r\n<META http-equiv=Content-Type content=\\"text/html; charset=$settings[site_pages_encoding]\\">\r\n<title>$data[title]</title>\r\n</head>\r\n<body>\r\n\r\n<table width=100%>\r\n<tr>\r\n<td>\r\n<p align=center><font size=5><b>$data[title]</b></font></p>\r\n</td></tr>\r\n\r\n<tr><td>\r\n\r\n<DIV style=\\"FLOAT: $global_align_x\\"><TABLE border=\\"0\\"><TBODY><TR><TD><TABLE border=\\"0\\"><TBODY><TR><TD align=\\"center\\">\r\n<img src=\\"".get_image($data[''img''])."\\">\r\n</TD></TR><TR><TD align=center><font color=''#808080''>".get_date($data[''date''])."</font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir=\\"$global_dir\\" align=\\"$global_align\\">\r\n$data[details] <br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font>\r\n</div>\r\n</td></tr>\r\n\r\n</table>   \r\n</body>\r\n</html>";\r\n?>', 1, 1, 0),
(48, 'رسالة تأكيد تغيير البريد الالكتروني', 'email_change_confirmation_msg', '<html dir=rtl>\r\n<body>\r\n\r\nمرحبا {username} <br><br>\r\n\r\nتصلك هذه الرسالة لتأكيد بريدك الاكتروني الجديد<br><br>\r\n\r\nلتغيير بريدك الالكتروني الى هذا البريد , يرجى الضغط على الرابط التالي : <br>\r\n\r\n{active_link}\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1, 0),
(49, 'رسالة طلب تغيير كلمة المرور', 'pwd_rest_request_msg', '<html dir=rtl>\r\n<body>\r\n\r\n{name},<br><br>\r\n\r\nلقد قمت بطلب تغيير كلمة المرور لفقدانك لها , لتأكيد العملية يرجى الضغط على الرابط التالي : \r\n<br>\r\n{url}\r\n<br><br>\r\n\r\nاذا لم تكن انت من قام بعمل هذا الطلب , فضلا تجاهل هذه الرسالة\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}', 1, 1, 0),
(50, 'رسالة كلمة المرور الجديدة', 'pwd_rest_done_msg', '<html dir=rtl>\r\n<body>\r\n\r\n{name},<br>\r\nلقد تم تغيير كلمة المرور الخاصة بك,\r\n<br><br>\r\n\r\nكلمة المرور الجديدة : {password}\r\n\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1, 0),
(55, 'قالب شريط ترتيب الأغاني', 'songs_orderby', '<?\r\nglobal $phrases,$data_singer,$links,$start,$orderby,$sort,$album_id,$settings;\r\n\r\n$orders = array("name"=>$phrases[''the_name''],"id"=>$phrases[''add_date''],"rate"=>$phrases[''the_most_voted''],"listens_{$settings[''default_url_id'']}"=>$phrases[''listens''],"downloads_{$settings[''default_url_id'']}"=>$phrases[''downloads'']);\r\n\r\n\r\nprint "<span class=''path''><img src=''images/sort.gif''>&nbsp;<b>$phrases[sort_by] :</b>&nbsp;&nbsp;";\r\n\r\nforeach($orders as $key=>$value){\r\n\r\nprint "<a href=''".str_replace("{start}",$start,singer_url($data_singer[''id''],$data_singer[''page_name''],$data_singer[''name''],$album_id,$key,iif($sort==''asc'' && $key==$orderby,''desc'',''asc'')))."'' class=''path_link''>".iif($orderby==$key,"<b>").$value.iif($orderby==$key,"</b>")."</a>";\r\n\r\n\r\nif($orderby==$key && $sort=="asc"){\r\nprint "<img src=''images/arr_asc_disabled.gif'' border=0 title=\\"$value $phrases[asc]\\"></a>";\r\n}else{\r\nprint "<a href=''".str_replace("{start}",$start,singer_url($data_singer[''id''],$data_singer[''page_name''],$data_singer[''name''],$album_id,$key,''asc''))."'' class=''path_link''><img src=''images/arr_asc.gif'' border=0 title=\\"$value $phrases[asc]\\"></a>";\r\n}\r\n\r\nif($orderby==$key && $sort=="desc"){\r\nprint "<img src=''images/arr_desc_disabled.gif'' border=0 title=\\"$value $phrases[desc]\\">";\r\n}else{\r\nprint "<a href=''".str_replace("{start}",$start,singer_url($data_singer[''id''],$data_singer[''page_name''],$data_singer[''name''],$album_id,$key,''desc''))."'' class=''path_link''><img src=''images/arr_desc.gif'' border=0 title=\\"$value $phrases[desc]\\"></a>";\r\n}\r\n\r\nprint "&nbsp;";\r\n\r\n}\r\n\r\n\r\nprint "</span><br><br>";\r\n\r\n?>', 1, 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`, `views`) VALUES
(56, 'استعراض الأغاني - هيدر', 'browse_songs_header', '<?\r\nglobal $settings,$action,$urls_sets,$songs_fields_sets,$is_member,$without_tables,$phrases,$letter,$urls_sets,$songs_fields_sets,$letter;\r\n\r\n$is_member = check_member_login();\r\n\r\nif(CFN=="songs.php"){\r\n//----- sort by template ------\r\nif($settings[''visitors_can_sort_songs''] && !$letter){\r\nrun_template("songs_orderby");\r\n}\r\n//--------------------\r\n\r\n\r\nopen_table(iif($letter,$letter,""));\r\n}\r\n\r\nif($settings[''songs_multi_select''] && CFN != "singer_overview.php"){\r\nprint "<form name=''songs_form'' id=''songs_form'' action=''listen_all.php'' method=''post''>";\r\n\r\nprint "\r\n<img src=''images/find.gif''><input id=''quick_search'' onkeyup=quicksearch(this); name=''quick_search''>\r\n\r\n<a onclick=''quicksearch_clear();return false;'' href=''javascript:;'' id=''clearlnk'' style=''display:none;''><img src=''images/del_small.gif''></a><br><br>\r\n\r\n<div style=''display: none;'' id=''no_quicksearch_results'' align=center>$phrases[no_results]</div>";\r\n}\r\n                           \r\n                              ', 1, 1, 2),
(57, 'استعراض الأغاني - فوتر', 'browse_songs_footer', '<?\r\nglobal $action,$global_dir,$settings,$without_tables,$phrases,$album_id,$id,$songs_limit,$songs_perpage,$page_result,$songs_start,$page_string,$letter;\r\n\r\n\r\nif($settings[''songs_multi_select''] && CFN != "singer_overview.php"){\r\nprint "\r\n\r\n<div id=''select_and_listen''>\r\n<br>\r\n<img src=''images/arrow_".$global_dir.".gif''>&nbsp;\r\n\r\n<input type=''button'' value=''$phrases[check_all]'' onclick=\\"CheckAll(''songs_form'');\\"> <input type=''button'' value=''$phrases[uncheck_all]'' onclick=\\"UncheckAll(''songs_form'');\\"> &nbsp;<img src=''images/arrow_".$global_dir."2.gif''> &nbsp;\r\n<input type=''button'' value=''$phrases[listen_to_songs]''  onclick=\\"\\$(''songs_form'').submit();\\">\r\n</div>\r\n\r\n</form>";\r\n}\r\n\r\nif(CFN=="songs.php"){\r\nclose_table();\r\n}\r\n\r\n//---- pages links ------\r\nif(CFN=="songs.php"){  \r\nprint_pages_links($songs_start,$page_result[''count''],$songs_perpage,$page_string); \r\n}\r\n\r\n\r\nif(CFN=="songs.php" && !$letter){\r\n\r\nif($album_id > 0 && (string)$album_id != "all"){\r\n\r\nif($settings[''enable_album_comments'']){\r\n    open_table($phrases[''members_comments'']);\r\n    get_comments_box(''album'',$album_id);\r\n    close_table();\r\n}\r\n\r\n\r\n}else{\r\n\r\nif($settings[''enable_singer_comments'']){\r\n    open_table($phrases[''members_comments'']);\r\n    get_comments_box(''singer'',$id);\r\n    close_table();\r\n}\r\n\r\n}\r\n}\r\n\r\n?>', 1, 1, 1),
(112, '', 'browse_videos_cats_header', '<?\r\nopen_table();\r\nprint "<table width=100%><tr>";\r\n?>', 1, 1, 0),
(113, '', 'browse_videos_cats_sep', '</tr><tr>', 1, 1, 0),
(114, '', 'browse_videos_cats', '<?\r\nglobal $links,$data;\r\n\r\nprint "<td align=center><a href=\\"".str_replace(''{id}'',$data[''id''],$links[''browse_videos''])."\\" title=\\"$data[name]\\"><img src=\\"".get_image($data[''img''],"images/folder.gif")."\\" alt=\\"$data[name]\\"><br>$data[name]</td>";\r\n?>\r\n', 1, 1, 0),
(115, '', 'browse_videos_cats_footer', '</tr></table>', 1, 1, 0),
(116, '', 'browse_videos_footer', '<?\r\nprint "</tr></table></center>";\r\nif(CFN == "videos.php"){\r\nclose_table();\r\n}\r\n?>', 1, 1, 0),
(117, '', 'browse_videos_sep', '</tr><tr>', 1, 1, 0),
(118, '', 'browse_videos_header', '<?\r\nglobal $data_cat;\r\nif(CFN == "videos.php"){\r\nopen_table($data_cat[''name'']);\r\n}\r\n\r\nprint "<center><table width=100%>" ;\r\n?>', 1, 1, 0),
(119, 'الحروف', 'letters', '<?\r\nglobal $settings,$phrases,$action;\r\n\r\nif((CFN=="index.php" && !$action) || CFN=="songs.php" || CFN=="browse.php" || CFN=="singer_overview.php"){\r\n\r\n\r\nif($settings[''letters_songs''] || $settings[''letters_singers'']){\r\n open_table();\r\n if($settings[''letters_songs''] && $settings[''letters_singers'']){\r\n print "<table width=100%><tr><td>  $phrases[the_singers] : </td><td align=center>";\r\n        print_letters_singers();\r\n        print "</td></tr><tr><td>  $phrases[the_songs] : </td><td align=center>";\r\n        print_letters_songs();\r\n        print "</td></tr></table>";\r\n         }else{\r\n    if($settings[''letters_songs'']){\r\nprint "<p align=center>";\r\n            print_letters_songs();\r\nprint "</p>";\r\n            }\r\n        if($settings[''letters_singers'']){\r\nprint "<p align=center>";\r\n            print_letters_singers();\r\nprint "</p>";\r\n            }\r\n  }\r\n close_table();\r\n\r\n        }\r\n\r\n}\r\n?>', 1, 1, 0),
(124, 'صفحة استماع الاغنية', 'song_listen', '<?\r\nglobal $id,$cat,$data,$url,$settings,$phrases,$data_singer,$scripturl,$links,$no_singer_name,$without_tables,$style,$global_align_x,$data_video;\r\n\r\n$is_member = check_member_login();\r\n\r\n\r\nopen_table($data[''name'']);\r\n\r\n\r\nrun_player($url);\r\n\r\n\r\n print "<center><br><br>\r\n\r\n<table><tr>\r\n<td align=center>\r\n<a href=\\"".$scripturl."/".str_replace(array(''{cat}'',''{id}''),array($cat,$id),$links[''song_download''])."\\" title=\\"$phrases[download]\\"><img src=\\"$style[images]/save_mid.gif\\" alt=\\"$phrases[download]\\"></a>\r\n</td>\r\n\r\n<td align=center>\r\n<a href=''http://www.facebook.com/sharer.php?u=".urlencode($scripturl."/".str_replace(array(''{cat}'',''{id}''),array($cat,$data[''id'']),$links[''song_listen'']))."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook_mid.gif'' alt=''Share it on Facebook'' border=0></a>\r\n</td>";\r\n\r\nif($settings[''snd2friend'']){\r\n print "<td align=center><a href=\\"javascript:send($data[id])\\" title=''$phrases[send2friend]''><img src=''images/send_mid.gif'' alt=''$phrases[send2friend]'' border=0></a></td>    ";\r\n}\r\n\r\n//-------- playlist ----------//\r\nprint "<td align=center><a href=\\"javascript:;\\" onClick=\\"".iif($is_member, "playlist_add_song($data[id]);","alert(''$phrases[please_login_first]'');")."\\" title=''$phrases[add_to_playlist]''><img src=''images/playlist_add_mid.gif'' title=''$phrases[add_to_playlist]'' border=0></a></td>";\r\n\r\n//----------- report -------\r\nif($settings[''reports_enabled'']){\r\nprint "<td align=center>\r\n<a href=\\"javascript:;\\" onClick=\\"report($data[id],''song'');\\"><img src=\\"$style[images]/report.gif\\" title=\\"$phrases[report_do]\\" border=0></a>\r\n</td>";  \r\n}\r\n//-------------------------\r\n\r\n\r\nprint "\r\n</tr></table>\r\n\r\n</center>";\r\n \r\n//------- rating -----------\r\nprint "<br><br><center>";\r\nprint_rating(''song'',$data[''id''],$data[''rate'']);    \r\nprint "</center>";\r\n \r\n//----------------------------\r\n\r\n\r\n   print "<br>\r\n        <img src=''$style[images]/add_date.gif''> &nbsp; <b>$phrases[add_date] : </b>".get_date($data[''date''])."<br>";\r\n        print "<img src=''$style[images]/views.gif''> &nbsp; <b>$phrases[listens] : </b>".$data["listens_{$cat}"]; \r\n\r\nif($data[''video_id'']){\r\n print "<br><img src=''$style[images]/video.gif''> &nbsp; <b>$phrases[video] : </b> <a href=\\"".str_replace(''{id}'',$data[''video_id''],$links[''video_watch''])."\\">$data_video[name]</a>"; \r\n}\r\n\r\n\r\n ?>\r\n <br>\r\n       <br> \r\n        <table width=100%>        \r\n       <TBODY>\r\n<TR>\r\n<TD class=box2 width="100%">\r\n<TABLE dir=rtl border=0 cellSpacing=0 cellPadding=2 width="100%">\r\n<TBODY>\r\n<TR>\r\n<TD class=000 width="100%"><STRONG><FONT color=#cc6600>هل انت مشترك في اي منتدى؟</FONT></STRONG> <BR>يمكنك اضافة رابط هذه الاغنية الى موضوعك بالمنتدى الان! <BR>اكتب موضوعاً و انسخ الرابط التالي اليه! </TD></TR>\r\n<FORM id=embedFormvb name=embedFormvb action="">\r\n<TR>\r\n<TD width="100%"><TEXTAREA style="BORDER-BOTTOM: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; FONT-FAMILY: Tahoma; FONT-SIZE: 8pt; BORDER-TOP: #c0c0c0 1px solid; BORDER-RIGHT: #c0c0c0 1px solid" dir=ltr id=embed_code onclick=javascript:document.embedFormvb.embed_code.focus();document.embedFormvb.embed_code.select(); cols=55 name=embed_code>\r\n<?\r\nprint "[URL=".$scripturl."/".str_replace(array(''{cat}'',''{id}''),array($cat,$id),$links[''song_listen''])."]\r\n[img]".iif(!strchr($data_singer[''img''],"http://"),$scripturl."/".get_image($data_singer[''img'']),$data_singer[''img''])."[/img]\r\n[COLOR=\\"Red\\"][B] $data_singer[name] - $data_song[name] [/B][/COLOR][/URL]\r\n[URL=$scripturl][SIZE=\\"1\\"][FONT=\\"Tahoma\\"]".$sitename."[/FONT][/SIZE][/URL]</TEXTAREA> </TD></TR></FORM></TBODY></TABLE></TD></TR>";\r\n?>\r\n<TR>\r\n<TD class=box2 width="100%">\r\n<TABLE dir=rtl border=0 cellSpacing=0 cellPadding=2 width="100%">\r\n<TBODY>\r\n<TR>\r\n<TD class=000 width="100%"><STRONG><FONT color=#cc6600>هل لديك موقع أو مدونة؟</FONT></STRONG> <BR>يمكنك اضافة رابط هذه الاغنية الى موقعك او مدونتك ! <BR>انسخ الكود التالي و ضعه في موقعك الآن! </TD></TR>\r\n<FORM id=embedFormmsn name=embedFormmsn action="">\r\n<TR>\r\n<TD width="100%"><TEXTAREA style="BORDER-BOTTOM: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; FONT-FAMILY: Tahoma; FONT-SIZE: 8pt; BORDER-TOP: #c0c0c0 1px solid; BORDER-RIGHT: #c0c0c0 1px solid" dir=ltr id=embed_code onclick=javascript:document.embedFormmsn.embed_code.focus();document.embedFormmsn.embed_code.select(); cols=55 name=embed_code>\r\n<?\r\n\r\nprint $scripturl."/".str_replace(array(''{cat}'',''{id}''),array($cat,$id),$links[''song_listen'']);\r\n?>\r\n</textarea> </TD></TR></FORM></TBODY></TABLE></TD></TR></TBODY>\r\n</table>\r\n<?\r\n\r\n\r\n\r\nclose_table();\r\n\r\n//----------- another songs ---------------\r\nif(CFN != "listen_window.php"){\r\n$without_tables = ture;\r\nopen_table("$phrases[another_songs]");\r\n$no_singer_name=true;\r\nsongs_table($data[''album''],$data[''album_id''],"","name","asc",0,20);\r\nclose_table();\r\n}\r\n//------ Comments -------------------\r\nif($settings[''enable_songs_comments'']){\r\n    open_table($phrases[''members_comments'']);\r\n    get_comments_box(''song'',$id);\r\n    close_table();\r\n}\r\n?>', 1, 1, 1),
(128, 'الاغنية السابقة و التالية', 'prev_next_song', '<?\r\nglobal $phrases,$data_prev,$data_next,$links,$settings;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=right>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_song] : <a href=\\"".str_replace(array(''{cat}'',''{id}''),array($settings[''default_url_id''],$data_prev[''id'']),$links[''song_listen''])."\\" title=\\"$data_prev[name]\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=left>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_song] : <a href=\\"".str_replace(array(''{cat}'',''{id}''),array($settings[''default_url_id''],$data_next[''id'']),$links[''song_listen''])."\\" title=\\"$data_next[name]\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(127, 'المغني السابق و التالي', 'prev_next_singer', '<?\r\nglobal $phrases,$data_prev,$data_next;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=right>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_singer] : <a href=\\"".singer_url($data_prev[''id''],$data_prev[''page_name''],$data_prev[''name''])."\\" title=\\"$data_prev[name]\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=left>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_singer] : <a href=\\"".singer_url($data_next[''id''],$data_next[''page_name''],$data_next[''name''])."\\" title=\\"$data_next[name]\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(129, 'الكليب السابق و التالي', 'prev_next_video', '<?\r\nglobal $phrases,$data_prev,$data_next,$links;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=right>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_video] : <a href=\\"".str_replace(''{id}'',$data_prev[''id''],$links[''video_watch''])."\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=left>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_video] : <a href=\\"".str_replace(''{id}'',$data_next[''id''],$links[''video_watch''])."\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(130, 'القسم السابق و التالي', 'prev_next_cat', '<?\r\nglobal $phrases,$data_prev,$data_next;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=right>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_cat] : <a href=\\"".cat_url($data_prev[''id''],$data_prev[''page_name''],$data_prev[''name''])."\\" title=\\"$data_prev[name]\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=left>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_cat] : <a href=\\"".cat_url($data_next[''id''],$data_next[''page_name''],$data_next[''name''])."\\" title=\\"$data_next[name]\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(131, 'قسم الكليبات السابق و التالي', 'prev_next_video_cat', '<?\r\nglobal $phrases,$data_prev,$data_next,$links;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=right>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_cat] : <a href=\\"".str_replace(''{id}'',$data_prev[''id''],$links[''browse_videos''])."\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=left>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_cat] : <a href=\\"".str_replace(''{id}'',$data_next[''id''],$links[''browse_videos''])."\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(132, 'الألبوم السابق و التالي', 'prev_next_album', '<?\r\nglobal $phrases,$data_prev,$data_next,$data_singer;\r\n\r\nopen_table();\r\nprint  "<table width=100%><tr><td width=50% align=right>";\r\nif($data_prev[''name'']){\r\nprint "$phrases[prev_album] : <a href=\\"".album_url($data_prev[''id''],$data_prev[''page_name''],$data_prev[''name''],$data_singer[''id''],$data_singer[''page_name''],$data_singer[''name''])."\\" title=\\"$data_prev[name]\\">".$data_prev[''name'']."</a>";\r\n}\r\nprint "</td><td width=50% align=left>";\r\n if($data_next[''name'']){\r\nprint "$phrases[next_album] : <a href=\\"".album_url($data_next[''id''],$data_next[''page_name''],$data_next[''name''],$data_singer[''id''],$data_singer[''page_name''],$data_singer[''name''])."\\" title=\\"$data_next[name]\\">".$data_next[''name'']."</a>";\r\n}\r\nprint "</td></tr></table>";\r\nclose_table();\r\n\r\n?>', 1, 1, 0),
(133, 'روابط الصفحات', 'pages_links', '<?\r\nglobal $f_page_string,$nextpag,$prevpag,$f_items_perpage,$f_start,$start,$phrases,$f_pages,$f_end,$f_cur_page;\r\n\r\n\r\nprint "<center>\r\n<div class=''pagenavi''> <span class=''page''>$phrases[pages] : </span> ";\r\n\r\n//----- first and prev -----//\r\nif($start >0){\r\nprint "<a title=\\"$phrases[first_page]\\"  href=''".str_replace("{start}",0,$f_page_string)."'' class=''first''><<</a> \\n";\r\n\r\n$previouspage = $start - $f_items_perpage;\r\nprint "<a title=\\"$phrases[prev_page]\\" href=''".str_replace("{start}",$previouspage,$f_page_string)."'' class=''prev''><</a>\\n";\r\n}\r\n\r\n\r\n//----- pages loop -------//\r\nfor ($i = $f_start; $i <= $f_end; $i++) {\r\n$nextpag = $f_items_perpage*($i-1);\r\nif ($nextpag == $start){\r\nprint "<span class=''current''>$i</span>&nbsp;\\n";\r\n}else{\r\nprint "<a href=''".str_replace("{start}",$nextpag,$f_page_string)."'' class=''page''>$i</a>&nbsp;\\n";\r\n}\r\n}\r\n//----- loop end --------//\r\n\r\n\r\nif (! ( ($start/$f_items_perpage) == ($f_pages - 1) ) && ($f_pages != 1) ){\r\n$last_pag = ($f_pages-1)*$f_items_perpage;\r\n$nextpag = $start+$f_items_perpage; \r\n\r\n  \r\n//----- extend and last page num -----//\r\n\r\nif($f_end < $f_pages){  \r\nprint " <span class=''extend''>...</span> <a href=''".str_replace("{start}",$last_pag,$f_page_string)."'' class=''page''>$f_pages</a>\\n";\r\n}\r\n\r\n//------ next and last -------//\r\nprint "<a title=\\"$phrases[next_page]\\" href=''".str_replace("{start}",$nextpag,$f_page_string)."'' class=''next''>></a>\\n";\r\n\r\n\r\nprint "  <a title=\\"$phrases[last_page]\\" href=''".str_replace("{start}",$last_pag,$f_page_string)."'' class=''last''>>></a>\\n";\r\n\r\n}\r\nprint "</div><br>\r\n</center>";\r\n?>', 1, 1, 0),
(134, 'نموذج رسالة الاتصال بنا', 'contactus_msg', '<html dir=rtl>\r\n<body>\r\n\r\nاسم المرسل : {name} <br>\r\nبريد المرسل : {email} <br><br>\r\n\r\n----------------------------------<br><br>\r\n\r\n{message}\r\n\r\n<br><br>\r\n\r\n---------------------------------\r\n\r\n</body>\r\n</html>', 1, 1, 0),
(135, '', 'no_title_no_border', '{content}', 0, 1, 0),
(136, 'عرض الصورة', 'photo_view', '<?\r\nglobal $data,$global_align,$global_align_x,$list,$prev_index,$next_index,$phrases,$in_this_photo,$style,$links;\r\n\r\n\r\n print "<table width=100%><tr>\r\n       <td width=''33%'' align=''$global_align''>";\r\n       \r\n       if($list[$prev_index][''id'']){ \r\n      \r\n       print "<a href=\\"".str_replace("{id}",$list[$prev_index][''id''],$links[''singer_photo''])."\\"><img src=\\"images/arrw_$global_align.gif\\" title=\\"$phrases[prev_photo]\\" border=0><br>\r\n       $phrases[prev_photo]</a>";\r\n       }\r\n       \r\n       print "</td>\r\n       <td width=''33%'' align=''center''><a href=\\"$data[img]\\" target=_blank>\r\n       <img src=\\"images/full_size.gif\\" title=\\"$phrases[full_photo_size]\\"><br>$phrases[full_photo_size]</a></td>  \r\n       <td width=''33%'' align=''$global_align_x''>";\r\n    \r\n     if($list[$next_index][''id'']){ \r\n      $next_url = str_replace("{id}",$list[$next_index][''id''],$links[''singer_photo'']); \r\n       print "<a href=\\"".$next_url."\\"><img src=\\"images/arrw_".$global_align_x.".gif\\" title=\\"$phrases[next_photo]\\" border=0><br>\r\n       $phrases[next_photo]</a>";\r\n     }else{\r\n        $next_url = str_replace("{id}",$list[0][''id''],$links[''singer_photo'']);\r\n       }\r\n     \r\n       print "</td>  \r\n       </tr></table><br><br>";\r\n       \r\n \r\n         print "<center><a href=\\"javascript:;\\" onClick=\\"window.location=scripturl+''/$next_url'';\\"><img src=\\"$data[img_resized]\\" title=\\"$data[name]\\" border=0></a><br><br>";\r\n       print_rating(''singer_photo'',$data[''id''],$data[''rate'']);\r\n       print "</center>";\r\n       \r\n       \r\n       print iif($data[''name''],"<br><br> <img src=''$style[images]/info.gif''> &nbsp; $data[name]");\r\n       \r\n       print "<br>\r\n        <img src=''$style[images]/add_date.gif''> &nbsp; <b>$phrases[add_date] : </b>".get_date($data[''date''])."<br>";\r\n        print "<img src=''$style[images]/views.gif''> &nbsp; <b>$phrases[views] : </b>$data[views]"; \r\n        \r\n        \r\n        \r\n      \r\n        \r\n      \r\n         print iif($in_this_photo,"<br><br> <img src=''$style[images]/in_this_photo.gif''> &nbsp; <b>$phrases[in_this_photo] : </b> $in_this_photo");     \r\n      //--------------------------//   \r\n         \r\n       print "<br><br>\r\n\r\n<div align=''$global_align_x''>\r\n<a href=''http://www.facebook.com/sharer.php?u=".urlencode("http://".$_SERVER[''HTTP_HOST''].$_SERVER[''REQUEST_URI''])."'' target=_blank title=''Share it on Facebook''><img src=''images/facebook_mid.gif'' alt=''Share it on Facebook'' border=0></a>\r\n</div>";\r\n?>', 1, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `songs_templates_cats`
--

CREATE TABLE IF NOT EXISTS `songs_templates_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `selectable` int(11) NOT NULL default '0',
  `images` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `songs_templates_cats`
--

INSERT INTO `songs_templates_cats` (`id`, `name`, `selectable`, `images`) VALUES
(1, 'الستايل الافتراضي', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `songs_urls_fields`
--

CREATE TABLE IF NOT EXISTS `songs_urls_fields` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `download_icon` varchar(255) NOT NULL,
  `listen_icon` varchar(255) NOT NULL,
  `show_listen` int(1) NOT NULL default '0',
  `show_download` int(1) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `download_alt` varchar(100) NOT NULL,
  `listen_alt` varchar(100) NOT NULL,
  `download_for_members` int(1) NOT NULL,
  `listen_for_members` int(1) NOT NULL,
  `listen_type` int(1) NOT NULL,
  `show_ext_listen` int(1) NOT NULL,
  `ext_listen_icon` varchar(100) NOT NULL,
  `ext_listen_alt` varchar(100) NOT NULL,
  `active` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `songs_urls_fields`
--

INSERT INTO `songs_urls_fields` (`id`, `name`, `download_icon`, `listen_icon`, `show_listen`, `show_download`, `ord`, `download_alt`, `listen_alt`, `download_for_members`, `listen_for_members`, `listen_type`, `show_ext_listen`, `ext_listen_icon`, `ext_listen_alt`, `active`) VALUES
(1, 'رابط التحميل', 'images/save.gif', 'images/listen.gif', 1, 1, 0, 'تحميل ({downloads} تحميل)', 'استماع ({listens} استماع) ', 0, 0, 0, 0, 'images/ext_listen.gif', 'استماع خارجي ({listens} استماع) ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `songs_user`
--

CREATE TABLE IF NOT EXISTS `songs_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `group_id` int(11) NOT NULL default '0',
  `permisions` text NOT NULL,
  `cp_permisions` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_videos_cats`
--

CREATE TABLE IF NOT EXISTS `songs_videos_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `img` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  `path` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(1) NOT NULL default '0',
  `download_limit` int(1) NOT NULL default '0',
  `page_title` varchar(255) NOT NULL,
  `page_description` varchar(255) NOT NULL,
  `page_keywords` varchar(255) NOT NULL,
  `users` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `active` (`active`),
  KEY `ord` (`ord`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `songs_videos_cats`
--

INSERT INTO `songs_videos_cats` (`id`, `name`, `img`, `cat`, `path`, `ord`, `active`, `download_limit`, `page_title`, `page_description`, `page_keywords`, `users`) VALUES
(1, 'كليبات عربية', '', 0, '1,0', 1, 1, 0, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `songs_videos_data`
--

CREATE TABLE IF NOT EXISTS `songs_videos_data` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `downloads` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `date` int(11) NOT NULL,
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  `rate` float NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `rate` (`rate`),
  KEY `name` (`name`),
  KEY `downloads` (`downloads`),
  KEY `views` (`views`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_videos_tags`
--

CREATE TABLE IF NOT EXISTS `songs_videos_tags` (
  `id` int(11) NOT NULL auto_increment,
  `video_id` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `singer_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `singer_id` (`singer_id`),
  KEY `video_id` (`video_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_votes`
--

CREATE TABLE IF NOT EXISTS `songs_votes` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `cnt` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `songs_votes_cats`
--

CREATE TABLE IF NOT EXISTS `songs_votes_cats` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
